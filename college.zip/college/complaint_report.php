<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$head = "report";
$page = "complaint_report";
include("layouts/header.php");
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$compalint_type = @$_REQUEST['compalint_type'];
$from     = @$_REQUEST['from'];
$to       = @$_REQUEST['to'];
if ($from) {
    $from  = date('Y-m-d 00:00:00', strtotime($from));
    $to    = date('Y-m-d 23:59:59', strtotime($to));
} else {
    $from  = date('Y-m-d 00:00:00');
    $to    = date('Y-m-d 23:59:59');
}
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h3 class="m-0">Report/Complaint</h3>
                </div>
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div><!-- /.content-header -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <form method="POST" action="complaint_report.php" autocomplete="off">
                                        <label class="col-lg-4 control-label" style="padding-top: 10px;">From</label>
                                        <div class="col-lg-3">
                                            <input type="date" placeholder="DD-MM-YYYY" name="from" class="form-control" id="from" value="<?= date('d-m-Y') ?>" required>
                                        </div>
                                    
                                        <label class="col-lg-4 control-label" style="padding-top: 10px;">To</label>
                                        <div class="col-lg-3">
                                            <input type="date" name="to" placeholder="DD-MM-YYYY" class="form-control" id="to" value="<?= date('d-m-Y') ?>" required>
                                        </div>
                                   
                                <div class="form-group">
                                    <label class="col-lg-2 control-label" style="padding-top: 10px;">Complaint Type</label>
                                    <div class="col-lg-3">
                                        <select name="compalint_type" id="compalint_type" class="form-control" required>
                                            <option value="">Select Complaint Type</option>
                                            <option value="All">All Complaint </option>
                                            <option value="Pending_For_Allocation">Job Card Pending for Allocation</option>
                                            <option value="Pending_For_Workman">Pending For Workman</option>
                                            <option value="Pending_For_Closer">Pending For Closure</option>
                                            <option value="Closer"> Closed</option>
                                            <option value="Beyond-SLG">Beyond SLG</option>
                                            <option value="Repeat-Complaint">Repeat Complaint</option>
                                        </select>
                                    </div>
                                </div>
                                    <div class="form-group">
                                        <div class="col-lg-8">
                                            <input type="submit" class="btn btn-primary " name="submit">
                                        </div>
                                    </div>
                            </form>
<?php 
                           if($compalint_type){ ?>

                            <div style="float:right"><a href="print_complaint.php?&from=<?= $from ?>&to=<?= $to ?>&compalint_type=<?= $compalint_type ?>" target="_blank"><input type="button" value="Export To Excel" class="btn btn-success btn-xs"></a></div>
                            
                                  <strong> From Date : </strong>
                                    <?php echo  date('d-m-Y h:i A', strtotime($from)) ?>
                                    <strong> To Date : </strong>
                                    <?php echo  date('d-m-Y h:i A', strtotime($to ))?>
                                    <strong>  Complaint Type :</strong>
                                    <?php echo  $compalint_type ?>
                               
                            <table class="table table-bordered table-hover table-condensed">
                                
                                <tr class="warning">
                                    <th width="10%">
                                        <div align="center">#</div>
                                    </th>
                                    <th width="10%">
                                        <div align="center">Complaint Number</div>
                                    </th>
                                    <th width="10%">
                                        <div align="center">Date of Complaint</div>
                                    </th>
                                    <th width="10%">
                                        <div align="center">Employee Name</div>
                                    </th>
                                    <th width="10%">
                                        <div align="center">P Number</div>
                                    </th>
                                    <th width="10%">
                                        <div align="center">Estimated Date of Completion</div>
                                    </th>
                                    <th width="10%">
                                        <div align="center">Complaint Close Date</div>
                                    </th>
                                    <?php
                                    if ($compalint_type == 'All') { ?>
                                        <th width="10%">
                                            <div align="center">Status</div>
                                        </th>
                                    <?php } ?>
                                </tr>
                                <?php
                                if ($compalint_type == 'All') {
                                    $get_complaint = mysqli_query($conn, "SELECT complaint.* ,workman.workman_name,jobs.jobs_name,employee.name,employee.p_number,employee.phone
                                                FROM complaint 
                                                LEFT JOIN workman ON complaint.allocated_to = workman.id
                                                LEFT JOIN jobs ON complaint.type_of_job = jobs.id 
                                                LEFT JOIN employee ON complaint.employee_id = employee.id 
                                                WHERE complaint.complaint_login_datetime between '$from' AND '$to'
                                                ORDER BY complaint.id DESC");
                                } elseif($compalint_type=="Beyound-SLG"){
                                    $get_complaint = mysqli_query($conn, "SELECT complaint.* ,workman.workman_name,jobs.jobs_name,employee.name,employee.p_number,employee.phone
                                                FROM complaint 
                                                LEFT JOIN workman ON complaint.allocated_to = workman.id
                                                LEFT JOIN jobs ON complaint.type_of_job = jobs.id 
                                                LEFT JOIN employee ON complaint.employee_id = employee.id 
                                                WHERE complaint.complaint_login_datetime between '$from' AND '$to' AND complaint.estimated_date_of_completion < complaint.complaint_closed_datetime
                                                ORDER BY complaint.id DESC");
                                }elseif ($compalint_type == 'Repeat-Complaint') {
                                    $get_complaint = mysqli_query($conn, "SELECT complaint.* ,workman.workman_name,jobs.jobs_name,employee.name,employee.p_number,employee.phone
                                                FROM complaint 
                                                LEFT JOIN workman ON complaint.allocated_to = workman.id
                                                LEFT JOIN jobs ON complaint.type_of_job = jobs.id 
                                                LEFT JOIN employee ON complaint.employee_id = employee.id 
                                                WHERE complaint.complaint_login_datetime between '$from' AND '$to' AND complaint.repeat_complaint='on'
                                                ORDER BY complaint.id DESC");
                                }
                                else {
                                    $get_complaint = mysqli_query($conn, "SELECT complaint.* ,workman.workman_name,jobs.jobs_name,employee.name,employee.p_number,employee.phone
                                                FROM complaint 
                                                LEFT JOIN workman ON complaint.allocated_to = workman.id
                                                LEFT JOIN jobs ON complaint.type_of_job = jobs.id 
                                                LEFT JOIN employee ON complaint.employee_id = employee.id 
                                                WHERE complaint.complaint_login_datetime between '$from' AND '$to' AND complaint.complaint_status='$compalint_type'
                                                ORDER BY complaint.id DESC");
                                }
                                $i = 0;
                                while ($complaint_list = mysqli_fetch_assoc($get_complaint)) {
                                ?>
                                <tr onclick="window.open('complaint_edit.php?id=<?= md5($complaint_list['id']);?>')">
                                    <!-- <tr onclick="window.location.href = 'complaint_edit.php?id=<?= md5($complaint_list['id']); ?>';"> -->
                                        <td>
                                            <div align="center">
                                                <?= ++$i ?>
                                            </div>
                                        </td>
                                        <td>
                                            <div align="center">
                                                C/<?= date('m-Y', strtotime($complaint_list['complaint_login_datetime'])); ?>/ <?= @$complaint_list['complaint_number'] ?>
                                            </div>
                                        </td>
                                        <td>
                                            <div align="center">
                                                <?= date('d-m-Y h:i A', strtotime(@$complaint_list['complaint_login_datetime'])) ?>
                                            </div>
                                        </td>
                                        <td>
                                            <div align="center">
                                                <?= @$complaint_list['name'] ?>
                                            </div>
                                        </td>
                                        <td>
                                            <div align="center">
                                                <?= @$complaint_list['p_number'] ?>
                                            </div>
                                        </td>
                                        <td>
                                            <div align="center">
                                                <?= date('d-m-Y h:i A', strtotime(@$complaint_list['estimated_date_of_completion'])) ?>
                                            </div>
                                        </td>
                                        <?php if(date('d-m-Y h:i A', strtotime(@$complaint_list['complaint_closed_datetime'] ))!='30-11--0001 12:00 AM') { ?>
                                        <td>
                                            <div align="center">
                                                <?= date('d-m-Y h:i A', strtotime(@$complaint_list['complaint_closed_datetime'] ))?>
                                            </div>
                                        </td>
                                        <?php }else{ ?>
                                        <th>
                                        </th>
                                        <?php }?>
                                        <?php
                                        if ($compalint_type == 'All') { ?>
                                            <?php if ($complaint_list['complaint_status'] == 'Pending_For_Allocation') {
                                                $status = "Pending for Job Card";
                                                $cl = "info";
                                            } elseif ($complaint_list['complaint_status'] == 'Pending_For_Workman') {
                                                $status = "Work in Progress";
                                                $cl = "info";
                                            } elseif ($complaint_list['complaint_status'] == 'Pending_For_Closer') {
                                                $status = "Pending for Closure";
                                                $cl = "info";
                                            } elseif ($complaint_list['complaint_status'] == 'Closer') {
                                                $status = "Closed";
                                                $cl = "success";
                                            }
                                            ?>
                                            <td><span class="badge badge-<?= $cl ?>"><?= $status ?></span></td>
                                        <?php } ?>
                                    </tr>
                                <?php } ?>
                            </table>

                            <?php } ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $("#from").datepicker({
        dateFormat: 'dd-mm-yy'
    });
    $("#to").datepicker({
        dateFormat: 'dd-mm-yy'
    });
</script>
<?php
include("layouts/footer.php");
?>