<?php
session_start();
include("../inc/db_conn.php");
//$db=$conn;// database connection  
$myid = $_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');
$workman_name   = $_POST['workman_name'];
$workman_email   = $_POST['workman_email'];
$workman_username   = $_POST['workman_username'];
$workman_mobile   = $_POST['workman_mobile'];
$workman_type   = $_POST['workman_type'];
$vender_email   = $_POST['vender_email'];
$vender_name   = $_POST['vender_name'];
$vender_code   = $_POST['vender_code'];
$vender_mobile   = $_POST['vender_mobile'];
$pwd = rand(0000, 9999);
$result1 = mysqli_query($conn,  "SELECT id FROM employee WHERE p_number='$workman_username'");
$row1 = mysqli_fetch_assoc($result1);
if (!$row1['id']) {
        $EXE   = mysqli_query($conn, "INSERT INTO workman SET workman_name = '$workman_name',workman_email = '$workman_email',
        workman_username = '$workman_username',workman_mobile = '$workman_mobile', workman_type = '$workman_type',vender_email = '$vender_email',
        vender_name = '$vender_name',vender_code = '$vender_code', vender_mobile = '$vender_mobile',
        created_by='$myid',created_date_time='$date',workman_password='$pwd'");
}
if ($EXE) {
        echo "yes";
        //send email sms
        include "email_message_send.php";
        email_sms($workman_email, $workman_mobile, $workman_name, $pwd);
} else {
        echo "no";
}
