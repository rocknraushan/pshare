<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$myid = $_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');

$emp_id = $_POST['emp_id'];
$emp_id = explode('/', $emp_id);
$emp_id = $emp_id[1];
$employee_id1 = $_POST['employee_id1'];
$complaint_number_search = $_POST['complaint_number_search'];
$employee_id22 = $_POST['employee_id22'];
$type_of_job22 = $_POST['type_of_job22'];

if ($emp_id) {
    $sql = "SELECT employee.id,employee.house_id,employee.email,employee.phone, house.id AS houseID,house.house_number,house_type.house_type 
        FROM employee
        LEFT JOIN house ON employee.house_id = house.id
        LEFT JOIN house_type ON house.house_type = house_type.id        
        WHERE employee.is_deleted='N' AND employee.p_number = '$emp_id' ";
    $q1 = mysqli_query($conn, $sql);
    $listofAvilHouse = mysqli_fetch_assoc($q1);
    $data = array();
    $data['employee_id'] = $listofAvilHouse['id'];
    // $data['houseID'] = $listofAvilHouse['houseID'];
    $data['email'] = $listofAvilHouse['email'];
    $data['phone'] = $listofAvilHouse['phone'];
    echo json_encode($data);
} elseif ($complaint_number_search) { 
    $complaint_detail = explode('/', $complaint_number_search);
    $complaint_month = $complaint_detail[1];
    $complaint_year = $complaint_detail[2];
    $complaint_num = $complaint_detail[3];
    $complaintList = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id FROM complaint WHERE complaint_number='$complaint_num' AND YEAR(complaint_login_datetime)='$complaint_year' AND MONTH(complaint_login_datetime)='$complaint_month'"));
    echo $complaintList['id'];
} elseif ($employee_id1) {
    $employeeList = mysqli_fetch_assoc(mysqli_query($conn, "SELECT house_id FROM employee WHERE id='$employee_id1'"));
    $q11 = mysqli_fetch_assoc(mysqli_query($conn, "select house.id as houseID,house.house_number,house_type.house_type from house_type
    INNER JOIN house ON house.house_type = house_type.id WHERE house.id='" . $employeeList['house_id'] . "'"));

    $q1 = mysqli_query($conn, "select house.id as houseID,house.house_number,house_type.house_type from house_type
    INNER JOIN house ON house.house_type = house_type.id WHERE house.is_deleted='N' AND house.house_status='Non-Active'"); ?>
    <option value="<?= $q11['houseID']; ?>" selected><?= $q11['house_type'] . " - " . $q11['house_number'];  ?></option>
    <?php
    while ($listofAvilHouse = mysqli_fetch_assoc($q1)) {
    ?>
        <option value="<?= $listofAvilHouse['houseID']; ?>"><?= $listofAvilHouse['house_type'] . " - " . $listofAvilHouse['house_number'];  ?></option>
    <?php
    }
}elseif($employee_id22){
    $complaintquery=mysqli_query($conn,"SELECT id,complaint_login_datetime,complaint_number FROM complaint WHERE employee_id='$employee_id22' AND type_of_job='$type_of_job22'");
   if(mysqli_num_rows($complaintquery)>0){ ?>
        <select class="form-control" name="repeat_complaint_id[]">
        <?php
        while($complaintList=mysqli_fetch_assoc($complaintquery)){?>
            <option value="<?=$complaintList['id']?>"><?="C/".date('m-Y', strtotime($complaintList['complaint_login_datetime']))."/".$complaintList['complaint_number']?></option>
       <?php  }
        ?>
        </select>
  <?php }
}
