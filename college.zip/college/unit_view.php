<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$count=1;
$sql = "SELECT * FROM unit WHERE is_deleted='N' ORDER BY id DESC";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
	while ($row = $result->fetch_assoc()) {
		$id = $row['id'];
?>
		<tr>
			<td><?= $count++; ?></td>
			<td><?= $row['unit_name']; ?></td>
			
			<td><button type="button" class="btn btn-success btn-sm update" data-toggle="modal" data-keyboard="false" data-backdrop="static" data-target="#modal-update" 
			data-id="<?= $row['id']; ?>" 
			data-unit_name="<?= $row['unit_name']; ?>" 
			
			>Edit</button></td>
			<td><button type="button" class="btn btn-danger btn-sm update" id="delete" data-id="<?= $row['id']; ?>"
			
			>Delete</button></td>
		</tr>
<?php
	}
} else {
	echo "<tr >
		<td colspan='5'>No Result found !</td>
		</tr>";
}
mysqli_close($conn);
?>