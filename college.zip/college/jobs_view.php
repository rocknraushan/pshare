<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$count = 1;

$sql="SELECT jobs.*,job_category.job_category AS cat_name,job_sub_category.job_sub_category AS sub_cat_name FROM jobs 
LEFT JOIN job_category ON job_category.id = jobs.jobs_category_id 
LEFT JOIN job_sub_category ON job_sub_category.id = jobs.jobs_sub_category_id
WHERE jobs.is_deleted='N' ORDER BY jobs.id DESC";
// echo $sql;
// exit;
$result = mysqli_query($conn,$sql);
if ($result) {
	while ($row = mysqli_fetch_array($result)) {	
?>
<tr>
<td><?= $count++; ?>
<td><?= $row['cat_name']; ?></td>			
<td><?= $row['sub_cat_name']; ?></td>
<td><?= $row['jobs_name']; ?></td>
<td><?= $row['slg']; ?></td>
<td><button type="button" class="btn btn-success btn-sm update" data-toggle="modal" data-keyboard="false" data-backdrop="static" data-target="#modal-update" 
    data-id="<?= $row['id'];?>" 
    data-jobs_category_edit="<?= $row['jobs_category_id']; ?>" 
    data-jobs_sub_category_edit="<?= $row['jobs_sub_category_id']; ?>"
	data-jobs_name_edit="<?= $row['jobs_name'];?>" 
	data-slg_edit="<?= $row['slg'];?>" 
	>Edit</button>
</td>
<td><button type="button" class="btn btn-danger btn-sm update" id="delete" data-id="<?= $row['id']; ?>">Delete</button></td>
</tr>
<?php
	} 
} else {
	echo "<tr >
		<td colspan='5'>No Result found !</td>
		</tr>";
}
mysqli_close($conn);
?>

