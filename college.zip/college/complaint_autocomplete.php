<?php
include("../inc/db_conn.php");
if(isset($_GET['term'])){
	$name = $_GET['term'];
    $return_arr = array();
	$result = mysqli_query($conn,"SELECT name,p_number FROM employee WHERE is_deleted='N' AND (name LIKE '$name%' OR p_number LIKE '$name%')");
	if(mysqli_num_rows($result) >0)
	{
		while($row = mysqli_fetch_array($result)) {
			$return_arr[] =  $row['name'].'/'.$row['p_number'];
		}
		echo json_encode($return_arr);
	}
	else
	{
		return false;   
	}
}
?>