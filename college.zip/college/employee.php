<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$head="masters";
$head1="employee";
$page="employee";
include("layouts/header.php");
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h3 class="m-0">Masters/Employee</h3>
                </div>
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div><!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header border-0">
                            <div class="d-flex justify-content-between">
                                Employee
                                <div style="float:right">
                                    <a href="#" class="btn btn-success btn-sm" data-toggle="modal" data-target="#exampleModal">Add New</a>
                                </div>
                            </div>
                        </div>

                        <div class="card-body">
                            <div class="alert alert-success alert-dismissible" id="success" style="display:none;">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                            </div>
                            <table id="example1" class="table table-bordered table-sm">
                                <thead>
                                    <tr>
                                        <th>Sl No.</th>
                                        <th>User name</th>
                                        <th>Email</th>
                                        <th>Alternative Email</th>
                                        <th>Mobile</th>
                                        <th>Alternative Mobile</th>
                                        <th>Intercom Number</th>
                                        <th>Personal Number</th>
                                        <th>House </th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody id="table">

                                </tbody>
                            </table>

                            <script type="text/javascript">
                                $(document).ready(function() {
                                    loaddata();
                                });

                                function loaddata() {
                                    $('#modal-loader').modal('show');
                                    $.ajax({
                                        url: 'employee_view.php',
                                        type: 'POST',
                                        dataType: 'html',
                                        success: function(newContent) {
                                            $('#table').html('');
                                            $('#table').append(newContent);
                                            
                                            $('#example1').DataTable();
                                            $('#modal-loader').modal('hide');
                                        }
                                    });
                                }
                            </script>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- /.content -->
    <!-- /.content-wrapper -->
</div>
</div>

</body>
 

<div class="modal" id="modal-loader" style="z-index:1000000000">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body" style="z-index:1000000000">
                <img class="mx-auto d-block" src="dist/img/loader.gif" />
                <p class="text-center">Please Wait</p>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

<div class="modal" id="exampleModal">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Employee</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form class="form-horizontal" role="form" method="post" autocomplete="off" id="userForm" action="">
                <div class="modal-body">
                    <input type="hidden" value="<?= @$data['id'] ?>" name="token">
                    <div class="form-group">
                        <label for="exampleInputPassword1">Employee Name</label>
                        <input type="text" name="user_name" class="form-control rec" value="<?= @$data['name'] ?>" id="" placeholder="User Name" required>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Personal Number</label>
                        <input type="number" name="p_number" class="form-control rec" value="<?= @$data['p_number'] ?>" id="" placeholder="Employee Personal Number" required min="1">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1"> Email ID.</label>
                        <input type="email" name="email" class="form-control rec" value="<?= @$data['email'] ?>" id="" placeholder="Email ID" required>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Alternative Email ID.</label>
                        <input type="email" name="alternative_email" class="form-control rec" id="" placeholder="Alternative Email ID">
                    </div>

                    <div class="form-group">
                        <label for="exampleInputEmail1"> Mobile No.</label>
                        <input type="number" name="phone" class="form-control rec" id=" " placeholder="Mobile" required min="1">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Alternative Mobile No.</label>
                        <input type="number" name="alternative_phone" class="form-control rec" id="" placeholder="Mobile" min="1">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Intercom Number</label>
                        <input type="number" name="inter_com_nunber" class="form-control rec" id="" placeholder="Intercom Number" min="1">
                    </div>
                    <div class="form-group ven">
                        <label for="exampleInputEmail1">House Type </label>
                        <select name="house_type_id" id="house_type_id" class="form-control rec" required>
                            <option value="">Select House Type</option>
                            <?php
                            $q1 = mysqli_query($conn, "select id ,house_type from house_type WHERE is_deleted='N'");

                            while ($listofAvilHouse = mysqli_fetch_assoc($q1)) {
                            ?>
                                <option value="<?= $listofAvilHouse['id']; ?>"><?= $listofAvilHouse['house_type'];  ?></option>
                            <?php
                            }   ?>
                        </select>
                    </div>
                    <div class="form-group ven">
                        <label for="exampleInputEmail1">House Number </label>
                        <select name="house_id" id="house_id" class="form-control rec" required>
                            <option value="">Select House Number</option>

                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" id="submit_request" onSubmit="add(event)">Submit</button>
                </div>
        </div>
        </form>
    </div>
</div>
</div>
<script>
    $('#house_type_id').on('change', function() {
        var house_ty_id = $(this).val();
        $('#modal-loader').modal('show');
        if (house_ty_id) {
            //alert(ponumber);
            //alert(party_id);
            $.ajax({
                type: "POST",
                url: "employee_change.php",
                data: {
                    'house_ty_id': house_ty_id,
                },
                beforeSend: function() {
                    $("#view-model").html("");
                    $('#house_id').find('select').val('');

                },
                success: function(data) {
                    
                    // console.log(data);
                    $("#house_id").html(data);
                    $('#modal-loader').modal('hide');
                }
            });
        }
    });
</script>
<script>
    $(document).on('submit', '#userForm', function(e) {
        $('#modal-loader').modal('show');
        $('#submit_request').prop('disabled', true);
        e.preventDefault();
        $.ajax({
            method: "POST",
            url: "employee_add.php",
            data: $(this).serialize(),
            success: function(data) {
                
                if(data=='yes'){
               
                // $('#exampleModal').modal('hide');
                $('#userForm').find('input').val('');
                $('#userForm').find('select').val('');
                loaddata();
                swal("Employee Saved!", "", "success");
                $('#submit_request').prop('disabled', false);
                }else{
                    $('#userForm').find('input').val('');
                $('#userForm').find('select').val('');
                loaddata();
                    swal("Duplicate Entry!", "", "warning");
                }
                $('#modal-loader').modal('hide');
            }
        });
    });
</script>


<!-- UPATE  DATA -->
<!-- Modal Update-->
<div class="modal fade" id="modal-update">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Update Employee</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <!--1-->
                <div class="form-group">
                    <label for="exampleInputPassword1">Name</label>
                    <input type="text" name="name_modal" id="name_modal" class="form-control" required>
                </div>
                <!--2-->
                <div class="form-group">
                    <label>Email</label>
                    <input type="text" name="email_modal" id="email_modal" class="form-control" required>
                </div>
                <!--3-->
                <div class="form-group">
                    <label>Alternative Email</label>
                    <input type="text" name="alternative_email_modal" id="alternative_email_modal" class="form-control">
                </div>
                <!--4-->
                <div class="form-group">
                    <label>Phone</label>
                    <input type="number" name="phone_modal" id="phone_modal" class="form-control" required min="1">
                </div>
                <!--5-->
                <div class="form-group">
                    <label>Alternative Phone</label>
                    <input type="number" name="alternative_phone_modal" id="alternative_phone_modal" class="form-control" min="1">
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Intercom Number</label>
                    <input type="number" name="inter_com_nunber" id="inter_com_nunber" class="form-control rec" id="" placeholder="Intercom Number" min="1">
                </div>
                <!--6-->
                <div class="form-group">
                    <label>Personal Number</label>
                    <input type="text" name="per_modal" id="per_modal" class="form-control" required min="1">
                </div>
                <!--7-->
                <div class="form-group ven">
                    <label for="exampleInputEmail1">House Type </label>
                    <select name="house_type_id_edit" id="house_type_id_edit" class="form-control rec" required>
                        <option value="">Select House Type</option>
                        <?php
                        $q1 = mysqli_query($conn, "select id ,house_type from house_type WHERE is_deleted='N'");

                        while ($listofAvilHouse = mysqli_fetch_assoc($q1)) {
                        ?>
                            <option value="<?= $listofAvilHouse['id']; ?>"><?= $listofAvilHouse['house_type'];  ?></option>
                        <?php
                        }   ?>
                    </select>
                </div>
                <div class="form-group ven">
                    <label for="exampleInputEmail1">House Number </label>
                    <select name="house_id_edit" id="house_id_edit" class="form-control rec" required>
                    </select>
                </div>
                <input type="hidden" name="old_house_id" id="old_house_id" class="form-control">
                <input type="hidden" name="id_modal" id="id_modal" class="form-control">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary" id="update_data">Update</button>
            </div>
        </div>
    </div>
</div>
</div>
<!-- Modal End-->
<script>
    $('#house_type_id_edit').on('change', function() {
        var house_ty_id_edit = $(this).val();
        $('#modal-loader').modal('show');
           
        if (house_ty_id_edit) {
            //alert(ponumber);
            //alert(party_id);
            $.ajax({
                type: "POST",
                url: "employee_change.php",
                data: {
                    'house_ty_id_edit': house_ty_id_edit,
                },
                beforeSend: function() {
                    $("#view-model").html("");
                    $('#house_id_edit').find('select').val('');

                },
                success: function(data) {
                    // console.log(data);
                   
                    $("#house_id_edit").html(data);
                    $('#modal-loader').modal('hide');
                }
            });
        }
    });
</script>
<script>
    $(function() {
        $('#modal-loader').modal('show');
        $('#modal-update').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget); /*Button that triggered the modal*/
            var id = button.data('id');
            var name = button.data('name');
            var email = button.data('email');
            var alternative_email = button.data('alternative_email');
            var phone = button.data('phone');
            var alternative_phone = button.data('alternative_phone');
            var inter_com_nunber = button.data('inter_com_nunber');
            var per = button.data('per');
            var house_type = button.data('house_id');
            var house_name = button.data('house_name');
            var house_status_id =  button.data('house_status_id');
           //alert(house_status_id);

            // var house_status_edit = button.data('house_status');
            var modal = $(this);
            modal.find('#old_house_id').val(house_status_id);
            modal.find('#name_modal').val(name);
            modal.find('#email_modal').val(email);
            modal.find('#alternative_email_modal').val(alternative_email);
            modal.find('#phone_modal').val(phone);
            modal.find('#alternative_phone_modal').val(alternative_phone);
            modal.find('#inter_com_nunber').val(inter_com_nunber);
            modal.find('#per_modal').val(per);
            modal.find('#id_modal').val(id);           
            modal.find('#house_type_id_edit').val(house_type);
            modal.find('#house_id_edit').append('<option value="'+house_status_id+'" >'+house_name+'</option>');
            $('#modal-loader').modal('hide');
        });
    });

    $(document).on("click", "#update_data", function() {
        $('#modal-loader').modal('show');
        $.ajax({
            url: "employee_update.php",
            type: "POST",
            cache: false,
            data: {
                id: $('#id_modal').val(),
                name: $('#name_modal').val(),
                email: $('#email_modal').val(),
                alternative_email: $('#alternative_email_modal').val(),
                phone: $('#phone_modal').val(),
                alternative_phone: $('#alternative_phone_modal').val(),
                inter_com_nunber: $('#inter_com_nunber').val(),
                p_number: $('#per_modal').val(),
                house_id_edit: $('#house_id_edit').val(),              
                old_house_id: $('#old_house_id').val(),
            },
            success: function(dataResult) {
                var dataResult = JSON.parse(dataResult);
                if (dataResult.statusCode == 200) {
                    loaddata();
                    $('#id_modal').find('input').val('');
                    $('#name_modal').find('input').val('');
                    $('#email_modal').find('input').val('');
                    $('#alternative_email_modal').find('input').val('');
                    $('#phone_modal').find('input').val('');
                    $('#alternative_phone_modal').find('input').val('');
                    $('#inter_com_nunber').find('input').val('');
                    $('#per_modal').find('input').val('');
                    $('#old_house_id').find('input').val('');
                    $('#house_id_edit').find('select').val('');
                    $('#modal-update').modal('hide');
                    swal("Employee Updated!", "", "success");
                    
                    
                    $('#modal-loader').modal('hide');
                }
            }
        });
    });
</script>

<!-- DELETE DATA  -->
<script>
    $(document).on("click", "#delete", function() {
        $('#modal-loader').modal('show');
        var dataId = $(this).attr("data-id");
        var house_status_del = $(this).attr("data-house_status_del");
        // alert(house_status_del);
        swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this !",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: "employee_delete.php",
                        type: "POST",
                        cache: false,
                        data: {
                            id: dataId,
                            house_status: house_status_del,

                        },
                        success: function(dataResult) {
                            var dataResult = JSON.parse(dataResult);
                        }
                    });

                    loaddata();
                    swal("Deleted Successfully!", {
                        icon: "success",
                    });
                } else {
                    swal("Delete Action Cancelled by User!");
                }
            });
        loaddata();
        $('#modal-loader').modal('hide');
    });
</script>
<!-- Reset Password  -->
<script>
    $(document).on("click", "#reset_password", function() {
        var dataId = $(this).attr("data-id");
        $('#modal-loader').modal('show');
        swal({
                title: "Are you sure?",
                text: "Once Reset, you will not be able to recover this imaginary Password!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: "employee_reset_password.php",
                        type: "POST",
                        cache: false,
                        data: {
                            id: dataId,
                        },
                        success: function(dataResult) {
                            var dataResult = JSON.parse(dataResult);
                        }
                    });

                    loaddata();
                    swal("Poof! Your imaginary file has been Reset!", {
                        icon: "success",
                    });
                } else {
                    swal("Your imaginary Password is safe!");
                }
            });
        loaddata();
        $('#modal-loader').modal('hide');
    });
</script>
<!-- model  -->
<script>
    $(document).ready(function() {

        $('#reservation').daterangepicker();

        $('#myModal').on('show.bs.modal', function(e) {
            $('#modal-loader').modal('show');
            $('#table_app').html("");
            var iddetails = $(e.relatedTarget).data('id');      
            $.ajax({
                method: 'POST',
                url: "get_all_data.php",
                data: {
                    'employee_house_id': iddetails  ,                               
                }
            }).done(function(data) {
                // console.log(data);
                $('#table_app').append(`<div class="modal-body1">`);
                $('#table_app').append(data);
                $('#table_app').append(`</div>`);
                $('#modal-loader').modal('hide');
            });
        });
    });
</script>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" >
    <div class="modal-dialog  modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title contenttoshow" id="abc">House</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div id="table_app">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<?php
include("layouts/footer.php");
?>