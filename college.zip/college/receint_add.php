<?php
session_start();

include("../inc/db_conn.php"); 
$myid = $_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');

foreach ($_POST['material_id'] as $key => $value) {
    $material_id =  $_POST['material_id'][$key];
    $allot_id   = $_POST['allot_id'][$key];
    $quantity   = $_POST['quantity'][$key];
 
    $EXE1   = mysqli_query($conn, "INSERT INTO txn_logs SET  material_id='$material_id', stock_userid='$allot_id',quantity='$quantity', type='OUT',out_type='Return',entry_by='$myid',datetime='$date' ");

    $EXE   = mysqli_query($conn, "INSERT INTO txn_logs SET  material_id='$material_id',  quantity='$quantity', type='IN',in_type='Return',entry_by='$myid',datetime='$date' ");

}
