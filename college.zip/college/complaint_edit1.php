<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$pg = "complaint_edit.php";
include("layouts/header.php");
$c_id = $_REQUEST['id'];
$complaint_numbwr_search = $_POST['complaint_number'];
// exit;

date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$sql1 = "SELECT complaint.* ,workman.workman_name,jobs.jobs_name,employee.name,employee.email,employee.phone,employee.id AS employee_id
FROM complaint 
LEFT JOIN workman ON complaint.allocated_to = workman.id
LEFT JOIN jobs ON complaint.type_of_job = jobs.id 
LEFT JOIN employee ON complaint.employee_id=employee.id
WHERE md5(complaint.id)='$c_id' ";
$result1 = mysqli_query($conn, $sql1);
$row1 = mysqli_fetch_assoc($result1);
$employee_id = $row1['employee_id'];
$emp_name = $row1['name'];
$emp_email = $row1['email']; 
$emp_phone = $row1['phone'];
$h_id = $row1['house_id'];
$c_discription = $row1['complaint_description'];
$estimated_date_of_completion = $row1['estimated_date_of_completion'];
$t_job = $row1['type_of_job'];
$id = $row1['id'];
$complaint_login_datetime = $row1['complaint_login_datetime'];
$complaint_status = $row1['complaint_status'];
$complaint_number = $row1['complaint_number'];
$a_to = $row1['allocated_to'];
$r_complaint = $row1['repeat_complaint'];
$allocated_datetime = $row1['allocated_datetime'];
$all_by = $row1['allocated_by'];
$complaint_l_by_id = $row1['complaint_logged_by_id'];
$complaint_l_by_type = $row1['complaint_logged_by_type'];
$complaint_photo = $row1['complaint_photo'];
$repeat_complaint_id = @$row1['repeat_complaint_id'];
$complaint_close_remarks = @$row1['complaint_close_remarks']; 
$complaint_closed_datetime = @$row1['complaint_closed_datetime']; 
$feedback1 = $row1['feedback1'];
if ($r_complaint == 'on') {
    $repeat_complaint = "YES";
} else {
    $repeat_complaint = "NO";
}

if ($complaint_l_by_type == 'Helpdesk') {
    $p12 = "SELECT * FROM user WHERE id='$complaint_l_by_id'";
    $r12 = mysqli_query($conn, $p12);
    $p112 = mysqli_fetch_assoc($r12);
    $complaint_logged_by_id = $p112['user_name'];
} else {
    $empluyeeList = mysqli_fetch_assoc(mysqli_query($conn, "SELECT name FROM employee WHERE id='$complaint_l_by_id'"));
    $complaint_logged_by_id = $empluyeeList['name'];
}
$p1 = "SELECT * FROM user WHERE id='$all_by'";
$r1 = mysqli_query($conn, $p1);
$p11 = mysqli_fetch_assoc($r1);
$allocated_by = $p11['user_name'];

// workman feedback 
$s1 = "SELECT * FROM workman_feedback WHERE id='$workman_feedback'";
$s11 = mysqli_query($conn, $s1);
$s111 = mysqli_fetch_assoc($s11);
$resolve = $s111['resolved'];
$remark = $s111['remarks'];
$complaint_datetime = $s111['complaint_datetime'];
$workman_f_id = $s111['workman_id'];
$workman_photo = $s111['image'];
// echo $workman_photo;
$workman_lat_long = $s111['lat_long'];
// echo $workman_lat_long;
$sql41 = "SELECT * FROM workman WHERE id='$workman_f_id'";
$result41 = mysqli_query($conn, $sql41);
$row41 = mysqli_fetch_assoc($result41);
$workman_feedback_id = $row41['workman_name'];

$q1 = mysqli_query($conn, "select house.id as houseID,house.house_number,house_type.house_type from house_type
    INNER JOIN house ON house.house_type = house_type.id WHERE house.id='$h_id'");
$listofAvilHouse = mysqli_fetch_assoc($q1);
$house = trim($listofAvilHouse['house_type']) . " - " . trim($listofAvilHouse['house_number']);

$sql4 = "SELECT * FROM workman WHERE id='$a_to'";
$result4 = mysqli_query($conn, $sql4);
$row4 = mysqli_fetch_assoc($result4);
$allocated_to = $row4['workman_name'];


$sql7 = "SELECT * FROM jobs WHERE id='$t_job'";
$result7 = mysqli_query($conn, $sql7);
$row7 = mysqli_fetch_assoc($result7);
$j_s_c = $row7['jobs_sub_category_id'];
$j_c = $row7['jobs_category_id'];
$job_name = $row7['jobs_name'];


$sql8 = "SELECT job_sub_category FROM job_sub_category WHERE id='$j_s_c'";
$result8 = mysqli_query($conn, $sql8);
$row8 = mysqli_fetch_assoc($result8);
$job_sub_category = $row8['job_sub_category'];

$sql9 = "SELECT id,job_category FROM job_category WHERE id='$j_c'";
$result9 = mysqli_query($conn, $sql9);
$row9 = mysqli_fetch_assoc($result9);
$job_category = $row9['job_category'];
$job_cat_id = $row9['id'];
//Status
if ($row1['complaint_status'] == 'Pending_For_Allocation') {
    $status = "Pending for Job Card";
} elseif ($row1['complaint_status'] == 'Pending_For_Workman') {
    $status = "Work in Progress";
} elseif ($row1['complaint_status'] == 'Pending_For_Closer') {
    $status = "Pending for Closure";
} elseif ($row1['complaint_status'] == 'Closer') {
    $status = "Closed";
}
?>

<style>
    .content {
        background-color: white;
    }

    .swal-content {
        overflow: auto;
    }
</style>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <br>
    <!-- Main content -->
    <section class="content">
        <form class="form-horizontal" id="add_complain" role="form" method="post" autocomplete="off" action="">
            <div id="accordion">
                <div class="card card-primary">
                    <div class="card-header">
                        <div style="float:right">
                            <input type="button" value="Print this page" onClick="window.print()">
                        </div>
                        <h4 class="card-title">
                            <a data-toggle="collapse" data-parent="#accordion" href="#Observation-Details">
                                C/<?= date('m-Y', strtotime($row1['complaint_login_datetime'])); ?>/<?= $complaint_number; ?> (<?php echo $status; ?>)
                            </a>
                        </h4>
                    </div>
                    <div id="Observation-Details" class="panel-collapse collapse show">
                        <div class="card-body">
                            <input type="hidden" value="<?= @$data['id'] ?>" name="token">
                            <input type="hidden" value="<?= @$job_category ?>" name="job_category_check">
                            <input type="hidden" value="<?= @$repeat_complaint_id ?>" name="repeat_complaint_id_check">
                            <!-- Here the Code for the Product of all the details  -->
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Employee Name</label>
                                        <input type="text" class="form-control rec" required placeholder=" Your Name" value="<?= $emp_name ?>" readonly>
                                        <input type="hidden" name="id" id="id" value="<?= $id ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="exampleInputEmail1">House Number</label>
                                        <input type="text" class="form-control rec" required readonly value="<?= $house ?>">

                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Complaint Date</label>
                                        <input type="text" class="form-control rec" required readonly value="<?= date('d-m-Y h:i A', strtotime($complaint_login_datetime)); ?>">

                                    </div>
                                    <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#myModal1" data-id="<?= $employee_id ?>" data-keyboard="false" data-backdrop="static">View Profile</button>
                                    <button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#myModal" data-id="<?= $employee_id ?>" data-keyboard="false" data-backdrop="static">View Past Occupancy</button>
                                    <?php if ($repeat_complaint_id) {
                                        $repeat_complaint_list = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * From complaint WHERE id='" . $row1['repeat_complaint_id'] . "'"));
                                    ?>

                                        <a href="complaint_edit.php?id=<?= md5($repeat_complaint_id) ?>" target="_blank"> <button type="button" class="btn btn-secondary btn-sm">Repeat Complaint(C/<?= date('m-Y', strtotime($repeat_complaint_list['complaint_login_datetime'])); ?>/<?= $repeat_complaint_list['complaint_number']; ?>)</button></a>
                                    <?php } ?>
                                </div>
                                <div class="col-md-6" id="table_fill">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Email</label>
                                        <input type="text" placeholder="Email" required readonly class="form-control rec" value="<?= $emp_email ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Mobile Number</label>
                                        <input type="number" class="form-control rec" readonly placeholder="Mobile Number" value="<?= $emp_phone ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Logged By</label>
                                        <input type="text" class="form-control rec" required readonly value="<?php echo $complaint_logged_by_id . '(' . $complaint_l_by_type . ')'; ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group row">
                                        <table class="table table-bordered table-hover table-condensed">
                                            <thead>
                                                <tr>

                                                    <th>
                                                        <div>Job Category</div>
                                                    </th>
                                                    <th>
                                                        <div>Job Sub Category</div>
                                                    </th>
                                                    <th>
                                                        <div>Job Name</div>
                                                    </th>
                                                    <th>
                                                        <div>Complaint Description</div>
                                                    </th>

                                                    <th>
                                                        <div>Allocated To<br>

                                                        </div>
                                                    </th>
                                                    <?php if ($complaint_status != 'Pending_For_Allocation') { ?>

                                                    <?php } ?>
                                                </tr>
                                            </thead>
                                            <tbody id="items_list">
                                                <tr>

                                                    <?php
                                                    if ($complaint_status != 'Pending_For_Allocation' or $repeat_complaint_id or $job_category) { ?>
                                                        <td style="width:10%">
                                                            <input type="text" name="job_category" id="job_category" class="form-control rec" readonly value="<?= $job_category ?>">
                                                        </td>
                                                        <td style="width:10%">
                                                            <input type="text" name="job_sub_category" id="job_sub_category" class="form-control rec" readonly value="<?= $job_sub_category ?>">
                                                        </td>
                                                        <td style="width:10%">
                                                            <input type="text" name="type_of_job" id="type_of_job" class="form-control rec" readonly value="<?= $job_name; ?>">
                                                        </td>
                                                    <?php } else { ?>
                                                        <?php if (in_array("allocate.php", $_SESSION['allowed_file']) || $_SESSION['role'] == '0') { ?>
                                                            <td style="width:20%">
                                                                <select name="job_category1" id="job_category1" class="form-control" required>

                                                                    <option value="">Select Job Category Type</option>
                                                                    <?php
                                                                    $sql = "SELECT * FROM job_category  WHERE is_deleted='N' ORDER BY id DESC";
                                                                    $result = $conn->query($sql);
                                                                    while ($row1 = $result->fetch_assoc()) {
                                                                    ?>
                                                                        <option value="<?= $row1['id']; ?>"><?php echo $row1['job_category']; ?></option>
                                                                    <?php
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </td>
                                                            <td style="width:20%">
                                                                <select name="job_sub_category1" id="job_sub_category1" class="form-control rec" required>
                                                                    <option value="">Select Job sub Category Type</option>

                                                                </select>
                                                            </td>
                                                            <td style="width:20%">
                                                                <select class="form-control rec producccttt" name="type_of_job1" id="type_of_job1" value="t_type" required>
                                                                    <option value="">Select Job Name</option>

                                                                </select>

                                                            </td>
                                                        <?php } ?>
                                                    <?php } ?>
                                                    </td>

                                                    <td style="width:20%">
                                                        <textarea class="form-control rec" placeholder="Complaint Description" readonly value="<?= $c_discription; ?>"><?= $c_discription; ?></textarea>
                                                        <?php
                                                        if (!$repeat_complaint_id) {
                                                            if ($complaint_status == 'Pending_For_Allocation' && $complaint_l_by_type != 'Helpdesk') {

                                                        ?>
                                                                Repeat Complaint : <input type="checkbox" id="repeat_complaint" name="repeat_complaint1">
                                                            <?php } else { ?>
                                                                Repeat Complaint <?php if ($repeat_complaint == 'NO') {
                                                                                        echo "<i class='fa fa-times'></i>";
                                                                                    } else {
                                                                                        echo "<i class='fa fa-check'></i>";
                                                                                    } ?>
                                                            <?php }
                                                        } else { ?>
                                                            Repeat Complaint <?php if ($repeat_complaint == 'NO') {
                                                                                    echo "<i class='fa fa-times'></i>";
                                                                                } else {
                                                                                    echo "<i class='fa fa-check'></i>";
                                                                                } ?>
                                                        <?php
                                                        } ?>
                                                        <?php if ($complaint_photo) { ?>
                                                            <img src="data:image/png;base64,<?= $complaint_photo ?>" width="200" height="200"><br>
                                                            <a download="file.png" href="data:image/png;base64,<?= $complaint_photo ?>" target="_blank">DOWNLOAD</a>
                                                            <!-- <a href="<?= $complaint_photo ?>"> <img src="data:image/png;base64,<?= $complaint_photo ?>" width="200" height="200"></a> -->
                                                        <?php } ?>
                                                    </td>
                                                    <td style="width:15%">
                                                        <?php
                                                        if ($complaint_status == 'Pending_For_Allocation' && !$repeat_complaint_id && !$job_category) {
                                                        ?>
                                                            <?php if (in_array("allocate.php", $_SESSION['allowed_file']) || $_SESSION['role'] == '0') { ?>
                                                                <select class="form-control rec" name="allocated_to1" id="allocated_to" required>
                                                                    <option value="">Select Workman</option>
                                                                </select>
                                                                <hr>
                                                                <label>Estimated Date of Completion</label>
                                                                <input type="text" name="find_slg" id="find_slg" placeholder="SLG" readonly class="form-control rec">
                                                            <?php } ?>
                                                            <?php } elseif (($repeat_complaint_id || $job_category) && $complaint_status != 'Pending_For_Workman') {
                                                            if (in_array("allocate.php", $_SESSION['allowed_file']) || $_SESSION['role'] == '0') { ?>
                                                                <select class="form-control rec" name="allocated_to1" id="allocated_to" required>
                                                                    <?php
                                                                    $workman_o_query = mysqli_query($conn, "SELECT workman.id,workman.workman_name 
                                                                    FROM job_category
                                                                    LEFT JOIN job_workman ON job_category.id=job_workman.job_category_id
                                                                    LEFT JOIN workman ON job_workman.workman_id = workman.id 
                                                                    WHERE job_category.job_category='$job_category' GROUP BY workman.id");
                                                                    ?>
                                                                    <option value="">Select Workman</option>
                                                                    <?php
                                                                    while ($workman_o_list = mysqli_fetch_assoc($workman_o_query)) {
                                                                        $id_count = $workman_o_list['id'];
                                                                        $rowcount = mysqli_fetch_assoc(mysqli_query($conn, "SELECT count(allocated_to) AS pending_job FROM complaint  WHERE allocated_to = '$id_count' AND complaint_status!='Closer'"));

                                                                    ?>
                                                                        <option value="<?= $workman_o_list['id']; ?>" <?php if ($workman_o_list['id'] == $a_to) {
                                                                                                                            echo "selected";
                                                                                                                        } ?>><?= $workman_o_list['workman_name']; ?> (Pending Jobs - <?= $rowcount['pending_job']; ?>) </option>
                                                                    <?php
                                                                    }
                                                                    ?>
                                                                </select>
                                                                <hr>
                                                                <label>Estimated Date of Completion</label>
                                                                <input type="text" readonly class="form-control rec" value="<?= date('d-m-Y', strtotime($estimated_date_of_completion)) ?>">
                                                            <?php }
                                                        } else { ?>
                                                            <input type="text" readonly class="form-control rec" value="<?= $allocated_to ?>">
                                                            <hr>
                                                            <label>Estimated Date of Completion</label>
                                                            <input type="text" readonly class="form-control rec" value="<?= date('d-m-Y', strtotime($estimated_date_of_completion)) ?>">
                                                        <?php } ?>
                                                        <?php
                                                        if ($allocated_by) {
                                                            echo "<font size='2'>(Allocated by : <i>$allocated_by</i> on <i>" . date('d-m-Y h:i A', strtotime($allocated_datetime)) . "</i>)</font>";
                                                        } ?>
                                                    </td>

                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                $workman_feedbackQuery = mysqli_query($conn, "SELECT workman_feedback.* ,workman.workman_name 
                                FROM workman_feedback 
                                LEFT JOIN workman ON workman_feedback.workman_id= workman.id 
                                WHERE workman_feedback.complaint_id='$id'");
                while ($workman_feedbackList = mysqli_fetch_assoc($workman_feedbackQuery)) {
                    $workman_location = $workman_feedbackList['lat_long'];
                    if ($workman_feedbackList['id']) {
                ?>


                        <div class="card card-primary">
                            <div class="card-header">
                                <h4 class="card-title">
                                    <a data-toggle="collapse" data-parent="#accordion" href="#C-Details">
                                        Response from Workman
                                    </a>
                                </h4>
                            </div>
                            <div id="C-Details" class="panel-collapse collapse show">
                                <div class="card-body">

                                    <table class="table table-bordered table-hover table-condensed">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">Resolve</label>
                                                    <input type="text" placeholder="Resolve" required readonly class="form-control rec" value="<?= $workman_feedbackList['resolved'] ?>">
                                                </div>

                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">Remarks</label>
                                                    <input type="text" placeholder="Remarks" required readonly class="form-control rec" value="<?= $workman_feedbackList['remarks'] ?>">
                                                </div>
                                                <?php if ($workman_feedbackList['image']) { ?>
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Image</label>
                                                        <div>
                                                            <img src="data:image/png;base64,<?= $workman_feedbackList['image'] ?>" width="500" height="400">
                                                        </div>
                                                    </div>
                                                <?php } ?>
                                                <?php if ($workman_feedbackList['employee_feedback']) { ?>
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Employee Feedback</label><br>
                                                        <?php if ($workman_feedbackList['employee_feedback'] == 1) {
                                                            echo  "Un-Satisfactory";
                                                        } elseif ($workman_feedbackList['employee_feedback'] == 2) {
                                                            echo "Average";
                                                        } elseif ($workman_feedbackList['employee_feedback'] == 3) {
                                                            echo "Good";
                                                        } elseif ($workman_feedbackList['employee_feedback'] == 4) {
                                                            echo "V-Good";
                                                        } elseif ($workman_feedbackList['employee_feedback'] == 5) {
                                                            echo "Excellence";
                                                        }
                                                        ?>
                                                    </div>

                                                <?php } ?>
                                            </div>
                                            <div class="col-md-6" id="table_fill">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">Completed Date</label>
                                                    <input type="text" placeholder="Completed Date" required readonly class="form-control rec" value="<?= date('d-m-Y h:i A', strtotime($workman_feedbackList['complaint_datetime'])) ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">Completed By</label>
                                                    <input type="text" placeholder="Completed By" required readonly class="form-control rec" value="<?= $workman_feedbackList['workman_name'] ?>">
                                                </div>
                                                <?php
                                                $latlong = $workman_feedbackList['lat_long'];
                                                if ($latlong) {
                                                ?>
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Location</label>
                                                        <?php
                                                        // echo $latlong;
                                                        $latlong = explode(",", $latlong);
                                                        ?>
                                                        <script>
                                                            $(document).ready(function() {
                                                                loadMap();
                                                            });
                                                        </script>
                                                        <div id="sample" style="width:100%; height:400px;"></div>
                                                    </div>
                                                <?php
                                                }
                                                if ($workman_feedbackList['employee_remarks']) {
                                                ?>
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Employee Remarks</label><br>
                                                        <?= $workman_feedbackList['employee_remarks'] ?>
                                                    </div>
                                                <?php } ?>
                                            </div>

                                        </div>
                                    </table>
                                </div>
                            </div>
                        </div>
                <?php }
                } ?>
                <?php
                $materialquery = mysqli_query($conn, "SELECT txn_logs.quantity ,material.material_name 
                                        FROM txn_logs
                                        LEFT JOIN material ON txn_logs.material_id = material.id
                                        WHERE txn_logs.complaint_id='$id' GROUP BY txn_logs.id");

                if (mysqli_num_rows($materialquery) != 0) {
                ?>
                    <div class="card card-primary">
                        <div class="card-header">
                            <h4 class="card-title">
                                <a data-toggle="collapse" data-parent="#accordion" href="#M-Details">
                                    Material Consumption
                                </a>
                            </h4>
                        </div>
                        <div id="M-Details" class="panel-collapse collapse show">
                            <div class="card-body">
                                <h3>Material Used</h3>
                                <table class="table table-bordered table-hover table-condensed">
                                    <tr>
                                        <th>Material Name</th>
                                        <th>Stock</th>
                                    </tr>
                                    <?php
                                    while ($materiallist = mysqli_fetch_assoc($materialquery)) {

                                    ?>
                                        <tr>
                                            <td><?= $materiallist['material_name'] ?></td>
                                            <td><?= $materiallist['quantity'] ?></td>
                                        </tr>
                                    <?php } ?>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php } ?>
                <?php if($complaint_close_remarks){ ?>
                <div class="card card-primary">
                    <div class="card-header">
                        <h4 class="card-title">
                            <a data-toggle="collapse" data-parent="#accordion" href="#C-Details">
                                Close Remarks
                            </a>
                        </h4>
                    </div>
                    <div class="modal-body">
                    <div class="form-group">
                        <label for="exampleInputPassword1">Remarks</label>
                        <textarea name="remarks" class="form-control" readonly><?=$complaint_close_remarks?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Close Date</label>
                       <input type="text" class="form-control" readonly value="<?=@$complaint_closed_datetime ?>" >
                    </div>
                </div>
                <?php } ?>
            </div>
            <div class="form-group">
                <?php
                if ($complaint_status == 'Pending_For_Allocation') {
                ?>
                    <?php if (in_array("allocate.php", $_SESSION['allowed_file']) || $_SESSION['role'] == '0') { ?>
                        <div class="form-group">
                            <center><input type="submit" id="add_form" name="save" value="Log Complaint" class="btn btn-primary" />&nbsp;&nbsp;
                                <button type="button" class="btn btn-danger  update" data-toggle="modal" data-keyboard="false" data-backdrop="static" data-target="#myModal11" data-id="<?= $id; ?>">Close Complaint</button>
                            </center>

                        </div>
                    <?php } ?>
                <?php } ?>
            </div>
        </form>
    </section>
</div>


<!-- /.content-wrapper -->

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->


<?php
include("layouts/footer.php");
?>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<!-- <script src="https://unpkg.com/sweetalert2@7.19.3/dist/sweetalert2.all.js"></script> -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC227pY8VAIHyN_y4s1IeRtLqiBJcaC_Mo"></script>

<script>
    $(document).ready(function() {
        $('#type_of_job1').select2();
        $('#job_sub_category1').select2();
        $('#allocated_to').select2();
        $('#job_category1').select2();

        $(document).on('submit', '#add_complain', function(e) {
            $('#modal-loader').modal('show');
            e.preventDefault();
            $.ajax({
                method: "POST",
                url: "complaint_edit_add.php",
                //    data: $(this).serialize(),
                data: $('#add_complain').serialize(),
                success: function(data) {
                    $('#modal-loader').modal('hide');
                    swal("Job Card Created!", "", "success");
                    window.location.href = 'view_all_complaint.php';
                }
            });
        });



        $('#job_category1').on('change', function() {
            $('#modal-loader').modal('show');
            var id = $(this).val();
            $.ajax({
                type: "POST",
                url: "get_all_data.php",
                data: {
                    'job_cat_id': id,
                },
                beforeSend: function() {
                    // $("#job_category").html("");
                    $("#job_sub_category1").html("");
                    $("#type_of_job1").html("");
                    $("#find_slg").html("");

                },
                success: function(data) {
                    $('#add_complain').find('#job_sub_category1').html(data);
                    job_category_select1();
                    $('#modal-loader').modal('hide');
                }
            });
        });
        $('#job_sub_category1').on('change', function() {
            $('#modal-loader').modal('show');
            $.ajax({
                type: "POST",
                url: "get_all_data.php",
                data: {
                    'job_sub_cat_id': $(this).val(),
                },
                beforeSend: function() {
                    //  $("#job_category").html("");
                    // $("#job_sub_category1").html("");
                    $("#type_of_job1").html("");
                    $("#find_slg").html("");

                },
                success: function(data) {
                    $('#add_complain').find('#type_of_job1').html(data);
                    $('#modal-loader').modal('hide');
                }
            });
        });

        $('#type_of_job1').on('change', function() {
            $('#modal-loader').modal('show');
            $.ajax({
                type: "POST",
                url: "get_all_data.php",
                data: {
                    'job_id': $(this).val(),
                },
                beforeSend: function() {

                    $("#find_slg").html("");

                },
                success: function(data) {
                    $('#add_complain').find('#find_slg').val(data);
                    // $(th).closest('tr').find('#find_slg').val(parsed_data.slg);    
                    $('#modal-loader').modal('hide');
                }
            });
        });



        function job_category_select1() {
            $('#modal-loader').modal('show');
            var id = $('#job_category1').val();
            $.ajax({
                type: "POST",
                url: "get_all_data.php",
                data: {
                    'job_cat_id_w': id,
                },
                beforeSend: function() {
                    $("#allocated_to").html("");
                },
                success: function(data) {
                    $('#add_complain').find('#allocated_to').html(data);
                    $('#modal-loader').modal('hide');
                }
            });

        }
    });

    <?php if ($workman_location) { ?>


        function loadMap() {
            var mapOptions = {
                center: new google.maps.LatLng(<?= @$latlong[0] ?>, <?= @$latlong[1] ?>),
                zoom: 14
            }
            var map = new google.maps.Map(document.getElementById("sample"), mapOptions);
            var marker = new google.maps.Marker({
                position: new google.maps.LatLng(<?= @$latlong[0] ?>, <?= @$latlong[1] ?>),
                map: map,
            });
        }
    <?php  } ?>
</script>


<div class="modal" id="modal-loader" style="z-index:1000000000">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body" style="z-index:1000000000">
                <img class="mx-auto d-block" src="dist/img/loader.gif" />
                <p class="text-center">Please Wait</p>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

<script>
    $(document).ready(function() {
        $('#myModal').on('show.bs.modal', function(e) {
            $('#modal-loader').modal('show');
            $('#table_app').html("");
            var iddetails = $(e.relatedTarget).data('id');
            $.ajax({
                method: 'POST',
                url: "get_all_data.php",
                data: {
                    'employee_house_id': iddetails,
                }
            }).done(function(data) {
                // console.log(data);

                $('#table_app').append(`<div class="modal-body1">`);
                $('#table_app').append(data);
                $('#table_app').append(`</div>`);
                $('#modal-loader').modal('hide');
            });
        });
    });
</script>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-xl modal-dialog modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title contenttoshow" id="abc">House</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div id="table_app">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<!-- model  -->
<script>
    $(document).ready(function() {
        $('#myModal1').on('show.bs.modal', function(e) {
            $('#modal-loader').modal('show');
            $('#table_app').html("");
            var iddetails = $(e.relatedTarget).data('id');
            $.ajax({
                method: 'POST',
                url: "get_all_data.php",
                data: {
                    'employee_information_id': iddetails,
                }
            }).done(function(data) {

                // console.log(data);
                $('#table_app1').append(`<div class='modal-body1'>`);
                $('#table_app1').html(data);
                $('#table_app1').append(`</div>`);
                $('#modal-loader').modal('hide');
            });
        });
    });
</script>
<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog  modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title contenttoshow" id="abc">Employee Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div id="table_app1">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<script>
    $('.update').on('click', function() {
        $('#myModal11').modal('show');
        $('#myModal11').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget); /*Button that triggered the modal*/
            var id = button.data('id');
            var modal = $(this);
            modal.find('#complaint_c_id').val(id);
        })
    });
    $(document).on('submit', '#userForm', function(e) {
        $('#modal-loader').modal('show');
        e.preventDefault();
        $.ajax({
            method: "POST",
            url: "complaint_edit_close.php",
            //    data: $(this).serialize(),
            data: $('#userForm').serialize(),
            success: function(data) {
                $('#modal-loader').modal('hide');
                swal("Complaint Close", "", "success");
                window.location.href = 'view_all_complaint.php';
            }
        });
    });
</script>
<div class="modal fade" id="myModal11" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog  modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title contenttoshow" id="abc">Complaint Close Detail</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form class="form-horizontal" role="form" method="post" autocomplete="off" id="userForm" action="">
                <input type="hidden" id="complaint_c_id" name="id">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="exampleInputPassword1">Remarks</label>
                        <textarea name="remarks" class="form-control" required placeholder="Remarks"></textarea>

                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary" id="update_data">Update</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>