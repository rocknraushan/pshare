<?php
include "inc/header.php";
include "../inc/db_conn.php";

// delete role
if(isset($_REQUEST['roleUniqueID']))
{         
    // $delrole       = base64_decode(urldecode($_REQUEST['roleUniqueID']));
    $delrole       = $_REQUEST['roleUniqueID'];
    $querycheck   = "SELECT * FROM user WHERE role='$delrole'";
    $queryexecute = mysqli_query($conn,$querycheck);
    $row1 =  mysqli_fetch_assoc($queryexecute);
    $found_id=$row1['id'];
    if($found_id){ ?>
        <script>
            swal({
                title: "Role Already Assigned to User",
                text:   "", 
                type: "error", 
                }, function(){
                    window.location = "permission.php"; 
                });
        </script>
<?php 
    }
    else{
    $querycheck1 = "SELECT * FROM role_master WHERE rolename='$delrole'";
    $queryexecute1 = mysqli_query($conn,$querycheck1);
    $row11 =  mysqli_fetch_assoc($queryexecute1);
    $del_id=$row11['id'];
        $deleteRole= mysqli_query($conn,"DELETE FROM role_master WHERE rolename='$delrole'"); 

        $deletePermission  = mysqli_query($conn,"DELETE FROM role_permission WHERE role_master_id ='$del_id'"); 
        if(($deleteRole && $deletePermission) == true){  ?>
            <script>
                swal({
                    title: "Deleted",
                    text:   "", 
                    type: "success",
                    }, function(){
                        window.location = "permission.php";
                    });
            </script>
        <?php }
    }
    ?>
<?php
} 
?>


<!-- List of all Roles  -->
<div class="panel">
    <header class="panel-heading">
    <h3 class="panel-title">List of Roles <h3>
    </header>
    <div class="panel-body">
        <div class="row">
            <div class="col-md-6">
                <div class="" style="margin-left:185%;">
                    <a href="create-permission.php" class="btn btn-primary">Add Role</a>
                </div>
            </div>
        </div>
        <table class="table table-hover dataTable table-striped w-full" data-plugin="dataTable">
            <thead>
              <tr>
                <th>#</th>
                <th>Role</th>
                <th>Permission</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
                <?php $count = 1; 
                    // Load all data in Table 
                    $getRolename    = mysqli_query($conn,"SELECT * FROM role_master");
                    if(isset($getRolename)){
                        while($row = mysqli_fetch_assoc($getRolename)){ ?>
                        <tr>
                            <td><?php echo $count++; ?> </td>
                            <td><?php echo $row['rolename']; ?> </td>  
                            <td>
                                <?php 
                                $roleid = $row['id'];
                                $query ="SELECT permission_master.name FROM role_permission INNER JOIN permission_master ON role_permission.permission_master_id = permission_master.id WHERE role_master_id='$roleid'";
                                $run  = mysqli_query($conn,$query); 
                                while($row1 =  mysqli_fetch_assoc($run)){ ?>
                                <?php  echo $row1['name']; ?><br>
                                <?php } ?> 
                            </td> 
                            <td>
                                <a href="create-permission.php?editid=<?php echo urlencode(base64_encode($row['id'])); ?>" class="btn btn-sm btn-icon"
                                    data-toggle="tooltip" data-original-title="Edit"><i class="icon wb-edit" aria-hidden="true"></i>
                                </a>
                                <a href="#" class="btn btn-sm btn-icon btnSweetalert"  
                                data-delid="<?php echo $row['rolename'] ?>" data-toggle="tooltip" data-original-title="Remove"><i class="icon wb-trash" aria-hidden="true"></i></a>
                            </td>                                    
                        </tr>
                    <?php }
                    } else { ?>
                    <tr>
                    <td colspan="4" style="color:red;text-align:center;">NA</td>
                    <tr>
                <?php  } ?>
            </tbody>
        </table>
    </div>
</div>
<?php
include "inc/footer.php";
?>
<script type="text/javascript">
    $('.btnSweetalert').on("click", function () {
        var delUniqueID = $(this).data('delid');
        // alert(delUniqueID);
        swal({
                title: "Are you sure you want to delete this Role?",
                text: "After you delete this Role you will not able to get this!",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Yes",
                cancelButtonText: "No",
                closeOnConfirm: false,
                closeOnCancel: false
            },
            function (isConfirm) {
                if (isConfirm) {
                    $.ajax({
                        url: 'permission.php',
                        async: false,
                        cache: false,
                        type: 'get', 
                        data: {roleUniqueID: delUniqueID},
                        success: function (data) {
                            // window.location = "permission.php?roleUniqueID="+delUniqueID;
                            window.location = "permission.php?roleUniqueID="+delUniqueID;
                        }
                    });
                } else {
                    <?php echo urlencode(base64_encode($row['id'])); ?>
                        // var jsString = '<div id="content">'+'<?php //echo $something['1'] ;?>'+'</div>';
                        //     alert(jsString);
                    swal("Cancelled", "Something went wrong. Please try again.)", "error");
                }
        });
    });
   
</script>