<?php
// include "inc/header.php";
// include "../inc/db_conn.php";
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
// $head="masters";
// $head1="employee"; 
// $page="role";
include("layouts/header.php");
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
if(isset($_POST['submit'])){
        $role_name    =  $_POST['role_name'];
        $permissionid  =  $_POST['permission_master_id'];

        if(!empty( $_POST['permission_master_id'] ) && !count( array_filter($_POST['permission_master_id'])) == 0 ) 
        {
            // for update the permissison
            if($_POST['unique_id']){
                $roleuniqueid = $_POST['unique_id'];
                $insertrole = mysqli_query($conn,"UPDATE role_master SET rolename ='$role_name' WHERE id='$roleuniqueid'");
                $deleteQuery = "DELETE FROM role_permission WHERE role_master_id='$roleuniqueid'"; 
                $delete  = mysqli_query($conn, $deleteQuery);

                foreach($permissionid as $key => $value){
                    // echo "key " .$key;
                    // echo "value "  .$value;
                    $query ="INSERT INTO role_permission (role_master_id,permission_master_id) 
                            VALUES ('$roleuniqueid','$value')"; 
                    $RolePermission = mysqli_query($conn,$query);
                }
            }
            // for insert the permissison
            else{
                $insertrole = mysqli_query($conn,"INSERT INTO role_master (rolename) VAlUES ('$role_name')");
                $roleidgenerate   = mysqli_insert_id($conn);
                foreach($permissionid as $key => $value){
                    // echo "key " .$key;
                    // echo "value "  .$value;
                    $query ="INSERT INTO role_permission (role_master_id,permission_master_id) 
                            VALUES ('$roleidgenerate','$value')"; 
                    $RolePermission = mysqli_query($conn,$query);
                }
            }
        }
        if(($insertrole && $RolePermission) == true){  ?>
            <script>
                swal({
                    title: "Saved",
                    text: "", 
                    type: "success",
                    html: true,
                    }, function(){
                        window.location = "permission.php";
                    });
            </script>
        <?php } else { ?>
            <script>
                swal({
                    title: "Not Saved",
                    text:  "Please Fill Details", 
                    type: "error",
                    }, function(){
                        window.location = "permission.php";
                    });
            </script>
        <?php  }
}
if(isset($_REQUEST['editid'])){
    // $id =  $_REQUEST['editid'];
    $id            = base64_decode(urldecode($_REQUEST['editid']));
    $getRoledata   = mysqli_query($conn,"SELECT * FROM role_master WHERE id='$id'");
    $roleid        = mysqli_fetch_assoc($getRoledata);
}
?>
<!-- Page -->
<div class="page">
    <div class="page-content container-fluid">
        <div class="row" data-plugin="matchHeight" data-by-row="true">
            <div class="col-xl-12">
                <div class="panel">
                <form method="POST" action="create-permission.php" autocomplete="off">
                    <div class="panel-body">
                        <div class="example-wrap">
                          <h4 class="example-title">Create New Permission</h4>
                            <div class="example">
                                <div class="row">
                                    <input type="hidden"  value="<?php echo $roleid['id']?>" name="unique_id">
                                    <div class="form-group col-md-6">
                                        <label class="form-control-label" for="">Role Name: </label>
                                        <input type="text" name="role_name" class="form-control round" value="<?php echo $roleid['rolename']?>" required>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label class="form-control-label" for="">List of Permission:</label><br>
                                        <?php
                                            // roleid admin,user,admin_user,mess_user
                                            $roleid    = $roleid['id'];
                                            $rolename  = mysqli_query($conn,"SELECT * FROM role_permission WHERE role_master_id='$roleid'");
                                            $role = array();
                                            while($row = mysqli_fetch_assoc($rolename)){ 
                                                $role[] = $row['permission_master_id'];
                                                // print_r($role);
                                                // echo  $role['id'];
                                            }
                                            $getfiles="SELECT * FROM permission_master";
                                            $execute = mysqli_query($conn,$getfiles);
                                            while($row = mysqli_fetch_assoc($execute)){ ?>
                                                <input type="checkbox" name="permission_master_id[]" <?php if(array_intersect($role,$row))  echo 'checked'; ?> value="<?php echo $row['id'] ?>" >&nbsp;&nbsp;&nbsp;<label for=""> <?php echo $row['name']."\t(". $row['file_name'] . ")" ?> </label><br>                                           
                                            <?php   }     ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <center><button type="submit" name="submit" class="btn btn-primary">Submit</button></center>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Page -->
<?php
include "inc/footer.php";
?>
<script type="text/javascript">
    
</script>
