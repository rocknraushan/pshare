<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$head="masters";
$head1="employee";
$page="user";
include("layouts/header.php");

?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h3 class="m-0">Masters/User</h3>
                </div>
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div><!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header border-0">
                            <div class="d-flex justify-content-between">
                                User
                                <div style="float:right">
                                    <a href="#" class="btn btn-success btn-sm" data-toggle="modal" data-target="#exampleModal">Add New</a>
                                </div>
                            </div>
                        </div>

                        <div class="card-body">
                            <div class="alert alert-success alert-dismissible" id="success" style="display:none;">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                            </div>
                            <table id="example1" class="table table-bordered table-sm">
                                <thead>
                                    <tr>
                                        <th>Sl No.</th>
                                        <th>User name</th>
                                        <th>Email</th>                                       
                                        <th>Mobile</th>
                                        <th>Role</th> 
                                        <th>Reset Password</th>                                      
                                        <th>Edit </th>
                                        <th>Delete</th>
                                    </tr>
                                </thead>
                                <tbody id="table">

                                </tbody>
                            </table> 

                            <script type="text/javascript">
                                $(document).ready(function() {
                                    loaddata();
                                });

                                function loaddata() {
                                    $('#modal-loader').modal('show');
                                    $.ajax({
                                        url: 'user_view.php',
                                        type: 'POST',
                                        dataType: 'html',
                                        success: function(newContent) {
                                            $('#table').html('');
                                            $('#table').append(newContent);
                                            $('#modal-loader').modal('hide');
                                            $('#example1').DataTable();
                                        }
                                    });
                                }
                            </script>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- /.content -->
    <!-- /.content-wrapper -->
</div>
</div>

</body>


<div class="modal" id="modal-loader" style="z-index:1000000000">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body" style="z-index:1000000000">
                <img class="mx-auto d-block" src="dist/img/loader.gif" />
                <p class="text-center">Please Wait</p>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

<div class="modal" id="exampleModal">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">User</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form class="form-horizontal" role="form" method="post" autocomplete="off" id="userForm" action="">
                <div class="modal-body">
                    <input type="hidden" value="<?= @$data['id'] ?>" name="token">               
                    <div class="form-group">
                        <label for="exampleInputPassword1">User Name</label>
                        <input type="text" name="user_name" class="form-control rec"  id="" placeholder="User Name" required>
                    </div>                    
                    <div class="form-group">
                        <label for="exampleInputEmail1"> Email ID.</label>
                        <input type="email" name="email" class="form-control rec" value="<?= @$data['email'] ?>" id="" placeholder="Email ID" required>
                    </div>                   
                    <div class="form-group">
                        <label for="exampleInputEmail1"> Mobile No.</label>
                        <input type="number" name="phone" class="form-control rec" id=" " placeholder="Mobile" required min="1">
                    </div> 
                    <div class="form-group">
                        <label for="exampleInputEmail1"> Role</label>
                        <select name="role" class="form-control rec" id=" " placeholder="Role" required >
                        <option value="" >Select Role</option>
                        <option value="0" >Super Admin</option>
                        <?php 
                            $result1 = mysqli_query($conn,"SELECT id,rolename  FROM role_master WHERE is_deleted='N'");
                            while($row1 = mysqli_fetch_assoc($result1)){
                            ?>
                                <option value="<?= $row1['id']; ?>"><?= $row1['rolename']; ?></option>
                            <?php
                            }
                        ?>
                        </select>
                    </div>                  
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" id="submit_request" onSubmit="add(event)">Submit</button>
                </div>
        </div>
        </form>
    </div>
</div>
</div>

<script>
    $(document).on('submit', '#userForm', function(e) {
        $('#modal-loader').modal('show');
        $('#submit_request').prop('disabled', true);
        e.preventDefault();
        $.ajax({
            method: "POST",
            url: "user_add.php",
            data: $(this).serialize(),
            success: function(data) {
                $('#modal-loader').modal('hide');
                $('#exampleModal').modal('hide');
                $('#userForm').find('input').val('');
                $('#userForm').find('select').val('');
                loaddata();
                swal("User Saved!", "", "success");
                $('#submit_request').prop('disabled', false);
            }
        });
    });
</script>


<!-- UPATE  DATA -->
<!-- Modal Update-->
<div class="modal fade" id="modal-update">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Update user</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            <input type="hidden" name="id_modal" id="id_modal" class="form-control" required>
                <!--1-->
                <div class="form-group">
                    <label for="exampleInputPassword1">Name</label>
                    <input type="text" name="name_modal" id="name_modal" class="form-control" required>
                </div>
                <!--2-->
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email_modal" id="email_modal" class="form-control" required>
                </div>
                
                <!--3-->
                <div class="form-group">
                    <label>Phone</label>
                    <input type="number" name="phone_modal" id="phone_modal" class="form-control" required min="1">
                </div>  
                <!-- 4 -->
                <div class="form-group">
                        <label for="exampleInputEmail1"> Role</label>
                        <select id="role_modal" class="form-control rec" id=" " placeholder="Role" required >
                        <option value="" >Select Role</option>
                        <option value="0">Super Admin</option>
                        <?php 
                            $result1 = mysqli_query($conn,"SELECT id,rolename  FROM role_master WHERE is_deleted='N'");
                            while($row1 = mysqli_fetch_assoc($result1)){
                            ?>
                                <option value="<?= $row1['id']; ?>"><?= $row1['rolename']; ?></option>
                            <?php
                            }
                        ?>
                        </select>
                    </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary" id="update_data">Update</button>
            </div>
        </div>
    </div>
</div>
</div>
<!-- Modal End-->
<script>
    $(function() {
        $('#modal-update').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget); /*Button that triggered the modal*/
            var id = button.data('id');
            var name = button.data('name');
            var email = button.data('email');
            var phone = button.data('phone');
            var role = button.data('role');
            
            var modal = $(this);  
            modal.find('#id_modal').val(id);         
            modal.find('#name_modal').val(name);
            modal.find('#email_modal').val(email);           
            modal.find('#phone_modal').val(phone);    
            modal.find('#role_modal').val(role);         
        });
    });

    $(document).on("click", "#update_data", function() {
        $('#modal-loader').modal('show');
       // alert($('#id_modal').val());
        $.ajax({
            url: "user_update.php",
            type: "POST",
            cache: false,
            data: {
                id: $('#id_modal').val(),
                user_name: $('#name_modal').val(),
                email: $('#email_modal').val(),                
                phone: $('#phone_modal').val(), 
                role: $('#role_modal').val(),               
            },
            success: function(dataResult) {
                var dataResult = JSON.parse(dataResult);
                if (dataResult.statusCode == 200) {
                    $('#modal-loader').modal('hide');
                    $('#modal-update').modal('hide');
                    swal("User Updated!", "", "success");
                    loaddata();
                }
            }
        });
    });
</script>

<!-- DELETE DATA  -->
<script>
    $(document).on("click", "#delete", function() {
        var dataId = $(this).attr("data-id");
        swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this !",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: "user_delete.php",
                        type: "POST",
                        cache: false,
                        data: {
                            id: dataId,
                        },
                        success: function(dataResult) {
                            var dataResult = JSON.parse(dataResult);
                        }
                    });

                    loaddata();
                    swal("Deleted Successfully!", {
                        icon: "success",
                    });
                } else {
                    swal("Delete Action Cancelled by User!");
                }
            });
        loaddata();
    });
</script>

<!-- Reset Password  -->
<script>
    $(document).on("click", "#reset_password", function() {
        var dataId = $(this).attr("data-id");
        swal({
                title: "Are you sure?",
                text: "Once Reset, you will not be able to recover this imaginary Password!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: "user_reset_password.php",
                        type: "POST",
                        cache: false,
                        data: {
                            id: dataId,
                        },
                        success: function(dataResult) {
                            var dataResult = JSON.parse(dataResult);
                        }
                    });

                    loaddata();
                    swal("Password Reset Successfully", {
                        icon: "success",
                    });
                } else {
                    swal("Password Reset Action Cancelled by User!");
                }
            });
        loaddata();
    });
</script>
<script>
    $(document).ready(function() {

        $('#reservation').daterangepicker();

        $('#myModal').on('show.bs.modal', function(e) {
            $('#table_app').html("");
            var iddetails = $(e.relatedTarget).data('id');      
            $.ajax({
                method: 'POST',
                url: "get_all_data.php",
                data: {
                    'user_role_id': iddetails  ,
                    user_role_data_show:"hii"              
                }
            }).done(function(data) {
                // console.log(data);
                $('#table_app').append(`<div class="modal-body1">`);
                $('#table_app').append(data);
                $('#table_app').append(`</div>`);
            });
        });
    });
</script>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" >
    <div class="modal-dialog  modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title contenttoshow" id="abc">Details </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div id="table_app">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<?php
include("layouts/footer.php");
?>