<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");	
$myid=$_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');
	$id=$_POST['id'];
	$sql = "UPDATE  `job_workman` SET is_deleted='Y', deleted_by='$myid',deleted_date_time='$date'  WHERE `id`='$id'";
	
	if (mysqli_query($conn, $sql)) {
		echo json_encode(array("statusCode"=>200));
	} 
	else {
		echo json_encode(array("statusCode"=>201));
	}
	mysqli_close($conn); 
?>  