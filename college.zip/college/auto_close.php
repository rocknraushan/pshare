<?php
session_start();
include("../inc/db_conn.php");
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$start = date('Y-m-d H:i:s');
$complaintQuery=mysqli_query($conn,"SELECT id FROM `complaint` WHERE complaint_status='Pending_For_Closer'");
while($complaintList=mysqli_fetch_assoc($complaintQuery)){
    $feedbackList=mysqli_fetch_assoc(mysqli_query($conn,"SELECT `complaint_datetime` FROM workman_feedback WHERE `complaint_id`='".$complaintList['id']."' ORDER BY id DESC LIMIT 1"));  
    $end = $feedbackList['complaint_datetime'];
    $diff = abs(strtotime($start) - strtotime($end)); 
    $years   = floor($diff / (365*60*60*24)); 
    $months  = floor(($diff - $years * 365*60*60*24) / (30*60*60*24)); 
    $days    = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));

    $hours   = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24)/ (60*60)); 

    $minuts  = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24 - $hours*60*60)/ 60); 
    
    $time1= $hours+$days*24;
    if($time1>=24){
        mysqli_query($conn,"UPDATE  `complaint` SET complaint_status='Closer'  WHERE `id`='".$complaintList['id']."'");
    } 
}
?>