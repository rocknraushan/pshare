<?php
session_start();
include("../inc/db_conn.php");
//$db=$conn;// database connection  
$myid=$_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');
$jobs_category_id   = $_POST['job_category'];
$jobs_sub_category_id   = $_POST['job_sub_category'];
$jobs_name= $_POST['jobs_name'];
$slg=$_POST['slg'];
// SELECT `id`, `jobs_category_id`, 
// `jobs_sub_category_id`, `jobs_name`,
//  `slg`, `created_by`, `updated_by`, 
//  `created_date_time`, `updated_date_time`,
//   `is_deleted`, `deleted_by`,
//    `deleted_date_time` FROM `jobs` WHERE 1


$EXE   = mysqli_query($conn, "INSERT INTO `jobs`( `jobs_category_id`, `jobs_sub_category_id`, `jobs_name`, `slg`, `created_by`, `created_date_time`) VALUES ('$jobs_category_id','$jobs_sub_category_id','$jobs_name','$slg','$myid','$date')");
if($execute){

//echo "Hii";
} 
