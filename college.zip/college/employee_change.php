<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$myid = $_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');

$house_ty_id = $_POST['house_ty_id'];
$house_ty_id_edit = $_POST['house_ty_id_edit'];
if ($house_ty_id) {
    $sql1 = "SELECT * FROM house WHERE house_type='$house_ty_id'  AND house_status='Non-Active'";
    $result1 = mysqli_query($conn, $sql1);
    ?>
    <option value="">Select House Number </option>
    <?php
    while ($row1 = mysqli_fetch_assoc($result1)) {
?>
        <option value="<?= $row1['id']; ?>"><?= $row1['house_number']; ?></option>
<?php
    }
}
elseif ($house_ty_id_edit) {
    $sql1 = "SELECT * FROM house WHERE house_type='$house_ty_id_edit' AND house_status='Non-Active'";
    $result1 = mysqli_query($conn, $sql1); ?>
    <option value="">Select House Number </option>
    <?php
    while ($row1 = mysqli_fetch_assoc($result1)) {
?>
        <option value="<?= $row1['id']; ?>"><?= $row1['house_number']; ?></option>
<?php
    }
}

?>