<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");	
$myid=$_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');
	$id=$_POST['id'];
	$job_category=$_POST['job_category'];
	
	$sql = "UPDATE `job_category` SET `job_category`='$job_category', updated_by='$myid',updated_date_time='$date' WHERE `id`='$id'";
	if (mysqli_query($conn, $sql)) {
		echo json_encode(array("statusCode"=>200));
	} 
	else {
		echo json_encode(array("statusCode"=>201));
	}
	mysqli_close($conn); 
?> 