<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$head="inventory";
$page="receipt_supplier";
include("layouts/header.php");

?>
<style>
    .content{
        background-color: white;
    }
    .swal-content{
        overflow: auto;
    }
</style>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h3 class="m-0">Receipt from Supplier</h3>
                </div>
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div><!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <form class="form-horizontal" role="form" method="post" autocomplete="off" id="userForm" action="">
                                <div class="modal-body">
                                    <input type="hidden" value="<?= @$data['id'] ?>" name="token">
                                    <div class="form-group">
                                        <table class="table" style=" border: 1px solid black;">
                                            <thead>
                                                <tr>
                                                    <th>Sl. No.</th>                                                   
                                                    <th>Material Name</th>
                                                    <th>Quantity</th>
                                                    <th>Remarks</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody id="items_list">
                                                <tr>
                                                    <td class="sl">1</td>
                                                    <td><select name="material_id[]" id="material_id" class="form-control rec" required >
                                                            <option value="">Select Material</option>  
                                                            <?php
                                                            $materialQuery = mysqli_query($conn, "SELECT id,material_name FROM material WHERE is_deleted='N' ORDER BY id DESC");
                                                            while ($materialList = mysqli_fetch_array($materialQuery)) { ?>
                                                                <option value="<?= $materialList['id']; ?>"><?php echo $materialList['material_name']; ?></option>
                                                            <?php  } ?>                                                      
                                                        </select>
                                                    </td>                                      
                                                    <td><input type="number" name="quantity[]" id="quantity" class="form-control rec" required min="0"> </td>
                                                    <td><input type="number" name="remarks[]" id="remarks" class="form-control rec" required min="0"> </td>
                                                    <td style="width:2%"><a href="javascript:void(0)" title="ADD" onclick="addProduct(this)" class="tab-index"><i class="fa fa-plus-circle fa-2x"></i></a></td>
                                                </tr>
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary" id="submit_request" onSubmit="add(event)">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- /.content -->
    <!-- /.content-wrapper -->
</div>
<!-- ====ADD DATA =====  -->

<script>
    function addProduct(th) {
       var tds=' <tr><td  class="sl">1</td>';
    
        tds+= '<td><select name="material_id[]"  id="material_id" class="form-control rec" required ><option value="">Select Material</option>'; 
        <?php
            $materialQuery = mysqli_query($conn, "SELECT id,material_name FROM material WHERE is_deleted='N' ORDER BY id DESC");
            while ($materialList = mysqli_fetch_array($materialQuery)) { ?>
        tds+='<option value="<?= $materialList['id']; ?>"><?php echo $materialList['material_name']; ?></option>';
            <?php  } ?>
        tds+='</select></td>';
        tds+='<td><input type="number" name="quantity[]" class="form-control rec" required min="0"> </td>';
        tds+='<td><input type="number" name="remarks[]" id="remarks" class="form-control rec" required min="0"> </td>';
        tds+='<td  style="width:2%"><a href="javascript:void(0)" title="ADD" onclick="addProduct(this)" class="tab-index"><i class="fa fa-plus-circle fa-2x"></i></a></td></tr>';
        
        $(th).find('> i').addClass('fa-times-circle');
        $(th).find('> i').removeClass('fa-plus-circle');
        $(th).attr('onclick', '$(this).closest("tr").remove();setSl();');
        $(th).attr('title', 'DELETE');
        $("#items_list").append(tds);
        setSl();
    }

    function setSl() {
        var i = 0;
        $(".sl").each(function(e) {
            i++;
            $(this).html(i);
        })
    }

    // <!-- =====submit add data =====  -->

    $(document).on('submit', '#userForm', function(e) {

        $('#modal-loader').modal('show');
        $('#submit_request').prop('disabled', true);
        e.preventDefault();
        $.ajax({
            method: "POST",
            url: "receipt_from_supplier_add.php",
            data: $(this).serialize(),
            success: function(data) {
                if(data=="yes"){
                $('#userForm').find('input').val('');
                $('#userForm').find('select').val('');
                swal("Receipt from Supplier Saved!", "", "success");
                $('#submit_request').prop('disabled', false);
                }
            }
        });
    });

  
</script>
<?php
include("layouts/footer.php");
?>