<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$head="masters";
$head1 ="material1";
$page="unit";
include("layouts/header.php");

?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h3 class="m-0">Masters/Unit</h3>
                </div>
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div><!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header border-0">
                            <div class="d-flex justify-content-between">
                                Unit
                                <div style="float:right">
                                    <a href="#" class="btn btn-success btn-sm" data-toggle="modal" data-target="#exampleModal">Add New</a>
                                </div>
                            </div>
                        </div>

                        <div class="card-body">
                            <div class="alert alert-success alert-dismissible" id="success" style="display:none;">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                            </div>
                            <table id="example1" class="table table-bordered table-sm">
                                <thead>
                                    <tr>
                                        <th>Sl No.</th>
                                        <th>Unit name</th>                                       
                                        <th>Edit </th>
                                        <th>Delete</th>
                                    </tr>
                                </thead>
                                <tbody id="table">

                                </tbody>
                            </table>

                            <script type="text/javascript">
                                $(document).ready(function() {
                                    loaddata();
                                });

                                function loaddata() {
                                    $('#modal-loader').modal('show');
                                    $.ajax({
                                        url: 'unit_view.php',
                                        type: 'POST',
                                        dataType: 'html',
                                        success: function(newContent) {
                                            $('#table').html('');
                                            $('#table').append(newContent);
                                            $('#modal-loader').modal('hide');
                                            $('#example1').DataTable();

                                        }
                                    });
                                }
                            </script>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- /.content -->
    <!-- /.content-wrapper -->
</div>
</div>

</body>


<div class="modal" id="modal-loader" style="z-index:1000000000">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body" style="z-index:1000000000">
                <img class="mx-auto d-block" src="dist/img/loader.gif" />
                <p class="text-center">Please Wait</p>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

<div class="modal" id="exampleModal">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Unit</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form class="form-horizontal" role="form" method="post" autocomplete="off" id="userForm" action="">
                <div class="modal-body">
                    <input type="hidden" value="<?= @$data['id'] ?>" name="token">
                    <div class="form-group">
                        <label for="exampleInputPassword1">Unit Name</label>
                        <input type="text" name="unit_name" class="form-control rec"   placeholder="Unit Name" required>
                    </div>                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" id="submit_request" onSubmit="add(event)">Submit</button>
                </div>
        </div>
        </form>
    </div>
</div>
</div>

<script>
    $(document).on('submit', '#userForm', function(e) {
        $('#modal-loader').modal('show');
        $('#submit_request').prop('disabled', true);
        e.preventDefault();
        $.ajax({
            method: "POST",
            url: "unit_add.php",
            data: $(this).serialize(),
            success: function(data) {
                $('#modal-loader').modal('hide');
                // $('#exampleModal').modal().hide();
                $('#userForm').find('input').val('');
                
                loaddata();
                swal("Unit Saved!", "", "success");
                $('#submit_request').prop('disabled', false);
            }
        });
    });
</script>


<!-- UPATE  DATA -->
<!-- Modal Update-->
<div class="modal fade" id="modal-update">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Update Unit</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!--1-->
                <div class="form-group">
                    <label for="exampleInputPassword1">Unit Name</label>
                    <input type="text" name="unit_name_edit" id="unit_name_edit" class="form-control" required>
                </div>
                
                <input type="hidden" name="unit_id" id="unit_id" class="form-control">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary" id="update_data">Update</button>
            </div>
        </div>
    </div>
</div>
</div>
<!-- Modal End-->

<script>
    $(function() {
        $('#modal-update').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget); /*Button that triggered the modal*/
            var unit_id = button.data('id');
            //alert(unit_id);
            var unit_name_edit = button.data('unit_name');            
            var modal = $(this);
            modal.find('#unit_id').val(unit_id);
            modal.find('#unit_name_edit').val(unit_name_edit);            
        });
    });

    $(document).on("click", "#update_data", function() {
        $('#modal-loader').modal('show');
    //    var unit_id= $('#unit_id').val();
    //     alert(unit_id);
    //     var unit_name_edit= $('#unit_name_edit').val();
    //     alert(unit_name_edit);
        $.ajax({
            url: "unit_update.php",
            type: "POST",
            cache: false,
            data: {
                id: $('#unit_id').val(),
                unit_name: $('#unit_name_edit').val(),              
            },
            success: function(dataResult) {
                var dataResult = JSON.parse(dataResult);
                if (dataResult.statusCode == 200) {
                    $('#modal-loader').modal('hide');
                    $('#modal-update').modal('hide');
                    swal("Unit Updated!", "", "success");
                    loaddata();
                }
            }
        });
    });
</script>

<!-- DELETE DATA  -->
<script>
    $(document).on("click", "#delete", function() {
        var dataId = $(this).attr('data-id');
        var dataResult = "";
        swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this data!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: "delete.php",
                        type: "POST",
                        cache: false,
                        data: {
                            id: dataId,
                            dtable: "unit",
                            ctable: "material",
                            field: "unit_name",
                        },
                        success: function(dataResult) {
                            dataResult = JSON.parse(dataResult);
                            // console.log(dataResult);
                            if (dataResult == 'success') {
                                loaddata();
                                swal("Deleted Successfully!", {
                                    icon: "success",
                                });
                            } else if (dataResult == 'duplicate') {
                                loaddata();
                                swal("Data already associated with Child Table!", {
                                    icon: "error",
                                });
                            }
                        }
                    });

                } else {
                    swal("Delete Action Cancelled by User!", {
                        icon: "warning",
                    });
                }
            });

    });
</script>

<?php
include("layouts/footer.php");
?>