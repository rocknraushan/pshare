<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$head = "report";
$page = "stock";
include("layouts/header.php");
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h3 class="m-0">Report/Stock</h3>
                </div>
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div><!-- /.content-header -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header border-0">
                            <div class="d-flex justify-content-between">
                                <?php
                                echo "Current Stock List"; ?>
                            </div>
                        </div>
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>Sl No.</th>
                                        <th>Material Name</th>
                                        <th>Head Office</th>
                                        <?php
                                        $StockQ = mysqli_query($conn, "SELECT * FROM workman ORDER BY id DESC");
                                        while ($StockQList = mysqli_fetch_array($StockQ)) {  ?>
                                            <th><?php echo $StockQList['workman_name'];  ?></th>
                                        <?php } ?>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $c = 0;
                                    $pQName = mysqli_query($conn, "SELECT * FROM material WHERE is_deleted='N' ORDER BY id DESC");
                                    while ($listOfProduct = mysqli_fetch_array($pQName)) {
                                    ?>
                                        <tr>
                                            <td><?php echo ++$c; ?></td> </a>
                                            <td><?php echo $listOfProduct['material_name']; ?></td>
                                            <?php
                                            $tav = 0;
                                            $stock_userid = 0;
                                            $getCurrentStockIN2   = mysqli_fetch_array(mysqli_query($conn, "SELECT SUM(quantity) as
																		stockQTYIN FROM txn_logs WHERE material_id='" . $listOfProduct['id'] . "' 
                                                                        AND stock_userid='0' AND type='IN' ORDER BY id DESC"));

                                            $getCurrentStockOUT2   = mysqli_fetch_array(mysqli_query($conn, "SELECT SUM(quantity) as
																		stockQTYOUT FROM txn_logs WHERE material_id='" . $listOfProduct['id'] . "' AND
                                                                        stock_userid='0' AND type='OUT' ORDER BY id DESC"));

                                            @$avail2         = $getCurrentStockIN2['stockQTYIN'] - $getCurrentStockOUT2['stockQTYOUT'];

                                            $tav += $avail2;
                                            ?>

                                            <td>
                                                <div data-toggle="modal" data-target="#myModal" data-id="<?= $listOfProduct['id'] ?>" data-stock_userid="a"><?php echo @$avail2 ?></div>
                                            </td>
                                            <?php
                                            $StockQs = mysqli_query($conn, "SELECT * FROM workman ORDER BY id DESC");
                                            $count_stock_point = mysqli_num_rows($StockQs);
                                            while ($StockQLists = mysqli_fetch_array($StockQs)) {
                                                $getCurrentStockIN   = mysqli_fetch_array(mysqli_query($conn, "SELECT SUM(quantity) as
																		stockQTYIN FROM txn_logs WHERE material_id='" . $listOfProduct['id'] . "' 
                                                                        AND stock_userid='" . $StockQLists['id'] . "' AND type='IN' ORDER BY id DESC"));

                                                $getCurrentStockOUT   = mysqli_fetch_array(mysqli_query($conn, "SELECT SUM(quantity) as
																		stockQTYOUT FROM txn_logs WHERE material_id='" . $listOfProduct['id'] . "'
                                                                        AND stock_userid='" . $StockQLists['id'] . "' AND type='OUT' ORDER BY id DESC"));
                                                @$avail         = $getCurrentStockIN['stockQTYIN'] - $getCurrentStockOUT['stockQTYOUT'];                                              
                                                $tav += $avail;
                                            ?>

                                                <td>
                                                    <div data-toggle="modal" data-target="#myModal" data-id="<?= $listOfProduct['id'] ?>" data-stock_userid="<?= $StockQLists['id'] ?>"><?php echo @$avail ?></div>
                                                </td>
                                            <?php    }       ?>
                                            <td><?php echo @$tav;
                                                $ttav += $tav; ?></td>
                                        </tr>
                                    <?php   }  ?>
                                    <tr>
                                        <?php
                                        $count_stock_point = $count_stock_point + 3;
                                        ?>
                                        <td colspan="<?= $count_stock_point ?>"></td>
                                        <td><b><?php echo $ttav; ?></b></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {

        $('#reservation').daterangepicker();

        $('#myModal').on('show.bs.modal', function(e) {
            $('#modal-loader').modal('show');
            $('#table_app').html("");
            var iddetails = $(e.relatedTarget).data('id');
            var stock_userid = $(e.relatedTarget).data('stock_userid');            
            $.ajax({
                method: 'GET',
                url: "all_stock_details.php",
                data: {
                    'id': iddetails,
                    'stock_userid':stock_userid
                }
            }).done(function(data) {
                // console.log(data);
                $('#table_app').append(`<div class="modal-body1">`);
                $('#table_app').append(data);
                $('#table_app').append(`</div>`);
                $('#modal-loader').modal('hide');
            });
        });
    });
</script>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" >
    <div class="modal-dialog  modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title contenttoshow" id="abc">Details </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div id="table_app">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<?php
include("layouts/footer.php");
?>

<div class="modal" id="modal-loader" style="z-index:1000000000">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body" style="z-index:1000000000">
                <img class="mx-auto d-block" src="dist/img/loader.gif" />
                <p class="text-center">Please Wait</p>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>