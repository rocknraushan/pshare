<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$count = 1;

$sql="SELECT j.*,job_category.job_category AS cat_name,workman.workman_name AS workman_n FROM job_workman j
LEFT JOIN job_category ON j.job_category_id =job_category.id  
LEFT JOIN workman ON j.workman_id = workman.id 
WHERE j.is_deleted='N' ORDER BY j.id DESC";
// echo $sql;
// exit;
$result = mysqli_query($conn,$sql);
if ($result) {
	while ($row = mysqli_fetch_array($result)) {	
?>
<tr>
<td><?= $count++; ?>
<td><?= $row['cat_name']; ?></td>			
<td><?= $row['workman_n']; ?></td> 
<td><button type="button" class="btn btn-success btn-sm update" data-toggle="modal" data-keyboard="false" data-backdrop="static" data-target="#modal-update" 
    data-id="<?= $row['id'];?>" 
    data-job_category_id_edit="<?= $row['job_category_id']; ?>" 
    data-workman_id_edit="<?= $row['workman_id']; ?>"
	>Edit</button>
</td>
<td><button type="button" class="btn btn-danger btn-sm update" id="delete" data-id="<?= $row['id']; ?>">Delete</button></td>
</tr>
<?php
	} 
} else {
	echo "<tr >
		<td colspan='5'>No Result found !</td>
		</tr>";
}
mysqli_close($conn);
?>

