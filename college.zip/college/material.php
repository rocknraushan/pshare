<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$head="masters";
$head1="material1";
$page="material";
include("layouts/header.php");
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h3 class="m-0">Masters/Material</h3>
                </div>
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div><!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header border-0">
                            <div class="d-flex justify-content-between">
                                Material
                                <div style="float:right">
                                    <a href="#" class="btn btn-success btn-sm" data-toggle="modal" data-target="#exampleModal">Add New</a>
                                </div>
                            </div>
                        </div>

                        <div class="card-body">
                            <div class="alert alert-success alert-dismissible" id="success" style="display:none;">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                            </div>
                            <table id="example1" class="table table-bordered table-sm">
                                <thead>
                                    <tr>
                                        <th>Sl No.</th>
                                        <th>Material name</th>
                                        <th>Unit Name</th>
                                        <th>Edit </th>
                                        <th>Delete</th>
                                    </tr>
                                </thead>
                                <tbody id="table">

                                </tbody>
                            </table>

                            <script type="text/javascript">
                                $(document).ready(function() {
                                    loaddata();
                                });

                                function loaddata() {
                                    $('#modal-loader').modal('show');
                                    $.ajax({
                                        url: 'material_view.php',
                                        type: 'POST',
                                        dataType: 'html',
                                        success: function(newContent) {
                                            $('#table').html('');
                                            $('#table').append(newContent);
                                            $('#modal-loader').modal('hide');
                                            $('#example1').DataTable();

                                        }
                                    });
                                }
                            </script>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- /.content -->
    <!-- /.content-wrapper -->
</div>
</div>

</body>


<div class="modal" id="modal-loader" style="z-index:1000000000">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body" style="z-index:1000000000">
                <img class="mx-auto d-block" src="dist/img/loader.gif" />
                <p class="text-center">Please Wait</p>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

<div class="modal" id="exampleModal">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Material</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form class="form-horizontal" role="form" method="post" autocomplete="off" id="userForm" action="">
                <div class="modal-body">
                    <input type="hidden" value="<?= @$data['id'] ?>" name="token">
                    <div class="form-group">
                        <label for="exampleInputPassword1">Material Name</label>
                        <input type="text" name="material_name" class="form-control rec" placeholder="Material Name" required>
                    </div>
                    <div class="form-group ven">
                        <label for="exampleInputEmail1">Unit Name </label>
                        <select name="unit_name" class="form-control rec" required>
                            <option value="">Select Unit Name</option>
                            <?php
                            $q1 = mysqli_query($conn, "SELECT id ,unit_name from unit WHERE is_deleted='N'");

                            while ($listunit = mysqli_fetch_assoc($q1)) {
                            ?>
                                <option value="<?= $listunit['id']; ?>"><?= $listunit['unit_name'];  ?></option>
                            <?php
                            }   ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Opening Quantity </label>
                        <input type="number" name="opening_quantity" class="form-control rec" placeholder="Opening Quantity" min="1">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" id="submit_request" onSubmit="add(event)">Submit</button>
                </div>
        </div>
        </form>
    </div>
</div>
</div>

<script>
    $(document).on('submit', '#userForm', function(e) {
        $('#modal-loader').modal('show');
        $('#submit_request').prop('disabled', true);
        e.preventDefault();
        $.ajax({
            method: "POST",
            url: "material_add.php",
            data: $(this).serialize(),
            success: function(data) {
                $('#modal-loader').modal('hide');
                // $('#exampleModal').modal().hide();
                $('#userForm').find('input').val('');
                $('#userForm').find('select').val('');
                loaddata();
                swal("Material Saved!", "", "success");
                $('#submit_request').prop('disabled', false);
            }
        });
    });
</script>


<!-- UPATE  DATA -->
<!-- Modal Update-->
<div class="modal fade" id="modal-update">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Update Material</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <!--1-->
                <div class="form-group">
                    <label for="exampleInputPassword1">Material Name</label>
                    <input type="text" name="material_name_edit" class="form-control rec" id="material_name_edit" placeholder="Material Name" required>
                </div>
                <!-- 2  -->
                <div class="form-group ven">
                    <label for="exampleInputEmail1">Unit Name </label>
                    <select name="unit_name_edit" id="unit_name_edit" class="form-control rec" required>
                        <option value="">Select Unit Name</option>
                        <?php
                        $q1 = mysqli_query($conn, "SELECT id ,unit_name from unit WHERE is_deleted='N'");

                        while ($listunit = mysqli_fetch_assoc($q1)) {
                        ?>
                            <option value="<?= $listunit['id']; ?>"><?= $listunit['unit_name'];  ?></option>
                        <?php
                        }   ?>
                    </select>
                </div>
                
                <input type="hidden" name="material_id" id="material_id" class="form-control">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary" id="update_data">Update</button>
            </div>
        </div>
    </div>
</div>
</div>
<!-- Modal End-->

<script>
    $(function() {
        $('#modal-update').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget); /*Button that triggered the modal*/
            var id = button.data('id');
            var material_name = button.data('material_name');
            var unit_name = button.data('unit_name');
           
            var modal = $(this);
            modal.find('#material_id').val(id);
            modal.find('#material_name_edit').val(material_name);
            modal.find('#unit_name_edit').val(unit_name);
            
        });
    });
    $(document).on("click", "#update_data", function() {
        $('#modal-loader').modal('show');
        //    var house_id_edit= $('#house_id_edit').val();
        //     alert(house_id_edit);
        $.ajax({
            url: "material_update.php",
            type: "POST",
            cache: false,
            data: {
                id: $('#material_id').val(),
                material_name_edit: $('#material_name_edit').val(),
                unit_name_edit: $('#unit_name_edit').val(),
            },
            success: function(dataResult) {
                var dataResult = JSON.parse(dataResult);
                if (dataResult.statusCode == 200) {
                    $('#modal-loader').modal('hide');
                    $('#modal-update').modal('hide');
                    swal("Material Updated!", "", "success");
                    loaddata();
                }
            }
        });
    });
</script>

<!-- DELETE DATA  -->
<script>
    $(document).on("click", "#delete", function() {
        var dataId = $(this).attr("data-id");

        // alert(house_status_del);
        swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this imaginary file!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: "material_delete.php",
                        type: "POST",
                        cache: false,
                        data: {
                            id: dataId,
                        },
                        success: function(dataResult) {
                            var dataResult = JSON.parse(dataResult);
                        }
                    });

                    loaddata();
                    swal("Deleted Successfully!", {
                        icon: "success",
                    });
                } else {
                    swal("Delete Action Cancelled by User!");
                }
            });
        loaddata();
    });
</script>

<?php
include("layouts/footer.php");
?>