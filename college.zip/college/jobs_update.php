<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");	
$myid=$_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');
	$id = $_POST['idUnq1'];
	
	$jobs_category_id   = $_POST['jobs_category_edit'];
$jobs_sub_category_id   = $_POST['jobs_sub_category_edit'];
$jobs_name= $_POST['jobs_name_edit'];
$slg=$_POST['slg_edit'];
	$sql = "UPDATE `jobs` SET `jobs_category_id`='$jobs_category_id',`jobs_sub_category_id`='$jobs_sub_category_id',jobs_name='$jobs_name',slg='$slg',
	 updated_by='$myid',updated_date_time='$date' WHERE `id`='$id'";
	// echo $sql;
	// exit;
	if (mysqli_query($conn, $sql)) {
		echo json_encode(array("statusCode"=>200));
	} 
	else {
		echo json_encode(array("statusCode"=>201));
	}
