<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$count = 1;
// $sql = "SELECT house.id,house_type.house_type AS type_name,house.house_number FROM house INNER JOIN house_type ON house.house_type=house_type.id WHERE house.is_deleted='N' ORDER BY house.id DESC";
$sql="SELECT house.id,house.house_number,house_type.house_type AS type_name,house.house_type AS house_type_id FROM house INNER JOIN house_type ON house.house_type=house_type.id WHERE house.is_deleted='N' ORDER BY house.id DESC";
$result = mysqli_query($conn,$sql);
if ($result) {
	while ($row = mysqli_fetch_array($result)) {
	
?>
<tr>
<td><?= $count++; ?>
<td><?= $row['type_name']; ?></td>			
<td><?= $row['house_number']; ?></td>
<td><button type="button" class="btn btn-success btn-sm update" data-toggle="modal" data-keyboard="false" data-backdrop="static" data-target="#modal-update" 
data-id="<?= $row['id']; ?>" 
data-house_type="<?= $row['house_type_id']; ?>" 
data-house_number="<?= $row['house_number']; ?>">Edit</button>
</td>
<td><button type="button" class="btn btn-danger btn-sm update" id="delete" data-id="<?= $row['id']; ?>">Delete</button></td>
</tr>
<?php
	}
} else {
	echo "<tr >
		<td colspan='5'>No Result found !</td>
		</tr>";
}
mysqli_close($conn);
?>

