﻿<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$head="masters";
$head1="house";
$page="house";
include("layouts/header.php");
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h3 class="m-0">Masters/House</h3>
                </div>
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div><!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header border-0">
                            <div class="d-flex justify-content-between">
                                House
                                <div style="float:right">
                                    <a href="#" class="btn btn-success btn-sm" data-toggle="modal" data-target="#exampleModal">Add New</a>
                                </div>
                            </div>
                        </div>

                        <div class="card-body">
                            <div class="alert alert-success alert-dismissible" id="success" style="display:none;">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                            </div>
                            <table id="example1" class="table table-bordered table-sm">
                                <thead>
                                    <tr>
                                        <th>Sl No.</th>
                                        <th>House Type</th>

                                        <th>House Number</th>
                                        <th>Edit </th>
                                        <th>Delete</th>
                                    </tr>
                                </thead>
                                <tbody id="table">

                                </tbody>
                            </table>

                            <script type="text/javascript">
                                $(document).ready(function() {
                                    loaddata();
                                });

                                function loaddata() {
                                    $('#modal-loader').modal('show');

                                    $.ajax({
                                        url: 'house_view.php',
                                        type: 'POST',
                                        dataType: 'html',
                                        success: function(newContent) {
                                            $('#table').html('');
                                            $('#table').append(newContent);
                                            $('#example1').DataTable();
                                            $('#modal-loader').modal('hide');

                                        }
                                    });
                                }
                            </script>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- /.content -->
    <!-- /.content-wrapper -->
</div>
</div>

</body>


<div class="modal" id="modal-loader" style="z-index:1000000000">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body" style="z-index:1000000000">
                <img class="mx-auto d-block" src="dist/img/loader.gif" />
                <p class="text-center">Please Wait</p>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

<div class="modal" id="exampleModal">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">House</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form class="form-horizontal" role="form" method="post" autocomplete="off" id="userForm" action="">
                <div class="modal-body">
                    <input type="hidden" value="<?= @$data['id'] ?>" name="token">
                    <div class="form-group">
                        <label for="exampleInputPassword1">House Type</label>
                        <select name="house_type" id="house_type" class="form-control rec">
                        <option value="">Select House Type</option>
                            <?php
                            $sql = "SELECT * FROM house_type  WHERE is_deleted='N' ORDER BY id DESC";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                               
                                while ($row1 = $result->fetch_assoc()) {
                                    echo "console.log(".$row1['id'].")";
                            ?>
                                    <option value="<?= $row1['id']; ?>"><?php echo $row1['house_type']; ?></option>
                                    <?php
                                       }  
                                    }
                                    else { 
                                        echo "<tr >
                                        <td colspan='5'>No Result found !</td>
                                        </tr>";
                                    }
                                    // mysqli_close($conn);
                                    ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">House Number</label>
                        <input type="text" name="house_number" class="form-control rec" id="" placeholder="House Number" required>

                    </div>

                    <div class="form-group">
                        <?php if ($edit) { ?>
                            <input type="submit" name="update" onclick="return form_validate()" value="Update" class="btn btn-primary btn-sm" />&nbsp;&nbsp;
                        <?php } else { ?>
                        <?php } ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" id="submit_request" onSubmit="add(event)">Submit</button>
                </div>
        </div>
        </form>
    </div>
</div>
</div>
<script>
    $(document).on('submit', '#userForm', function(e) {
        $('#modal-loader').modal('show');
        $('#submit_request').prop('disabled', true);
        e.preventDefault();
        $.ajax({
            method: "POST",
            url: "house_add.php",
            data: $(this).serialize(),
            success: function(data) {
                $('#modal-loader').modal('hide');
               // $('#exampleModal').modal().hide();
                $('#userForm').find('input').val('');
              //  location.reload();
                loaddata();
                swal("House Saved!", "", "success");
                $('#submit_request').prop('disabled', false);
            }
        });
    });
</script>


<!-- UPATE  DATA -->
<!-- Modal Update-->
<div class="modal fade" id="modal-update">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Update Employee</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <input type="hidden" name="id_modal" id="id_modal" class="form-control">
            <div class="modal-body">
                <!--1-->
                <div class="form-group">
                    <label for="exampleInputPassword1">House Type</label>
                    <select name="houseType" id="houseType_edit" class="form-control rec">
                        <option value="">Select House Type</option>
                        <?php
                            $sql1 = "SELECT * FROM house_type  WHERE is_deleted='N' ORDER BY id DESC";
                            $result1 = mysqli_query($conn,$sql1);
                            while ($row1 = mysqli_fetch_assoc($result1)) {
                        ?>
                            <option value="<?= $row1['id']; ?>"><?=  $row1['house_type']; ?></option>
                        <?php
                            }   ?>
                        </select>   
                </div>
                <!--2-->
                <div class="form-group">
                    <label>House Number</label>
                    <input type="number" name="house_number" id="houseNumber_edit" class="form-control" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary" id="update_data">Update</button>
            </div>
        </div>
    </div>
</div>
</div>
<!-- Modal End-->
<script>
    $(function() {
        $('#modal-update').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget); /*Button that triggered the modal*/
            var id = button.data('id');
            var house_type = button.data('house_type');
            var house_number = button.data('house_number');
            var modal = $(this);
            modal.find('#houseType_edit').val(house_type);
            modal.find('#houseNumber_edit').val(house_number);
            modal.find('#id_modal').val(id);
        });
    });

    $(document).on("click", "#update_data", function() {
        $('#modal-loader').modal('show');
        // console.log($('#id_modal').val());
        // console.log($('#house_type').val());
        // console.log($('#house_number').val());
        $.ajax({
            url: "house_update.php",
            type: "POST",
            // cache: false,
            data: {
                id: $('#id_modal').val(),
                housetype_edit : $('#houseType_edit').val(),
                houseno_edit: $('#houseNumber_edit').val(),
            },
            success: function(dataResult) {
                // var dataResult = JSON.parse(dataResult);
                // if (dataResult.statusCode == 200) {
                    $('#modal-loader').modal('hide');
                   // $('#modal-update').modal().hide();
                    swal("House Updated!", "", "success");
                    loaddata();
               // }
            }
        });
    });
</script>

<!-- DELETE DATA  -->
<script>
    $(document).on("click", "#delete", function() {
        var dataId = $(this).attr("data-id");
        swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this imaginary file!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: "house_delete.php",
                        type: "POST",
                        cache: false,
                        data: {
                            id: dataId,

                        },
                        success: function(dataResult) {
                            var dataResult = JSON.parse(dataResult);
                        }
                    });

                    loaddata();
                    swal("Deleted Successfully!", {
                        icon: "success",
                    });
                } else {
                    swal("Delete Action Cancelled by User!");
                }
            });
        loaddata();
    });
</script>

<?php
include("layouts/footer.php");
?>