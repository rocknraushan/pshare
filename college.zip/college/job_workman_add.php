<?php
session_start();
include("../inc/db_conn.php");
//$db=$conn;// database connection  
$myid = $_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');

foreach ($_POST['job_category_id'] as $key => $value) {
    $job_category_id   = $_POST['job_category_id'][$key];
    $workman_id   = $_POST['workman_id'][$key];

    $EXE   = mysqli_query($conn, "INSERT INTO `job_workman`( `job_category_id`, `workman_id`, `created_by`, `created_date_time`) VALUES ('$job_category_id','$workman_id','$myid','$date')");
}
