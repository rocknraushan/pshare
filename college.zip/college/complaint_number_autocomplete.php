<?php
include("../inc/db_conn.php");
if(isset($_GET['term'])){
	$complaint_number = $_GET['term'];
    $complaint_detail = explode('/', $complaint_number);
    $complaint_month = $complaint_detail[1];
    $complaint_year = $complaint_detail[2];
    $complaint_num = $complaint_detail[3];
    $return_arr = array();
	$result = mysqli_query($conn,"SELECT complaint_number,complaint_login_datetime FROM complaint WHERE complaint_number LIKE '$complaint_num%' OR 
    YEAR(complaint_login_datetime) LIKE '$complaint_year%' OR MONTH(complaint_login_datetime) LIKE '$complaint_month%'");
	if(mysqli_num_rows($result) >0)
	{
		while($row = mysqli_fetch_array($result)) {
			$return_arr[] = 'C/'. date('m', strtotime($row['complaint_login_datetime'])).'-'. date('Y', strtotime($row['complaint_login_datetime'])).'/'.$row['complaint_number'];
		}
		echo json_encode($return_arr);
	}
	else
	{
		return false;   
	}
}
?>