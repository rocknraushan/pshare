<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$myid = $_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');
$workman_name   = $_POST['workman_name_edit'];
$workman_email   = $_POST['workman_email_edit'];
$workman_username   = $_POST['workman_username_edit'];
$workman_mobile   = $_POST['workman_mobile_edit'];
$workman_type   = $_POST['workman_type_edit'];
if ($workman_type == 'V') {
	$vender_email   = $_POST['vender_email_edit'];
	$vender_name   = $_POST['vender_name_edit'];
	$vender_code   = $_POST['vender_code_edit'];
	$vender_mobile   = $_POST['vender_mobile_edit'];
} else {
	$vender_email   = "";
	$vender_name   = "";
	$vender_code   = "";
	$vender_mobile   = "";
}
$id = $_POST['id'];

$sql = "UPDATE `workman` SET `workman_name`='$workman_name',workman_email = '$workman_email',
	workman_username = '$workman_username',workman_mobile = '$workman_mobile',workman_type = '$workman_type',
	vender_email = '$vender_email',vender_name = '$vender_name',vender_code = '$vender_code',vender_mobile = '$vender_mobile', updated_by='$myid',updated_date_time='$date' WHERE `id`='$id'";

if (mysqli_query($conn, $sql)) {
	echo json_encode(array("statusCode" => 200));
} else {
	echo json_encode(array("statusCode" => 201));
}
mysqli_close($conn);
?>
