<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$count++;
$sql = "SELECT e.*,house.house_number AS h_number,house.id AS house_status_id,house_type.house_type AS h_type,house_type.id AS h_id
	FROM employee e
	LEFT JOIN house ON e.house_id = house.id
	LEFT JOIN house_type ON house.house_type = house_type.id     
	WHERE e.is_deleted='N' ORDER BY e.id DESC";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
	while ($row = $result->fetch_assoc()) {
		$id = $row['id'];
?>
		<tr>
			<td><?= $count++; ?></td>
			<td><?= $row['name']; ?></td>
			<td><?= $row['email']; ?></td>
			<td><?= $row['alternative_email']; ?></td>
			<td><?= $row['phone']; ?></td>
			<td><?= $row['alternative_phone']; ?></td>
			<td><?= $row['intercom_nunber']; ?></td>
			<td><?= $row['p_number']; ?></td>
			<?php if ($row['house_id'] == "0") { ?>
				<td> </td>
			<?php } else { ?>				
				<td><?php echo $row['h_type'] . "-" . $row['h_number']; ?></td>
			<?php } ?>
			<td><button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#myModal" data-id="<?=  $row['id']; ?>" data-keyboard="false"
			 data-backdrop="static" >View Past Occupancy</button> <button type="button" class="btn btn-info btn-sm update" id="reset_password" data-id="<?= $row['id']; ?>"			
			>Reset Password</button> <button type="button" class="btn btn-success btn-sm update" data-toggle="modal" data-keyboard="false" data-backdrop="static" data-target="#modal-update" 
			data-id="<?= $row['id']; ?>" 
			data-name="<?= $row['name']; ?>" 
			data-email="<?= $row['email']; ?>" 
			data-alternative_email="<?= $row['alternative_email']; ?>" 
			data-phone="<?= $row['phone']; ?>" 
			data-alternative_phone="<?= $row['alternative_phone']; ?>"
			data-inter_com_nunber="<?= $row['intercom_nunber']; ?>" 
			data-per="<?= $row['p_number']; ?>" 
			data-house_id="<?= $row['h_id']; ?>"
			data-house_name="<?= $row['h_number'];?>"
			data-house_status_id="<?= $row['house_status_id']; ?>"
			>Edit</button> <button type="button" class="btn btn-danger btn-sm update" id="delete" data-id="<?= $row['id']; ?>"
			data-house_status_del="<?= $row['house_status_id']; ?>"
			>Delete</button></td>
		</tr>
<?php
	}
} else {
	echo "<tr >
		<td colspan='5'>No Result found !</td>
		</tr>";
}
mysqli_close($conn);
?>