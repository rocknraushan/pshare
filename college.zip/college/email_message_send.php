<?php
function email_sms($email,$mobile,$name,$pwd)
{
include "lib/function.php";
// SMS
$massage = "Dear $name,\n";
$massage .= "Your Password for Township App is " . $pwd;
$massage .= "\nThank You,";
$massage .= "\nTata Steel Long Products Limited";
$massage = urlencode($massage);
// echo  $massage;
$file = file_get_contents("http://gateway9.mbiz.co.in/httpapi/httpapi?token=ec5199c307c1e1f3e809efe526dd5fb0&sender=TSLPMS&number=$mobile&route=2&type=1&sms=$massage&templateid=1607100000000122784");
//Email
$to = $email;
$from_mail = 'apps_alert@tatasteellp.com';
$replyto = $to;
$replyname = 'noreply';
$from_name = 'Township App';
$subject = 'App Password';
$body = 'Dear ' . $name . ',<br>Your Password for Township App is ' . $pwd . ',<br>Thank You,<br>Tata Steel Long Products Limited';
sendSMTP($to, $from_mail, $from_name, $replyto, $replyname, $subject, $body);
}
?>