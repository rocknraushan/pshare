<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
if(isset($_GET['type'])){
    if($_GET['type'] == 'Allot_house'){
 
        $house = mysqli_query($conn,"SELECT house.house_number ,house_type.house_type,employee.name,employee.p_number,employee.phone
                                        FROM house
                                        LEFT JOIN house_type ON house.house_type = house_type.id
                                        LEFT JOIN employee ON house.id = employee.house_id
                                        WHERE house.is_deleted='N'AND house.house_status = 'Active' AND employee.is_deleted='N'");
        $toReturn = "";
            $toReturn .= "<table class='table'>";
                $toReturn .= "<tr>";
                    $toReturn .= "<th>#</th>";
                    $toReturn .= "<th>House</th>";
                    $toReturn .= "<th>Employee Name</th>";
                    $toReturn .= "<th>Personal Number </th>";
                    $toReturn .= "<th>Phone Number </th>";
                $toReturn .= "</tr>";
                $count = 1;
                while ($row = mysqli_fetch_assoc($house)) {
                    $toReturn .= "<tr>";
                        $toReturn .= "<td>".$count++."</td>";
                        $toReturn .= "<td>".$row['house_type']."-".$row['house_number']."</td>";
                        $toReturn .= "<td>".ucfirst($row['name'])."</td>";
                        $toReturn .= "<td>".$row['p_number']."</td>";
                        $toReturn .= "<td>".$row['phone']."</td>";                     
                    $toReturn .= "</tr>";                   
                }
            $toReturn .= "</table>";
            echo $toReturn;
    }elseif($_GET['type'] == 'Non_house'){
 
        $house = mysqli_query($conn,"SELECT house.house_number ,house_type.house_type
                                    FROM house
                                    LEFT JOIN house_type ON house.house_type = house_type.id
                                    WHERE house.is_deleted='N'AND house.house_status = 'Non-Active'");
        $toReturn = "";
            $toReturn .= "<table class='table'>";
                $toReturn .= "<tr>";
                    $toReturn .= "<th>#</th>";
                    $toReturn .= "<th>House</th>";                  
                $toReturn .= "</tr>";
                $count = 1;
                while ($row = mysqli_fetch_assoc($house)) {
                    $toReturn .= "<tr>";
                        $toReturn .= "<td>".$count++."</td>";
                        $toReturn .= "<td>".$row['house_type']."-".$row['house_number']."</td>";                                           
                    $toReturn .= "</tr>";                   
                }
            $toReturn .= "</table>";
            echo $toReturn;
    }

}
?>