<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$head="inventory";
$page="recipt";
include("layouts/header.php");

?>
<style>
    .content{
        background-color: white;
    }
    .swal-content{
        overflow: auto;
    }
</style>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h3 class="m-0">Receipt</h3>
                </div>
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div><!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <form class="form-horizontal" role="form" method="post" autocomplete="off" id="userForm" action="">
                                <div class="modal-body">
                                    <input type="hidden" value="<?= @$data['id'] ?>" name="token">
                                    <div class="form-group">
                                        <table class="table" style=" border: 1px solid black;">
                                            <thead>
                                                <tr>
                                                    <th>Sl. No.</th>
                                                    <th>Workman Name</th>
                                                    <th>Material Name</th>
                                                    <th>Stock</th>
                                                    <th>Quantity</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody id="items_list">
                                                <tr>
                                                    <td class="sl">1</td>
                                                    <td><select name="allot_id[]" id="workman_id" class="form-control rec" required onChange="workman_id_select(this.value,this)">
                                                            <option value="">Select Workman</option>
                                                            <?php
                                                            $workman = mysqli_query($conn, "SELECT * FROM workman WHERE is_deleted='N'  ORDER BY id DESC");
                                                            while ($workmanllist = mysqli_fetch_array($workman)) { ?>
                                                                <option value="<?= $workmanllist['id']; ?>"><?php echo $workmanllist['workman_name']; ?></option>
                                                            <?php  } ?>
                                                        </select>
                                                    </td>
                                                    <td><select name="material_id[]" id="material_id" class="form-control rec" required onChange="material_id_select(this.value,this)">
                                                            <option value="">Select Material</option>                                                         
                                                        </select>
                                                    </td>
                                                    <?php
                                                    ?>
                                                    <td><input type="number" name="stock[]" id="stock" class="form-control rec" readonly ></td>
                                                    
                                                    <td><input type="number" name="quantity[]" id="quantity" class="form-control rec" required min="0"> </td>
                                                    <td style="width:2%"><a href="javascript:void(0)" title="ADD" onclick="addProduct(this)" class="tab-index"><i class="fa fa-plus-circle fa-2x"></i></a></td>
                                                </tr>
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary" id="submit_request" onSubmit="add(event)">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- /.content -->
    <!-- /.content-wrapper -->
</div>
<!-- ====ADD DATA =====  -->

<script>
    function addProduct(th) {
       var tds=' <tr><td  class="sl">1</td>';
       tds+='<td><select name="allot_id[]"  class="form-control rec" required onChange="workman_id_select(this.value,this)"><option value="">Select Workman</option>';
            <?php
            $workman = mysqli_query($conn, "SELECT * FROM workman WHERE is_deleted='N'  ORDER BY id DESC");
            while ($workmanllist = mysqli_fetch_array($workman)) { ?>
        tds+='<option value="<?= $workmanllist['id']; ?>"><?php echo $workmanllist['workman_name']; ?></option>';
             <?php  } ?>
        tds+='</select></td>';
        tds+= '<td><select name="material_id[]"  id="material_id" class="form-control rec" required onChange="material_id_select(this.value,this)"><option value="">Select Material</option>'; 
        tds+='<td><input type="number" name="stock[]" id="stock" class="form-control rec" readonly ></td>';
        
        tds+='</select></td>';
        tds+='<td><input type="number" name="quantity[]" class="form-control rec" required min="0"> </td>';
        tds+='<td  style="width:2%"><a href="javascript:void(0)" title="ADD" onclick="addProduct(this)" class="tab-index"><i class="fa fa-plus-circle fa-2x"></i></a></td></tr>';
        
        $(th).find('> i').addClass('fa-times-circle');
        $(th).find('> i').removeClass('fa-plus-circle');
        $(th).attr('onclick', '$(this).closest("tr").remove();setSl();');
        $(th).attr('title', 'DELETE');
        $("#items_list").append(tds);
        setSl();
    }

    function setSl() {
        var i = 0;
        $(".sl").each(function(e) {
            i++;
            $(this).html(i);
        })
    }

    // <!-- =====submit add data =====  -->

    $(document).on('submit', '#userForm', function(e) {
        $('#modal-loader').modal('show'); 
        $('#submit_request').prop('disabled', true);
        e.preventDefault();
        $.ajax({
            method: "POST",
            url: "receint_add.php",
            data: $(this).serialize(),
            success: function(data) {
                $('#userForm').find('input').val('');
                $('#userForm').find('select').val('');
                $('#modal-loader').modal('hide');
                swal("Receipt from Workman Saved!", "", "success");
                $('#submit_request').prop('disabled', false);
            }
        });
    });

    function material_id_select(items, th) { 
        $('#modal-loader').modal('show');
        var material_id = items; 
       var workman_id = $(th).closest('tr').find('#workman_id').val();
      // alert(workman_id);  
        if (material_id) {
            $.ajax({
                type: "POST",
                url: "get_all_data.php",
                data: {
                    'material_id_workman': material_id,
                    api:'workman_detail',
                    workman_id : $('#workman_id').val(),
                },
                beforeSend: function() {
                    $(th).closest('tr').find('#stock').html('');                    
                },
                success: function(data) {
                    $(th).closest('tr').find('#stock').val(data);
                    $('#modal-loader').modal('hide');
                   //alert(data);              
                }
            });
        }
    }
    function workman_id_select(items, th) { 
        var workman_id = items; 
        $('#modal-loader').modal('show');
        //alert(workman_id);  
        if (workman_id) {
            $.ajax({
                type: "POST",
                url: "get_all_data.php",
                data: {
                    'workman_id_for_material': workman_id,
                    api1:'workman_id_detail',
                },
                beforeSend: function() {
                    $(th).closest('tr').find('#material_id').html('');                    
                },
                success: function(data) {
                  //  alert(data);
                    $(th).closest('tr').find('#material_id').html(data);
                    $('#modal-loader').modal('hide');
                   //alert(data);              
                }
            });
        }
    }

    // $('#quantity').on('change', function() {
	// 	var stock1 = $(this).val();
	// 	var stock2 = $('#stock').val();
    //     // alert(stock1);
    //     // alert(stock2);
	// 	if(stock2>=stock1){			
	// 		alert("Please Select Correct Quantity");
	// 		$(this).val('');
	// 	}else{
    //         alert(" Correct Quantity");
    //     }
	// });
</script>
<?php
include("layouts/footer.php");
?>

<div class="modal" id="modal-loader" style="z-index:1000000000">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body" style="z-index:1000000000">
                <img class="mx-auto d-block" src="dist/img/loader.gif" />
                <p class="text-center">Please Wait</p>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>