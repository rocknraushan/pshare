<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php"); 
$myid=$_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');	
	$id=$_POST['id_modal'];
	$role=$_POST['role_modal'];	
	$Q1 = mysqli_query($conn, "DELETE FROM role_permission WHERE role_master_id='$id'"); 
	$Q2 = mysqli_query($conn, "UPDATE `role_master` SET `rolename`='$role' WHERE `id`='$id'");
	
	foreach ($_POST['permission_master_id_edit'] as $key => $value) {
        $permission_master_id_edit   = $_POST['permission_master_id_edit'][$key];
		$Q3 = mysqli_query($conn,"INSERT INTO role_permission (role_master_id,permission_master_id) VALUES ('$id','$permission_master_id_edit')"); 
	}
	
if ($Q1 && $Q2 && $Q3) {
	echo json_encode(array("statusCode" => 200));
} else {
	echo json_encode(array("statusCode" => 201));
}

	mysqli_close($conn);
?>