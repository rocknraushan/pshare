<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$head = "complaint";
$page = "complaint";
include("layouts/header.php");
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
?>
<style>
    .content {
        background-color: white;
    }

    .swal-content {
        overflow: auto;
    }
    
</style>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <br>
    <!-- Main content -->
    <section class="content">
        <form class="form-horizontal" id="add_complain" role="form" method="post" autocomplete="off" action="">
            <div id="accordion">
                <div class="card card-primary">
                    <div class="card-header">
                        <h4 class="card-title">
                            <a data-toggle="collapse" data-parent="#accordion" href="#Observation-Details">
                                Log a Complaint
                            </a>
                        </h4>
                    </div>
                    <div id="Observation-Details" class="panel-collapse collapse show">
                        <div class="card-body">
                            <input type="hidden" value="<?= @$data['id'] ?>" name="token">
                            <!-- Here the Code for the Product of all the details  -->
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Employee Name / P.No.</label>
                                        <input type="text" name="name" id="name" class="form-control rec" required placeholder="Employee Name / P.No.">
                                        <input type="hidden" name="employee_id" id="employee_id">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">House Number</label>
                                        <!-- <input type="text" name="house_id" id="house_id" class="form-control rec" required> -->
                                        <select name="house_id" id="house_id" class="form-control rec">
                                            <option value="">Select House Type</option>
                    
                                        </select>

                                    </div>

                                </div>
                                <div class="col-md-6" id="table_fill">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Email</label>
                                        <input type="text" placeholder="Email" required name="email" id="email" readonly class="form-control rec">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Mobile Number</label>
                                        <input type="number" name="phone" id="phone" class="form-control rec" readonly placeholder="Mobile Number">
                                    </div>
                                </div>
                            </div>
                            <div id="button_div"></div>
                            <!-- <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#myModal1" data-id="<?= $row['id']; ?>" data-keyboard="false" data-backdrop="static">View Profile</button>
                            <button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#myModal" data-id="<?= $row['id']; ?>" data-keyboard="false" data-backdrop="static">View Past Occupancy</button> -->
                            <br>
                            <div id="back_complain"></div>

                        </div>

                        <!-- Here the code for the Employee all the details fill -->
                    </div>
                </div>


                <div class="card card-primary">
                    <div class="card-header">
                        <h4 class="card-title">
                            <a data-toggle="collapse" data-parent="#accordion" href="#C-Details">
                                Complaint Details
                            </a>
                        </h4>
                    </div>
                    <div id="C-Details" class="panel-collapse collapse show">
                        <div class="card-body">
                            <div class="row">
                                <div class="form-group">
                                    <table class="table table-bordered table-hover table-condensed">
                                        <thead>
                                            <tr>
                                                <th>
                                                    <div>#</div>
                                                </th>
                                                <th>
                                                    <div>Job</div>
                                                </th>
                                                <th>
                                                    <div>Complaint Description</div>
                                                </th>

                                                <th>
                                                    <div>Allocated To</div>
                                                </th>
                                                <th>
                                                    <div>Add</div>
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody id="items_list">
                                            <tr>
                                                <td class="sl" style="width:1%"> 1</td>
                                                <td style="width:15%">
                                                    <select name="job_category" id="job_category" class="form-control rec job_category" onChange="job_category_select(this.value,this), job_category_select1(this.value,this) ">

                                                        <option value="">Select Job Category Type</option>
                                                        <?php
                                                        $sql = "SELECT * FROM job_category  WHERE is_deleted='N' ORDER BY id DESC";
                                                        $result = $conn->query($sql);
                                                        while ($row1 = $result->fetch_assoc()) {
                                                        ?>
                                                            <option value="<?= $row1['id']; ?>"><?php echo $row1['job_category']; ?></option>
                                                        <?php
                                                        }
                                                        ?>
                                                    </select>

                                                    <select name="job_sub_category" id="job_sub_category"  class="form-control rec job_sub_category" onChange="job_sub_category_select(this.value,this)">
                                                        <option value="">Select Job sub Category Type</option>

                                                    </select>

                                                    <select class="form-control rec producccttt" name="type_of_job[]" id="type_of_job" onChange="job_select(this.value,this)">
                                                        <option value="">Select Job Name</option>
                                                    </select>
                                                </td>
                                                <td style="width:30%"><textarea name="complaint_description[]" id="complaint_description" class="form-control rec" placeholder="Complaint Description" required></textarea>
                                                    Repeat Complaint <input type="checkbox" id="repeat_complaint" name="repeat_complaint[]" onclick="check_complaint(this.value,this)" class="repeat_complaint">
                                                    <div class="select_repect_complaint"></div>
                                                </td>
                                                <td style="width:15%">

                                                    <select class="form-control rec allocated_to" name="allocated_to[]" id="allocated_to">
                                                        <option value="">Select Workman</option>
                                                    </select><hr>
                                                    <label>Estimated Date of Completion</label>
                                                    <input type="text" name="find_slg[]" id="find_slg" placeholder="SLG" readonly class="form-control rec">

                                                </td>
                                                <td style="width:1%"><a href="javascript:void(0)" title="ADD" onclick="addItems(this)" class="tab-index"><i class="fa fa-plus-circle fa-2x"></i></a></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="form-group">
                <center><input type="submit" name="save" id="save" value="Log Complaint" class="btn btn-primary" />&nbsp;&nbsp;
                </center>
            </div>
        </form>
    </section>
    <!-- /.content-wrapper -->

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->

</div>

<?php
include("layouts/footer.php");
?>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<!-- <script src="https://unpkg.com/sweetalert2@7.19.3/dist/sweetalert2.all.js"></script> -->
<script>
    $("#name").autocomplete({
        source: "complaint_autocomplete.php",
    });
    $('#name').on('change', function() {
        $('#modal-loader').modal('show');
        var emp_id = $(this).val();

        if (emp_id) {

            $.ajax({
                type: "POST",
                url: "complaint_change.php",
                data: {
                    'emp_id': emp_id,
                },
                beforeSend: function() {
                    $("#view-model").html(""); 
                },
                success: function(data) {
                    var parsed_data = JSON.parse(data);
                    // $("#house_id").val(parsed_data.houseID);
                    $("#email").val(parsed_data.email);
                    $("#phone").val(parsed_data.phone);
                    $("#employee_id").val(parsed_data.employee_id);
                    $('#modal-loader').modal('hide');
                    back_complaints();
                    button_click();
                    house_number_select();
                }
            });
        }
    });
    // get the ADDRESS AND GST NO


    //Code For adding new Complaint
    function addItems(th) {
        var tds = '<tr> <td class = "sl" style = "width:1%" > <?php $count++; ?> < /td> ';
        tds += '<td style = "width:15%" > ';
        tds += '<select name = "job_category"  id = "job_category" class = "form-control rec job_category" onChange="job_category_select(this.value,this) , job_category_select1(this.value,this)">';
        tds += '<option value = "" > Select Job Category Type </option>';
        <?php
        $sql = "SELECT * FROM job_category  WHERE is_deleted='N' ORDER BY id DESC";
        $result = $conn->query($sql);
        while ($row1 = $result->fetch_assoc()) {
        ?>
            tds += '<option value ="<?= $row1['id']; ?>" > <?php echo $row1['job_category']; ?> </option>';
        <?php
        }
        ?>
        tds += '</select> ';


        tds += '<select name ="job_sub_category"  id ="job_sub_category" class = "form-control rec job_sub_category" onChange="job_sub_category_select(this.value,this)">';
        tds += '<option value = "" > Select Job Sub Category Type </option>';
        tds += '</select>';

        tds += '<select class="form-control rec producccttt" name="type_of_job[]" id="type_of_job" onChange="job_select(this.value,this)">';
        tds += '<option value="">Select Job Name</option>';
        tds += '</select>';
        tds += '</td>';

        tds += '<td style = "width:30%"> <textarea name = "complaint_description[]" id = "complaint_description[]"  class = "form-control rec"  placeholder = "Complaint Description" required> </textarea>';
        tds += 'Repeat Complain <input type = "checkbox" id = "repeat_complaint" name = "repeat_complaint[]" class="repeat_complaint" onclick="check_complaint(this.value,this)">';
        tds +='<div class="select_repect_complaint"></div>';
        tds += '</td>';

        tds += '<td style = "width:15%">';
        tds += '<select class = "form-control rec allocated_to" name = "allocated_to[]" id = "allocated_to"> ';
        tds += '<option value = "" > Select Workman </option>';     
        tds += '</select><hr><label>Estimated Date of Completion</label><input type="text" name="find_slg[]" id="find_slg" placeholder ="SLG" readonly class="form-control rec"> </td>';
        tds += '<td style = "width:1%" > <a href = "javascript:void(0)" title = "ADD" onclick = "addItems(this)" class = "tab-index" > <i class = "fa fa-plus-circle fa-2x" > </i></a > </td>';
        tds += '</tr>';


        $(th).find('> i').addClass('fa-times-circle');
        $(th).find('> i').removeClass('fa-plus-circle');
        $(th).attr('onclick', '$(this).closest("tr").remove();setSl();');
        $(th).attr('title', 'DELETE');

        $("#items_list").append(tds);
        $('.job_category').select2({ selectOnClose: true});
        $('.producccttt').select2({ selectOnClose: true});
        $('.allocated_to').select2({ selectOnClose: true});

        setSl();
    }

    function setSl() {
        var i = 0;
        $(".sl").each(function(e) {
            i++;
            $(this).html(i);
        })
    }


    //  INSERT DATA 
    $(document).on('submit', '#add_complain', function(e) {
        $('#modal-loader').modal('show');
        e.preventDefault();       
         $("#table_app_complaint").html("");            
        $.ajax({
            method: "POST",
            url: "complaint_add.php",
            data: $(this).serialize(),
            success: function(data) {
                $('#add_complain')[0].reset();
                $('#add_complain').find('input').val('');
                $('#save').val('Log Complaint');
                $('#add_complain').find('select').val('');
                $('#add_complain').find('textarea').val('');
                $("select").val("");
                $('#back_complain').hide();
                $('#button_div').hide();
                $('#myModal111').modal('show');
                $('#table_app_complaint').append(`<div class="modal-body1">`);
                $('#table_app_complaint').append(data);
                $('#table_app_complaint').append(`</div>`);
                $('#modal-loader').modal('hide');
               $('.select_repect_complaint').css("display", "none");
               $('.select_repect_complaint').html("");
               $('.repeat_complaint').prop('checked', false);
            }
        });
    });



    function job_category_select(items, th) {
        $('#modal-loader').modal('show');
        $(th).closest('tr').find('.select_repect_complaint').css("display", "none");
        var job_cat_id = items;
        $('.job_sub_category').select2({ selectOnClose: true});
        if (job_cat_id) {
            $.ajax({
                type: "POST",
                url: "get_all_data.php",
                data: {
                    'job_cat_id': job_cat_id,
                },
                beforeSend: function() {
                    //$("#job_category").html("");
                    // $("#job_sub_category").html("");
                    //  $("#type_of_job").html("");
                    //  $("#find_slg").html("");
                    $(th).closest('tr').find('#type_of_job').html('');
                    $(th).closest('tr').find('#find_slg').html('');
                    $(th).closest('tr').find('#job_sub_category').html('');
                    $(th).closest('tr').find('.repeat_complaint').prop('checked', false);
                },
                success: function(data) {

                    $(th).closest('tr').find('#job_sub_category').html(data);
                    $('#modal-loader').modal('hide');
                }
            });
        }
    }



    function job_sub_category_select(items, th) {
        $('#modal-loader').modal('show');
        $(th).closest('tr').find('.select_repect_complaint').css("display", "none");
        var job_sub_cat_id = items;

        if (job_sub_cat_id) {
            $('.producccttt').select2({ selectOnClose: true});
            $.ajax({
                type: "POST",
                url: "get_all_data.php",
                data: {
                    'job_sub_cat_id': job_sub_cat_id,
                },
                beforeSend: function() {
                    //     $("#type_of_job").html("");
                    //$("#job_category").html("");
                    // $("#job_sub_category").html("");
                    //  $("#type_of_job").html("");
                    //  $("#find_slg").html("");
                    $(th).closest('tr').find('#type_of_job').html('');
                    $(th).closest('tr').find('#find_slg').html('');
                    $(th).closest('tr').find('.repeat_complaint').prop('checked', false);
                },
                success: function(data) {
                    $(th).closest('tr').find('#type_of_job').html(data);
                    $('#modal-loader').modal('hide');
                }
            });
        }
    }

    function job_select(items, th) {
        $('#modal-loader').modal('show');
        $(th).closest('tr').find('.select_repect_complaint').css("display", "none");
        var job_id = items;
        //alert(job_id);
        if (job_id) {
            $.ajax({
                type: "POST",
                url: "get_all_data.php",
                data: {
                    'job_id': job_id,
                },
                beforeSend: function() {
                    //  $("#job_sub_category").html("");
                    $(th).closest('tr').find('.repeat_complaint').prop('checked', false);
                },
                success: function(data) {
                    // alert(data);
                    //  var parsed_data = JSON.parse(data);
                    //$(th).closest('tr').find('#find_slg').val(parsed_data.slg);   
                    $(th).closest('tr').find('#find_slg').val(data);
                    $('#modal-loader').modal('hide');
                }
            });
        }
    }

    function job_category_select1(items, th) {
        $('#modal-loader').modal('show');
        var job_cat_id_w = items;
        if (job_cat_id_w) {

            $.ajax({
                type: "POST",
                url: "get_all_data.php",
                data: {
                    'job_cat_id_w': job_cat_id_w,
                },
                beforeSend: function() {
                    // $("#allocated_to").html("");
                },
                success: function(data) {

                    $(th).closest('tr').find('#allocated_to').html(data);
                    $('#modal-loader').modal('hide');
                }
            });
        }
    }

    function back_complaints() {
        $('#modal-loader').modal('show');
        var employee_id = $('#employee_id').val();
        if (employee_id) {

            $.ajax({
                type: "POST",
                url: "get_all_data.php",
                data: {
                    'employee_id': employee_id,
                },
                beforeSend: function() {
                    $("#back_complain").html("");
                },
                success: function(data) {

                    $("#back_complain").html(data);
                    $('#modal-loader').modal('hide');
                }
            });
        }
    }

    function button_click() {
        $('#modal-loader').modal('show');
        var employee_id = $('#employee_id').val();
        if (employee_id) {

            $.ajax({
                type: "POST",
                url: "get_all_data.php",
                data: {
                    'employee_id_for_house': employee_id,
                },
                beforeSend: function() {
                    $("#button_div").html("");
                },
                success: function(data) {
                    $("#button_div").html(data);
                    $('#modal-loader').modal('hide');
                }
            });
        }
    }
    function house_number_select() {
        $('#modal-loader').modal('show');
        var employee_id = $('#employee_id').val();        
        if (employee_id) {

            $.ajax({
                type: "POST",
                url: "complaint_change.php",
                data: {
                    'employee_id1': employee_id,
                },
                beforeSend: function() {
                    $("#house_id").html("");
                },
                success: function(data) {

                    $("#house_id").html(data);
                    $('#modal-loader').modal('hide');
                }
            });
        }
    }
    // ------------------------check repeat complaint----------
    function check_complaint(items, th) {
        $('#modal-loader').modal('show');
        var employee_id = $('#employee_id').val();
        var type_of_job= $(th).closest('tr').find('#type_of_job').val();
        $(th).closest('tr').find('.select_repect_complaint').css("display", "none");
        if (type_of_job) {

            $.ajax({
                type: "POST",
                url: "complaint_change.php",
                data: {
                    'employee_id22': employee_id,
                    'type_of_job22':type_of_job
                },
                beforeSend: function() {
                    $(th).closest('tr').find('.select_repect_complaint').html("");
                },
                success: function(data) {
                    if(data){
                        $(th).closest('tr').find('.repeat_complaint').prop('checked', true);
                        $(th).closest('tr').find('.select_repect_complaint').css("display", "block");
                        $(th).closest('tr').find('.select_repect_complaint').html(data);          
                    }
                        $('#modal-loader').modal('hide');
                }
            });
        }
    }
    // ----------------------------------------------------
    $(document).ready(function() {
        $('.job_category').select2({ selectOnClose: true});
        $('.allocated_to').select2({ selectOnClose: true});

        $('#reservation').daterangepicker();

        $('#myModal').on('show.bs.modal', function(e) {
            $('#modal-loader').modal('show');
            $('#table_app').html("");
            var iddetails = $(e.relatedTarget).data('id');
            $.ajax({
                method: 'POST',
                url: "get_all_data.php",
                data: {
                    'employee_house_id': iddetails,
                }
            }).done(function(data) {
                // console.log(data);
                $('#table_app').append(`<div class="modal-body1">`);
                $('#table_app').append(data);
                $('#table_app').append(`</div>`);
                $('#modal-loader').modal('hide');
            });
        });
    });
</script>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog  modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title contenttoshow" id="abc">House</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div id="table_app">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<!-- model  -->
<script>
    $(document).ready(function() {

        // $('#reservation').daterangepicker();

        $('#myModal1').on('show.bs.modal', function(e) {
            $('#modal-loader').modal('show');
            $('#table_app').html("");
            var iddetails = $(e.relatedTarget).data('id');
            $.ajax({
                method: 'POST',
                url: "get_all_data.php",
                data: {
                    'employee_information_id': iddetails,
                }
            }).done(function(data) {
                // console.log(data);
                $('#table_app1').append(`<div class='modal-body1'>`);
                $('#table_app1').html(data);
                $('#table_app1').append(`</div>`);
                $('#modal-loader').modal('hide');
            });
        });
    });
</script>
<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog  modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title contenttoshow" id="abc">Employee Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div id="table_app1">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="myModal111" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog  modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title contenttoshow" id="abc">Complaint Logged!</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div id="table_app_complaint">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<div class="modal" id="modal-loader" style="z-index:1000000000">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body" style="z-index:1000000000">
                <img class="mx-auto d-block" src="dist/img/loader.gif" />
                <p class="text-center">Please Wait</p>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
