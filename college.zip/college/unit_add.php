<?php
session_start();

include("../inc/db_conn.php");
//$db=$conn;// database connection  
$myid = $_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');
$unit_name   = $_POST['unit_name'];


$EXE   = mysqli_query($conn, "INSERT INTO unit SET unit_name = '$unit_name', created_by='$myid',created_date_time='$date'");

?>