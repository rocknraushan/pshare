<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$myid = $_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');
$count = 1;
$id = $_POST['id'];
    $sql1 = "SELECT complaint.* ,workman.workman_name,jobs.jobs_name,employee.name,employee.p_number,employee.phone
    FROM complaint 
    LEFT JOIN workman ON complaint.allocated_to = workman.id
    LEFT JOIN jobs ON complaint.type_of_job = jobs.id 
    LEFT JOIN employee ON complaint.employee_id = employee.id 
    ORDER BY complaint.id DESC";

$result1 = mysqli_query($conn, $sql1);
while ($row1 = mysqli_fetch_assoc($result1)) {
?>
    <tr onclick="window.location.href = 'complaint_edit.php?id=<?= md5($row1['id']); ?>';">
        <td><?= $count++; ?></td>
        <td><?= date('d-m-Y h:i A', strtotime($row1['complaint_login_datetime'])); ?> </td>
        <td>C/<?= date('m-Y', strtotime($row1['complaint_login_datetime'])); ?>/<?= $row1['complaint_number']; ?> </td>
        <td><?= $row1['name']; ?> </td>
        <td><?= $row1['p_number']; ?> </td>
        <td><?= $row1['phone']; ?> </td>
        <td><?= $row1['jobs_name']; ?></td>
        <td><?= $row1['complaint_description']; ?> </td>
        <td><?= $row1['workman_name']; ?></td>

        <?php if ($row1['complaint_status'] == 'Pending_For_Allocation') {
            $status = "Pending for Job Card";
            $cl = "info";
        } elseif ($row1['complaint_status'] == 'Pending_For_Workman') {
            $status = "Work in Progress";
            $cl = "info";
        } elseif ($row1['complaint_status'] == 'Pending_For_Closer') {
            $status = "Pending for Closure";
            $cl = "info";
        } elseif ($row1['complaint_status'] == 'Closer') {
            $status = "Closed";
            $cl = "success";
        }
        ?>
        <td><span class="badge badge-<?= $cl ?>"><?= $status ?></span></td>
    </tr>
<?php
}

?>