<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$myid = $_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');

$job_cat_id = $_POST['job_cat_id'];
$jobs_cat_id_edit = $_POST['jobs_cat_id_edit'];
$job_sub_cat_id = $_POST['job_sub_cat_id'];
$job_cat_id_w = $_POST['job_cat_id_w'];
$employee_id = $_POST['employee_id'];
$job_id = $_POST['job_id'];
$material_id = $_POST['material_id'];
$material_id_workman = $_POST['material_id_workman'];
$api = $_POST['api'];
$workman_id = $_POST['workman_id'];
$workman_id_for_material = $_POST['workman_id_for_material'];
$api1 = $_POST['api1'];
$roleid = $_POST['roleid'];
$user_role_id = $_POST['user_role_id'];
$user_role_data_show = $_POST['user_role_data_show'];
$employee_house_id = $_POST['employee_house_id'];
$employee_id_for_house = $_POST['employee_id_for_house'];
$employee_information_id = $_POST['employee_information_id'];
$complaint_information_id = $_POST['complaint_information_id'];
if ($job_cat_id) {
    $sql1 = "SELECT * FROM job_sub_category WHERE job_category='$job_cat_id'";
    $result1 = mysqli_query($conn, $sql1);
?>
    <option value=" ">Select Job Sub Category</option>
    <?php
    while ($row1 = mysqli_fetch_assoc($result1)) {
    ?>
        <option value="<?= $row1['id']; ?>"><?= $row1['job_sub_category']; ?></option>
    <?php
    }
} elseif ($jobs_cat_id_edit) {
    $sql1 = "SELECT * FROM job_sub_category WHERE job_category='$jobs_cat_id_edit'";
    $result1 = mysqli_query($conn, $sql1);
    while ($row1 = mysqli_fetch_assoc($result1)) {
    ?>
        <option value="<?= $row1['id']; ?>"><?= $row1['job_sub_category']; ?></option>
    <?php
    }
} elseif ($job_sub_cat_id) {
    $sql1 = "SELECT * FROM jobs WHERE jobs_sub_category_id='$job_sub_cat_id'";
    $result1 = mysqli_query($conn, $sql1);
    ?>
    <option value="">Select Job Name</option>
    <?php
    while ($row1 = mysqli_fetch_assoc($result1)) {
    ?>
        <option value="<?= $row1['id']; ?>"><?= $row1['jobs_name']; ?></option>
    <?php
    }
} elseif ($job_cat_id_w) {
    $sql1 = "SELECT workman.id,workman.workman_name FROM job_workman 
             LEFT JOIN workman ON job_workman.workman_id = workman.id 
             WHERE job_workman.job_category_id='$job_cat_id_w' GROUP BY workman.id";
    $result1 = mysqli_query($conn, $sql1);
    ?>
    <option value="">Select Workman Name</option>
    <?php
    while ($row1 = mysqli_fetch_assoc($result1)) {
        $id_count = $row1['id'];
        $dt = date('Y-m-d', strtotime($date));
        $sql5 = "SELECT count(allocated_to) AS pending_job FROM complaint  WHERE allocated_to = '$id_count' AND complaint_status!='Closer'";
        $result5 = mysqli_query($conn, $sql5);
        $row5 = mysqli_fetch_assoc($result5);
    ?>
        <option value="<?= $row1['id']; ?>"><?= $row1['workman_name']; ?> (Pending Jobs - <?= $row5['pending_job']; ?>) </option>
    <?php
    }
} elseif ($employee_id) {
    $sql1 = "SELECT complaint.* ,house.house_number,house_type.house_type,jobs.jobs_name
    FROM complaint 
    LEFT JOIN house ON complaint.house_id = house.id
    LEFT JOIN house_type  ON house.house_type = house_type.id
    LEFT JOIN jobs ON complaint.type_of_job = jobs.id
    WHERE employee_id ='$employee_id'  GROUP BY complaint.id ORDER BY complaint.id DESC LIMIT 5";
    $result1 = mysqli_query($conn, $sql1); ?>
    <table class="table table-bordered table-hover table-condensed">
        <tr>
            <th>#</th>
            <th>Date of Complaint</th>
            <th>Complaint No</th>
            <th>House Number</th>
            <th>Job</th>
            <th>Complaint Description</th>
            <th>Status</th>
        </tr>
        <?php
        $count = 1;
        while ($row1 = mysqli_fetch_assoc($result1)) {
        ?>
            <!-- <tr onclick="window.location.href = 'complaint_edit.php?id=<?= md5($row1['id']); ?>','_blank'; return false; "> -->
            <tr onclick="window.open('complaint_edit.php?id=<?= md5($row1['id']); ?>')">
                <td><?= $count++; ?> </td>
                <td><?= date('d-m-Y h:i A', strtotime($row1['complaint_login_datetime'])); ?> </td>
                <td>C/<?= date('m-Y', strtotime($row1['complaint_login_datetime'])); ?>/<?= $row1['complaint_number']; ?> </td>
                <td><?= $row1['house_type'] . "-" . $row1['house_number']; ?> </td>
                <td><?= $row1['jobs_name']; ?> </td>
                <td><?= $row1['complaint_description']; ?> </td>
                <?php if ($row1['complaint_status'] == 'Pending_For_Allocation') {
                    $status = "Pending for Job Card";
                    $cl = "info";
                } elseif ($row1['complaint_status'] == 'Pending_For_Workman') {
                    $status = "Work in Progress";
                    $cl = "info";
                } elseif ($row1['complaint_status'] == 'Pending_For_Closer') {
                    $status = "Pending for Closure";
                    $cl = "info";
                } elseif ($row1['complaint_status'] == 'Closer') {
                    $status = "Closed";
                    $cl = "success";
                }

                ?>
                <td><span class="badge badge-<?= $cl ?>"><?= $status ?></span></td>

            </tr>
        <?php
        }
        ?>

    </table>
<?php
} elseif ($job_id) {
    $Date = date('d-m-Y');
    $row1 = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM jobs WHERE id='$job_id'"));
    $find_slg = $row1['slg'];
    $data = date('d-m-Y', strtotime($Date . ' + ' . $find_slg . ' days'));
    echo $data;
} elseif ($material_id) {
    $data = array();

    $sql1 = "SELECT SUM(quantity) FROM txn_logs WHERE material_id='$material_id' AND type='IN' and stock_userid='0'";
    $result1 = mysqli_query($conn, $sql1);
    $row1 = mysqli_fetch_assoc($result1);
    $total_in = $row1['SUM(quantity)'];

    $sql2 = "SELECT SUM(quantity) FROM txn_logs WHERE material_id='$material_id' AND type='OUT' and stock_userid='0' ";
    $result2 = mysqli_query($conn, $sql2);
    $row2 = mysqli_fetch_assoc($result2);
    $total_out = $row2['SUM(quantity)'];

    $data = $total_in - $total_out;
    echo json_encode($data);
} elseif ($api1) {
    //  echo $workman_id_for_material;
    $sql1 = "SELECT material.id , material.material_name
    FROM txn_logs
    LEFT JOIN material ON txn_logs.material_id = material.id
    WHERE  txn_logs.stock_userid='$workman_id_for_material' GROUP BY material.id ORDER BY material.id DESC";
    $result1 = mysqli_query($conn, $sql1);
?>
    <option value="">Select Material</option>
    <?php
    while ($materiallist = mysqli_fetch_assoc($result1)) {
    ?>
        <option value="<?= $materiallist['id']; ?>"><?php echo $materiallist['material_name']; ?></option>
    <?php
    }
} elseif ($api) {
    $data = array();

    $sql1 = "SELECT SUM(quantity) FROM txn_logs WHERE material_id='$material_id_workman' AND stock_userid='$workman_id' AND type='IN' ";
    $result1 = mysqli_query($conn, $sql1);
    $row1 = mysqli_fetch_assoc($result1);
    $total_in = $row1['SUM(quantity)'];

    $sql2 = "SELECT SUM(quantity) FROM txn_logs WHERE material_id='$material_id_workman'  AND stock_userid='$workman_id' AND type='OUT' ";
    $result2 = mysqli_query($conn, $sql2);
    $row2 = mysqli_fetch_assoc($result2);
    $total_out = $row2['SUM(quantity)'];

    $data = $total_in - $total_out;
    echo json_encode($data);
} elseif (!empty($roleid)) {
    //echo 'hii';
    $rolename  = mysqli_query($conn, "SELECT * FROM role_permission WHERE role_master_id='$roleid'");
    $role = array();
    while ($row = mysqli_fetch_assoc($rolename)) {
        $role[] = $row['permission_master_id'];
    }
    $getfiles = "SELECT * FROM permission_master";
    $execute = mysqli_query($conn, $getfiles);
    while ($row = mysqli_fetch_assoc($execute)) { ?>
        <input type="checkbox" name="permission_master_id_edit[]" <?php if (array_intersect($role, $row))  echo 'checked'; ?> value="<?php echo $row['id'] ?>">&nbsp;&nbsp;&nbsp;<label for=""> <?php echo $row['name'] . "\t(" . $row['file_name'] . ")" ?> </label><br>
    <?php   }
} elseif ($user_role_data_show) {

    if ($user_role_id == '0' || $user_role_id == "") {
        $userRoleQuery  = mysqli_query($conn, "SELECT  `file_name`, `name` FROM permission_master");
    } else {
        $userRoleQuery  = mysqli_query($conn, "SELECT permission_master.file_name,permission_master.name
        FROM role_master
        LEFT JOIN role_permission ON role_master.id=role_permission.role_master_id
        LEFT JOIN permission_master ON role_permission.permission_master_id=permission_master.id
        WHERE role_master.id=1 AND role_master.is_deleted='N'");
    } ?>
    <table class="table table-bordered table-hover table-condensed">
        <tr>
            <th>File Name</th>
            <th>Permition</th>
        </tr>
        <?php
        while ($userRoleList = mysqli_fetch_assoc($userRoleQuery)) { ?>
            <tr>
                <td> <?= $userRoleList['file_name']; ?></td>
                <td><?= $userRoleList['name']; ?></td>
            </tr>
        <?php } ?>
    </table>
<?php
} elseif ($employee_house_id) {



    $employeehouseQuery  = mysqli_query($conn, "SELECT employee_house.created_date_time,house.house_number,house_type.house_type
                    FROM `employee_house` 
                    LEFT JOIN house ON employee_house.house_id=house.id
                    LEFT JOIN house_type ON house.house_type=house_type.id
                    WHERE employee_house.employee_id='$employee_house_id'");
?>
    <table class="table table-bordered table-hover table-condensed">
        <tr>
            <th>#</th>
            <th>House Number</th>
            <th>Created Datetime</th>
        </tr>
        <?php
        $count = 1;
        while ($employeehouseList = mysqli_fetch_assoc($employeehouseQuery)) { ?>
            <tr>
                <td><?= $count++; ?> </td>
                <td><?= $employeehouseList['house_type']; ?>-<?= $employeehouseList['house_number']; ?></td>
                <td><?= date('d-m-Y h:i A', strtotime($employeehouseList['created_date_time'])) ?></td>
            </tr>
        <?php } ?>
    </table>
<?php
} elseif ($employee_id_for_house) { ?>
    <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#myModal1" data-id="<?= $employee_id_for_house ?>" data-keyboard="false" data-backdrop="static">View Profile</button>
    <button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#myModal" data-id="<?= $employee_id_for_house ?>" data-keyboard="false" data-backdrop="static">View Past Occupancy</button>
<?php } elseif ($employee_information_id) {

    $employeeinformationList  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT e.name,e.p_number,e.email,e.alternative_email,e.phone,e.alternative_phone,e.intercom_nunber,house.house_number,house_type.house_type 
                            FROM employee e
                            LEFT JOIN house ON e.house_id = house.id
                            LEFT JOIN house_type ON house.house_type = house_type.id     
                            WHERE e.id='$employee_information_id'")); ?>
    <table class="table table-bordered table-hover table-condensed">
        <tr>
            <th>Name</th>
            <td><?= $employeeinformationList['name'] ?></td>
        </tr>
        <tr>
            <th>Email</th>
            <td><?= $employeeinformationList['email'] ?></td>
        </tr>
        <tr>
            <th>Alternative Email</th>
            <td><?= $employeeinformationList['alternative_email'] ?></td>
        </tr>
        <tr>
            <th>Phone</th>
            <td><?= $employeeinformationList['phone'] ?></td>
        </tr>
        <tr>
            <th>Alternative Phone</th>
            <td><?= $employeeinformationList['alternative_phone'] ?></td>
        </tr>
        <tr>
            <th>Intercom Number</th>
            <td><?= $employeeinformationList['intercom_nunber'] ?></td>
        </tr>
        <tr>
            <th>Personal Number</th>
            <td><?= $employeeinformationList['p_number'] ?></td>
        </tr>
        <tr>
            <th>House</th>
            <td><?php echo $employeeinformationList['house_type']; ?>-<?php echo $employeeinformationList['house_number']; ?></td>
        </tr>
    </table>
<?php
} ?>