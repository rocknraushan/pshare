<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$head = "password";
$page = "password";
include("layouts/header.php");
$userID = $_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
if (isset($_POST['save'])) {
   $old_password     = addslashes($_POST['old-password']);
   $password         = addslashes($_POST['password']);
   $confirm_password = addslashes($_POST['confirm-password']);
   // --------------------------------------
   if (strlen($confirm_password) <= '7') {
?>
      <script>
         alert("Your Password Must Contain At Least 7 Digits !");
      </script>
   <?php
   } elseif (!preg_match("#[0-9]+#", $confirm_password)) { ?>
      <script>
         alert("Your Password Must Contain At Least 1 Number !");
      </script>
   <?php } elseif (!preg_match("#[A-Z]+#", $confirm_password)) { ?>
      <script>
         alert("Your Password Must Contain At Least 1 Capital Letter !");
      </script>
   <?php } elseif (!preg_match("#[a-z]+#", $confirm_password)) { ?>
      <script>
         alert("Your Password Must Contain At Least 1 Lowercase Letter !")
      </script>
   <?php } elseif (!preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬-]/', $confirm_password)) { ?>
      <script>
         alert("Your Password Must Contain At Least 1 Special Character !");
      </script>
      <?php  } else {
      // ------------------------------------------
      $Query = mysqli_query($conn, "SELECT * FROM user WHERE id ='$userID'");
      $users = mysqli_fetch_array($Query);
      $userExist     = $users['id'];
      $existPassword = $users['password'];
      //$OldPassword   = md5($old_password);
      $OldPassword   = $old_password;
      if ($existPassword == $OldPassword) {
         if ($password == $confirm_password) {
            //  $yes = md5($confirm_password);
            $yes = $confirm_password;
            $UpdatePass  = mysqli_query($conn, "UPDATE user SET password = '$yes' WHERE id = '$userExist'"); ?>
            <script>
               window.location.href = 'change-password.php?status=success';
            </script>
         <?php } else { ?>
            <script>
               window.location.href = 'change-password.php?status=error';
            </script>
         <?php
         }
      } else { ?>
         <script>
            window.location.href = 'change-password.php?status=error2';
         </script>
      <?php
      }
   }
}

if (isset($_POST['update'])) {
   $token = addslashes($_POST['token']);
   $user_name   = addslashes($_POST['user-name']);
   $pass_word   = addslashes($_POST['pass-word']);

   $sql = mysqli_query($conn, "UPDATE user SET user_name='$user_name', password='$pass_word' WHERE id='$token'");

   if ($sql) {
      ?>
      <script>
         window.location.href = 'user.php?status=success';
      </script>
   <?php
   } else {
   ?>
      <script>
         window.location.href = 'user.php?status=error';
      </script>
<?php
   }
}
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
   <!-- Content Header (Page header) -->
   <div class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6">
               <h1 class="m-0">Change Password</h1>
            </div>
         </div><!-- /.row -->
      </div><!-- /.container-fluid -->
   </div><!-- /.content-header -->

   <!-- Main content -->
   <div class="content">
      <div class="container-fluid">
         <div class="row">
            <div class="col-lg-12">
               <?php
               if (isset($_REQUEST['status']) && $_REQUEST['status'] == 'success') {
               ?>
                  <div class="alert alert-success">
                     <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                     <strong>Success!</strong> Submitted Successfully
                  </div>
               <?php
               }
               if (isset($_REQUEST['status']) && $_REQUEST['status'] == 'error') {
               ?>
                  <div class="alert alert-danger">
                     <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                     <strong>Failed!</strong> New and Confimed Password doesn't Matched.
                  </div>
               <?php
               }
               if (isset($_REQUEST['status']) && $_REQUEST['status'] == 'error2') {
               ?>
                  <div class="alert alert-danger">
                     <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                     <strong>Failed!</strong> Old Password doesn't Matched.
                  </div>
               <?php
               }
               ?>
               <form action="change-password.php" method="post">
                  <div class="card">
                     <div class="card-header border-0">
                        <div class="d-flex justify-content-between">
                           Change Password
                        </div>
                     </div>
                     <div class="card-body" style="width:50%;">
                        <p class="login-box-msg">You are only one step a way from your new password,Please Fill Details.</p>
                        <div class="input-group mb-3">
                           <input type="password" class="form-control" required name="old-password" placeholder="Old Password">
                           <div class="input-group-append">
                              <div class="input-group-text"><span class="fas fa-lock"></span></div>
                           </div>
                        </div>
                        <div class="input-group mb-3">
                           <input type="password" class="form-control" required name="password" placeholder="Password">
                           <div class="input-group-append">
                              <div class="input-group-text"><span class="fas fa-lock"></span></div>
                           </div>
                        </div>
                        <div class="input-group mb-3">
                           <input type="password" class="form-control" required name="confirm-password" placeholder="Confirm Password">
                           <div class="input-group-append">
                              <div class="input-group-text"><span class="fas fa-lock"></span></div>
                           </div>
                        </div>
                        <div class="row">
                           <div class="col-12">
                              <input type="submit" name="save" class="btn btn-primary btn-block" value="Change password">
                           </div>
                        </div>
                        <small style="color:red"> <i>
                           <ul>
                              <li >Your Password Must Contain At Least 7 Digits !</li>
                              <li> Your Password Must Contain At Least 1 Number !</li>
                              <li>Your Password Must Contain At Least 1 Capital Letter !</li>
                              <li>Your Password Must Contain At Least 1 Lowercase Letter !</li>
                              <li>Your Password Must Contain At Least 1 Special Character !</li>
                           </ul>
                        </i></small>
                     </div>
                  </div>
               </form>
            </div>
         </div>
      </div>
   </div><!-- /.content -->
</div>
<!-- /.content-wrapper -->

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
   <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->

</div>
</body>
<?php
include("layouts/footer.php");
?>