<table class="table table-bordered table-hover table-condensed">
  <tr>
    <th>SI No.</th>
    <th>Date Of Complaint</th>
    <th>House Number</th>
    <th>Job</th>
    <th>Complaint Description</th>
    <th>Complaint Number</th>
    <th>Estimated Date Of Completion</th>
  </tr>
  <?php
  session_start();

  include("../inc/db_conn.php");
  $myid = $_SESSION['userid'];
  date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
  $date = date('Y-m-d H:i:s');
  $count = 1;
  $name   = $_POST['name'];

  $month = date('m', strtotime($date));
  $year  = date('Y', strtotime($date));

  $employee_id = $_POST['employee_id'];

  $house_id       = $_POST['house_id'];

  foreach ($_POST['type_of_job'] as $key => $value) {
    $type_of_job   = $_POST['type_of_job'][$key];
    $complaint_description   = $_POST['complaint_description'][$key];
    $allocated_to       = $_POST['allocated_to'][$key];
    $estimated_date = $_POST['find_slg'][$key];
    $estimated_date_of_completion  = date('Y-m-d', strtotime($estimated_date));
    $repeat_complaint = $_POST['repeat_complaint'][$key];
    if($repeat_complaint){
      if($_POST['repeat_complaint_id'][$key]){
        $repeat_complaint_id=$_POST['repeat_complaint_id'][$key];
        }else{
          $repeat_complaint_id=0;
        }
    }else{
      $repeat_complaint_id=0;
    }
    if ($allocated_to) {
      $complaint_status = 'Pending_For_Workman';
      $allocated_to_id = $allocated_to;
      $allocated_datetime = $date;
      $allocated_by = $myid;
    } else {
      $complaint_status = 'Pending_For_Allocation';
      $allocated_to_id = "";
      $allocated_datetime = "";
      $allocated_by = "";
    }
    // $estimated_date_of_completion =  date('Y-m-d', strtotime($Date. ' + '.$find_slg.' days'));

    $row2 = mysqli_fetch_assoc(mysqli_query($conn, "SELECT complaint_number AS slno from complaint WHERE  YEAR(complaint_login_datetime)='$year' AND MONTH(complaint_login_datetime)='$month' order by id DESC LIMIT 1"));
    if ($row2['slno']) {
      $c_no = $row2['slno'] + 1;
    } else {
      $c_no = 1;
    }
    $EXE   = mysqli_query($conn, "INSERT INTO complaint SET  employee_id='$employee_id', house_id='$house_id',complaint_login_datetime='$date',complaint_logged_by_id='$myid',
       allocated_by='$allocated_by',allocated_to='$allocated_to_id',allocated_datetime='$allocated_datetime',type_of_job='$type_of_job',complaint_description='$complaint_description',complaint_logged_by_type='Helpdesk',complaint_number='$c_no',repeat_complaint='$repeat_complaint',estimated_date_of_completion='$estimated_date_of_completion',complaint_status='$complaint_status',repeat_complaint_id='$repeat_complaint_id' ");
    $q1 = mysqli_query($conn, "select house.id as houseID,house.house_number,house_type.house_type from house_type
                                INNER JOIN house ON house.house_type = house_type.id WHERE house.id='$house_id'");
    while ($listofAvilHouse = mysqli_fetch_assoc($q1)) {
      $h_type = $listofAvilHouse['house_type'];
      $h_number = $listofAvilHouse['house_number'];
    }
    $q5 = mysqli_query($conn, "SELECT workman_name,workman_mobile,vender_mobile FROM workman WHERE id='$allocated_to'");
    while ($workmanname = mysqli_fetch_assoc($q5)) {
      $workman_name = $workmanname['workman_name'];
      $workman_mobile = $workmanname['workman_mobile'];
      $workman_vendor_mobile = $workmanname['vender_mobile'];
    }
  ?>

    <tr>
      <td><?= $count++; ?> </td>
      <td><?= date('d-m-Y', strtotime($date)); ?></td>
      <td><?= $h_type . "-" . $h_number; ?></td>
      <td><?= $workman_name; ?></td>
      <td><?= $complaint_description; ?></td>
      <?php if ($c_no) { ?>
        <td>C/<?= date('m-Y', strtotime($date)) ?>/<?= $c_no ?></td>
      <?php } else {
        echo "-";
      }
      if ($estimated_date) { ?>
        <td><?= date('d-m-Y', strtotime($estimated_date_of_completion)); ?></td>
      <?php }  ?>
    </tr>

  <?php
    // ------------------------------SMS-------------------
    $complaint_number = 'C/' . date('m-Y', strtotime($date)) . '/' . $c_no;
    $estimated_date_of_completion =  date('d-m-Y', strtotime($estimated_date_of_completion));
    $EmployeeList = mysqli_fetch_assoc(mysqli_query($conn, "SELECT phone FROM employee WHERE id='$employee_id'"));
    $employee_mobile = $EmployeeList['phone'];
    $jobList=mysqli_fetch_assoc(mysqli_query($conn,"SELECT `jobs_name` FROM `jobs` WHERE id='$type_of_job'")); 
    $type_of_job11=$jobList['jobs_name'];
    if (strlen($type_of_job11) > 18){
      $type_of_job11 = substr($type_of_job11, 0, 16) . '...';
    }else{
      $type_of_job11=$type_of_job11;
}
    if ($allocated_to) {
     
      $msg = "Dear Employee,";
      $msg .= "\nYour Complaint No $complaint_number has been assigned to $workman_name / Mobile No - $workman_mobile. Estimated Completion Date is $estimated_date_of_completion.";
      $msg .= "\nThanks, Tata Steel Long Products Limited";
      $msg = urlencode($msg);
      file_get_contents("http://gateway9.mbiz.co.in/httpapi/httpapi?token=ec5199c307c1e1f3e809efe526dd5fb0&sender=TSLPMS&number=$employee_mobile&route=2&type=1&sms=$msg&templateid=1607100000000135333");
     //to workman
$msg2="Dear Vendor,";
$msg2.="\nYou have been assigned a Job - $type_of_job11 with Complaint No.$complaint_number. Estimated Completion Date is $estimated_date_of_completion.";
$msg2.="\nThanks, Tata Steel Long Products Limited";
$msg2=urlencode($msg2);
file_get_contents("http://gateway9.mbiz.co.in/httpapi/httpapi?token=ec5199c307c1e1f3e809efe526dd5fb0&sender=TSLPMS&number=$workman_mobile&route=2&type=1&sms=$msg2&templateid=1607100000000135331");
//to workman vendor
$msg2="Dear Vendor,";
$msg2.="\nYou have been assigned a Job - $type_of_job11 with Complaint No.$complaint_number. Estimated Completion Date is $estimated_date_of_completion.";
$msg2.="\nThanks, Tata Steel Long Products Limited";
$msg2=urlencode($msg2);
file_get_contents("http://gateway9.mbiz.co.in/httpapi/httpapi?token=ec5199c307c1e1f3e809efe526dd5fb0&sender=TSLPMS&number=$workman_vendor_mobile&route=2&type=1&sms=$msg2&templateid=1607100000000135331");
 } else {
      // to employee
      $msg = "Dear Employee,";
      $msg .= "\nYou have logged a complaint of $complaint_description and the Complaint No.$complaint_number. Estimated Completion Date is N/A.";
      $msg .= "\nThanks, Tata Steel Long Products Limited";
      $msg = urlencode($msg);
      file_get_contents("http://gateway9.mbiz.co.in/httpapi/httpapi?token=ec5199c307c1e1f3e809efe526dd5fb0&sender=TSLPMS&number=$employee_mobile&route=2&type=1&sms=$msg&templateid=1607100000000135330");
    }

    // -------------------------------SMS End ------------
  }
  ?>
</table>
<?php
