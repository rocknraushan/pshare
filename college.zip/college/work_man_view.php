<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$count = 1;
$date = date('Y-m-d H:i:s');

$sql = "SELECT * FROM workman  WHERE is_deleted='N' ORDER BY id DESC";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
	while ($row = $result->fetch_assoc()) {
		$id = $row['id'];
?>
		<tr>
			<td><?= $count++; ?>
			<td><?= $row['workman_name']; ?></td>
            <td><?= $row['workman_email']; ?></td>
            <td><?= $row['workman_username']; ?></td>
            <td><?= $row['workman_mobile']; ?></td>
            <?php 
                    if($row['workman_type']=='V'){    ?>
                        <td>Vendor Employee</td>
                    <?php
                    }else{ ?>
                        <td>Own Employee</td>
                    <?php
                    }
            ?>
            <td><button type="button" class="btn btn-info btn-sm update" id="reset_password" data-id="<?= $row['id']; ?>"			
			>Reset Password</button></td>                 			
			<td><button type="button" class="btn btn-success btn-sm update" data-toggle="modal"
				 data-keyboard="false" data-backdrop="static" data-target="#modal-update" 
				 data-id="<?= $row['id']; ?>" 
				 data-workman_name="<?= $row['workman_name']; ?>" 
                 data-workman_email="<?= $row['workman_email']; ?>"		
                 data-workman_username="<?= $row['workman_username']; ?>" 
                 data-workman_mobile="<?= $row['workman_mobile']; ?>"
                 data-workman_type="<?= $row['workman_type']; ?>" 
                 data-vender_email="<?= $row['vender_email']; ?>"		
                 data-vender_name="<?= $row['vender_name']; ?>" 
                 data-vender_code="<?= $row['vender_code']; ?>"	
                 data-vender_mobile="<?= $row['vender_mobile']; ?>"			 
				 >Edit</button>
			</td>
			<td><button type="button" class="btn btn-danger btn-sm update" id="delete" data-id="<?= $row['id']; ?>">Delete</button></td>
		</tr>
<?php
	}
} else { 
	echo "<tr >
		<td colspan='5'>No Result found !</td>
		</tr>";
}
mysqli_close($conn);
?>
