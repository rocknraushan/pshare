<?php
session_start();

include("../inc/db_conn.php");
//$db=$conn;// database connection  
$myid = $_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');
$user_name   = $_POST['user_name'];
$p_number   = $_POST['p_number'];
$email       = $_POST['email'];
$alternative_email = $_POST['alternative_email'];
$phone      = $_POST['phone'];
$alternative_phone = $_POST['alternative_phone'];
$inter_com_nunber = $_POST['inter_com_nunber'];
$house_id = $_POST['house_id'];
$pwd=rand(0000,9999);

$result1 = mysqli_query($conn,  "SELECT id FROM workman WHERE workman_username='$p_number'");
$row1 = mysqli_fetch_assoc($result1);
if(!$row1['id'])
{

$EXE   = mysqli_query($conn, "INSERT INTO employee SET name = '$user_name', p_number='$p_number', email='$email',house_id='$house_id',password='$pwd',
         alternative_email ='$alternative_email',intercom_nunber ='$inter_com_nunber', phone = '$phone',alternative_phone='$alternative_phone', created_by='$myid',created_date_time='$date'");
$id = mysqli_insert_id($conn);

$EXE1   = mysqli_query($conn, "INSERT INTO employee_house SET employee_id='$id',house_id='$house_id',status='Active', created_by='$myid',created_date_time='$date'");

$EXE2 = mysqli_query($conn,"UPDATE house SET house_status='Active' WHERE id='$house_id'");
}
if($EXE){
    echo "yes";
    //send email sms
		include "email_message_send.php"; 
        email_sms($email,$phone,$user_name,$pwd);
}else{
    echo "no";
}
