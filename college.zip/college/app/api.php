<?php

use function PHPSTORM_META\type;

include("../inc/db_conn.php");
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$token = $_REQUEST["token"];
$match_token = mysqli_fetch_array(mysqli_query($conn, "select * from token where token='$token'"));
if (!empty($match_token['id'])) {
    $api =  $_REQUEST["api"];
    if ($api == "login") {
        $user = $_REQUEST['username'];
        $pass = $_REQUEST['password'];
        $response = array();

        $qw   = mysqli_query($conn, "SELECT * from workman where workman_username='$user' and workman_password = '$pass'");
        if (mysqli_num_rows($qw) > 0) {
            $data = mysqli_fetch_assoc($qw);
            $response['userid']  = $data['id'];
            $response['role']    = 'Workman';
            $response['name'] = $data['workman_name'];
            $response['email'] = $data['workman_email'];
            $response['username'] = $data['workman_username'];
            $response['mobile'] = $data['workman_mobile'];
            $response['force_pwd'] = $data['force_pwd'];
        } else {
            $qw   = mysqli_query($conn, "select employee.* ,house.house_number,house.id AS houseID,house_type.house_type AS h_type
        from employee 
        LEFT JOIN house ON employee.house_id = house.id
        LEFT JOIN house_type ON house.house_type = house_type.id
        where employee.p_number='$user' and employee.password = '$pass'");
            if (mysqli_num_rows($qw) > 0) {
                $data = mysqli_fetch_assoc($qw);

                $response['userid']  = $data['id'];
                $response['role']    = 'Employee';
                $response['name'] = $data['name'];
                $response['email'] = $data['email'];
                $response['username'] = $data['p_number'];
                $response['mobile'] = $data['phone'];
                $response['houseID'] = $data['houseID'];
                $response['house'] = $data['h_type'] . "-" . $data['house_number'];
                $response['force_pwd'] = $data['force_pwd'];
            } else {
                $response['error']    = 'Wrong Credentials!';
            }
        }
        echo json_encode($response);
    } elseif ($api == "view_pending_complaints") {
        $workman_id = $_REQUEST['workman_id'];
        $limit_from = $_REQUEST['start'];
        $limit_to = $_REQUEST['end'];

        $sql1 = "SELECT complaint.id,complaint.complaint_number,jobs.jobs_name,employee.name,complaint.complaint_login_datetime ,complaint.estimated_date_of_completion,employee.phone,house.house_number,house_type.house_type
        FROM complaint 
        LEFT JOIN workman ON complaint.allocated_to = workman.id
        LEFT JOIN jobs ON complaint.type_of_job = jobs.id 
        LEFT JOIN employee ON complaint.employee_id = employee.id 
        LEFT JOIN house ON complaint.house_id = house.id 
        LEFT JOIN house_type ON house.house_type = house_type.id 
        WHERE complaint.complaint_status='Pending_For_Workman' AND 
        complaint.allocated_to ='$workman_id'  ORDER BY complaint.id  DESC LIMIT $limit_from,$limit_to";

        $data = array();
        $result1 = mysqli_query($conn, $sql1);
        while ($row1 = mysqli_fetch_assoc($result1)) {
            $row1['complaint_number'] = 'C/' . date('m-Y', strtotime($row1['complaint_login_datetime'])) . '/' . $row1['complaint_number'];
            $data[] = $row1;
        }
        echo json_encode($data);
    } elseif ($api == "view_attended_complaints") {
        $workman_id = $_REQUEST['workman_id'];
        $limit_from = $_REQUEST['start'];
        $limit_to = $_REQUEST['end'];

        $sql1 = "SELECT complaint.id,complaint.complaint_status,complaint.complaint_number,jobs.jobs_name,employee.name,complaint.complaint_login_datetime  ,complaint.estimated_date_of_completion,employee.phone,house.house_number,house_type.house_type FROM complaint 
        LEFT JOIN workman ON complaint.allocated_to = workman.id
        LEFT JOIN jobs ON complaint.type_of_job = jobs.id 
        LEFT JOIN employee ON complaint.employee_id = employee.id 
        LEFT JOIN house ON complaint.house_id = house.id 
        LEFT JOIN house_type ON house.house_type = house_type.id 
         
        WHERE complaint.complaint_status='Pending_For_Closer' AND 
        complaint.allocated_to ='$workman_id' ORDER BY complaint.id DESC LIMIT $limit_from,$limit_to";

        $data = array();
        $result1 = mysqli_query($conn, $sql1);
        while ($row1 = mysqli_fetch_assoc($result1)) {
            $row1['complaint_number'] = 'C/' . date('m-Y', strtotime($row1['complaint_login_datetime'])) . '/' . $row1['complaint_number'];
            $data[] = $row1;
        }
        echo json_encode($data);
    } elseif ($api == "view_closed_complaints") {
        $workman_id = $_REQUEST['workman_id'];
        $limit_from = $_REQUEST['start'];
        $limit_to = $_REQUEST['end'];


        $sql1 = "SELECT complaint.id,complaint.complaint_closed_datetime,complaint.complaint_number,jobs.jobs_name,employee.name,complaint.complaint_login_datetime ,workman_feedback.complaint_datetime AS attend_date ,complaint.estimated_date_of_completion,employee.phone,txn_logs.quantity ,material.material_name,house.house_number,house_type.house_type
        FROM complaint 
        LEFT JOIN workman ON complaint.allocated_to = workman.id
        LEFT JOIN jobs ON complaint.type_of_job = jobs.id 
        LEFT JOIN employee ON complaint.employee_id = employee.id 
        LEFT JOIN house ON complaint.house_id = house.id 
        LEFT JOIN house_type ON house.house_type = house_type.id 
        LEFT JOIN workman_feedback ON complaint.id = workman_feedback.complaint_id
        LEFT JOIN txn_logs ON complaint.id = txn_logs.complaint_id
        LEFT JOIN material ON txn_logs.material_id = material.id
         
        WHERE complaint.complaint_status='Closer' AND 
        complaint.allocated_to ='$workman_id' GROUP BY complaint.complaint_number ORDER BY complaint.id DESC LIMIT $limit_from,$limit_to";

        $data = array();
        $rowtemp = array();
        $result1 = mysqli_query($conn, $sql1);
        while ($row1 = mysqli_fetch_assoc($result1)) {
            $row1['complaint_number'] = 'C/' . date('m-Y', strtotime($row1['complaint_login_datetime'])) . '/' . $row1['complaint_number'];
            $data[] = $row1;
        }
        echo json_encode($data);
    } elseif ($api == "view_complaint") {
        $response = array();

        $complaint_id = $_REQUEST['complaint_id'];
        // $complaint_id =1;
        $sql11 = "SELECT complaint.* ,workman.workman_name,jobs.jobs_name,employee.name,employee.email,employee.phone,employee.alternative_phone,employee.intercom_nunber
        FROM complaint 
        LEFT JOIN workman ON complaint.allocated_to = workman.id
        LEFT JOIN jobs ON complaint.type_of_job = jobs.id 
        LEFT JOIN employee ON complaint.employee_id=employee.id
        WHERE complaint.id='$complaint_id' ORDER BY complaint.id DESC ";
        $result11 = mysqli_query($conn, $sql11);
        $row1 = mysqli_fetch_assoc($result11);
        $response['emp_name'] = $row1['name'];
        $response['emp_email'] = $row1['email'];
        $response['emp_phone'] = $row1['phone'];
        $response['emp_alternative_phone'] = $row1['alternative_phone'];
        $response['emp_intercom_number'] = $row1['intercom_nunber'];
        $h_id = $row1['house_id'];
        $response['c_discription'] = $row1['complaint_description'];
        $response['estimated_date_of_completion'] = $row1['estimated_date_of_completion'];
        $t_job = $row1['type_of_job'];
        $id = $row1['id'];
        $response['complaint_login_datetime'] = $row1['complaint_login_datetime'];
        $response['complaint_status'] = $row1['complaint_status'];
        $response['complaint_number'] = 'C/' . date('m-Y', strtotime($row1['complaint_login_datetime'])) . '/' . $row1['complaint_number'];

        $a_to = $row1['allocated_to'];
        $r_complaint = $row1['repeat_complaint'];
        $response['allocated_datetime'] = $row1['allocated_datetime'];
        $all_by = $row1['allocated_by'];
        $complaint_l_by_id = $row1['complaint_logged_by_id'];
        $response['complaint_photo'] = $row1['complaint_photo'];
        $response['repeat_complaint_id'] = @$row1['repeat_complaint_id'];
        if($row1['repeat_complaint_id']){
            $repeat_complaint_list=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * From complaint WHERE id='".$row1['repeat_complaint_id']."'"));
            $response['repeat_complaint_number']='C/' . date('m-Y', strtotime($repeat_complaint_list['complaint_login_datetime'])) . '/' . $repeat_complaint_list['complaint_number'];
        }

        if ($r_complaint == 'on') {
            $response['repeat_complaint'] = "YES";
        } else {
            $response['repeat_complaint'] = "NO";
        }

        $p12 = "SELECT * FROM user WHERE id='$complaint_l_by_id'";
        $r12 = mysqli_query($conn, $p12);
        $p112 = mysqli_fetch_assoc($r12);
        $response['complaint_logged_by_id'] = $p112['user_name'];

        $p1 = "SELECT * FROM user WHERE id='$all_by'";
        $r1 = mysqli_query($conn, $p1);
        $p11 = mysqli_fetch_assoc($r1);
        $response['allocated_by'] = $p11['user_name'];

        $q1 = mysqli_query($conn, "select house.id as houseID,house.house_number,house_type.house_type from house_type
                INNER JOIN house ON house.house_type = house_type.id WHERE house.id='$h_id'");
        $listofAvilHouse = mysqli_fetch_assoc($q1);
        $response['house'] = $listofAvilHouse['house_type'] . " - " . $listofAvilHouse['house_number'];

        $sql4 = "SELECT * FROM workman WHERE id='$a_to'";
        $result4 = mysqli_query($conn, $sql4);
        $row4 = mysqli_fetch_assoc($result4);
        $response['allocated_to'] = $row4['workman_name'];

        $sql7 = "SELECT * FROM jobs WHERE id='$t_job'";
        $result7 = mysqli_query($conn, $sql7);
        $row7 = mysqli_fetch_assoc($result7);
        $j_s_c = $row7['jobs_sub_category_id'];
        $j_c = $row7['jobs_category_id'];
        $response['job_name'] = $row7['jobs_name'];

        $sql8 = "SELECT job_sub_category FROM job_sub_category WHERE id='$j_s_c'";
        $result8 = mysqli_query($conn, $sql8);
        $row8 = mysqli_fetch_assoc($result8);
        $response['job_sub_category'] = $row8['job_sub_category'];

        $sql9 = "SELECT id,job_category FROM job_category WHERE id='$j_c'";
        $result9 = mysqli_query($conn, $sql9);
        $row9 = mysqli_fetch_assoc($result9);
        $response['job_category'] = $row9['job_category'];
        $job_cat_id = $row9['id'];


        $s1 = "SELECT * FROM workman_feedback WHERE complaint_id='$complaint_id'";
        $s11 = mysqli_query($conn, $s1);
        $li = 0;
        while ($s111 = mysqli_fetch_assoc($s11)) {
            $response['work_man_feedback'][$li]['lat_long'] = $s111['lat_long'];
            $response['work_man_feedback'][$li]['resolve'] = $s111['resolved'];
            $response['work_man_feedback'][$li]['remark'] = $s111['remarks'];
            $response['work_man_feedback'][$li]['workman_image'] = $s111['image'];
            $response['work_man_feedback'][$li]['complaint_datetime'] = $s111['complaint_datetime'];
            $response['work_man_feedback'][$li]['id'] = $s111['id'];
            // For feedback employee
            $response['work_man_feedback'][$li]['employee_feedback'] = $s111['employee_feedback'];
            $response['work_man_feedback'][$li]['employee_remarks'] = $s111['employee_remarks'];
            $li++;
        }

        //  // For Material Used 
        $materialquery = mysqli_query($conn, "SELECT txn_logs.quantity ,txn_logs.material_id,material.material_name ,txn_logs.workman_feedback_id
                    FROM txn_logs
                    LEFT JOIN material ON txn_logs.material_id = material.id
                    WHERE txn_logs.complaint_id='$id' GROUP BY txn_logs.id");
        $li1 = 0;
        while ($materiallist = mysqli_fetch_assoc($materialquery)) {
            $response['material'][$li1]['workman_feedback_id'] = $materiallist['workman_feedback_id'];
            $response['material'][$li1]['material_name'] = $materiallist['material_name'];
            $response['material'][$li1]['quantity'] = $materiallist['quantity'];
            $li1++;
        }
        // echo json_encode($a);
        echo json_encode($response);
    } elseif ($api == "close_from_workman") {
        header("Access-Control-Allow-Origin: *");
        $data = json_decode(file_get_contents('php://input'), true);
        $ok = 'N';
        $complaint_id =  $data["complaint_id"];
        $workman_id = $data['workman_id'];
        $lat_long = $data['lat_long'];
        $resolved = $data['resolved'];
        $image = $data['image'];
        $remarks = $data['remarks'];
        $complaint_datetime = $data['complaint_datetime'];
        $material_used = $data['material_used'];

        $complaintList = mysqli_fetch_assoc(mysqli_query($conn, "SELECT complaint.estimated_date_of_completion ,workman.workman_name,employee.name,employee.phone,complaint.complaint_number,complaint.complaint_login_datetime
        FROM complaint
        LEFT JOIN workman ON complaint.allocated_to=workman.id
        LEFT JOIN employee ON complaint.employee_id=employee.id
        WHERE complaint.id='$complaint_id'"));
        $phone = $complaintList['phone'];
        $workman_name = $complaintList['workman_name'];
        $name = $complaintList['name'];
        $complaint_number = $complaintList['complaint_number'];
        $complaint_login_datetime = $complaintList['complaint_login_datetime'];
        $complaint_number = 'C/' . date('m-Y', strtotime($complaint_login_datetime)) . '/' . $complaintList['complaint_number'];
        $Date = date('d-m-Y');
        $slg = $complaintList['estimated_date_of_completion'];

        $date = date('Y-m-d H:i:s');
        $EXE   = mysqli_query($conn, "INSERT INTO workman_feedback SET complaint_id = '$complaint_id', workman_id='$workman_id', lat_long='$lat_long',resolved='$resolved',
        image ='$image', remarks = '$remarks',complaint_datetime='$date',slg='$slg'");
        $id = mysqli_insert_id($conn);
        $execute = mysqli_query($conn, $EXE);
        $complaint_status = 'Pending_For_Closer';

        if ($EXE) {
            $ok = 'Y';
        }

        $EXE2 = mysqli_query($conn, "UPDATE complaint SET complaint_status='$complaint_status' WHERE id='$complaint_id'");
        if ($material_used == 'Y') {

            $dataMaterial   = $data["material"];
            foreach ($dataMaterial as $key => $value) {
                $material_id      = $value['material_id'];
                $quantity      = $value['quantity'];

                $EXE3 = mysqli_query($conn, "INSERT INTO txn_logs SET material_id='$material_id',workman_feedback_id='$id', quantity='$quantity' , type='OUT' ,out_type='Used_for_job',stock_userid	='$workman_id',entry_by='$workman_id',datetime='$date',complaint_id='$complaint_id' ");
                if (!$EXE3) {
                    $ok = 'N';
                }
            }
        }
        $response = array();
        if ($ok == 'Y') {
            $response = "success";

            // sms to employee
            $msg = "Dear Employee,";
            $msg .= "\nYour Complaint No $complaint_number has attended by $workman_name on $date. Request you to please provide your feedback on the App.";
            $msg .= "\nThanks, Tata Steel Long Products Limited";
            $msg = urlencode($msg);
            file_get_contents("http://gateway9.mbiz.co.in/httpapi/httpapi?token=ec5199c307c1e1f3e809efe526dd5fb0&sender=TSLPMS&number=$phone&route=2&type=1&sms=$msg&templateid=1607100000000135335");
        } else {
            $response = "error";
        }

        echo json_encode($response);
    } elseif ($api == "Add_complaint") {
        $date = date('Y-m-d H:i:s');
        $month = date('m', strtotime($date));
        $year  = date('Y', strtotime($date));
        $employee_id = $_REQUEST['employee_id'];
        $house_id       = $_REQUEST['house_id'];
        $myid = $employee_id; 
        $complaint_description   = $_REQUEST['complaint_description'];
        $complaint_status = 'Pending_For_Allocation';
        $complaint_photo =  $_REQUEST['photo'];
        $repeat_complaint_id =  $_REQUEST['repeat_complaint_id'];
        if($repeat_complaint_id){
            $repeat_type_of_job=mysqli_fetch_assoc(mysqli_query($conn,"SELECT type_of_job,estimated_date_of_completion FROM `complaint` WHERE id='$repeat_complaint_id'"));
            $a=",repeat_complaint_id='$repeat_complaint_id',repeat_complaint='on',type_of_job='".$repeat_type_of_job['type_of_job']."',estimated_date_of_completion='".$repeat_type_of_job['estimated_date_of_completion']."'";
        }
        $mobile = mysqli_fetch_assoc(mysqli_query($conn, "SELECT phone from employee WHERE id='$employee_id'"));

        $row2 = mysqli_fetch_assoc(mysqli_query($conn, "SELECT complaint_number AS slno from complaint WHERE  YEAR(complaint_login_datetime)='$year' AND MONTH(complaint_login_datetime)='$month' order by id DESC LIMIT 1"));
        if ($row2['slno']) {
            $c_no = $row2['slno'] + 1;
        } else {
            $c_no = 1;
        }

        $EXE   = mysqli_query($conn, "INSERT INTO complaint SET  employee_id='$employee_id'$a, house_id='$house_id',complaint_login_datetime='$date',complaint_logged_by_id='$myid',
            complaint_photo='$complaint_photo',complaint_description='$complaint_description',complaint_number='$c_no',complaint_status='$complaint_status' ");


        $response = array();
        $cno = 'C/' . date('m-Y', strtotime($date)) . '/' . $c_no;
        $response['complain_number'] = $cno;

        $msg = "Dear Employee,";
        $msg .= "\nYou have logged a complaint of $complaint_description and the Complaint No.$cno. Estimated Completion Date is N/A.";
        $msg .= "\nThanks, Tata Steel Long Products Limited";
        $msg = urlencode($msg);
        file_get_contents("http://gateway9.mbiz.co.in/httpapi/httpapi?token=ec5199c307c1e1f3e809efe526dd5fb0&sender=TSLPMS&number=$mobile&route=2&type=1&sms=$msg&templateid=1607100000000135330");
        echo json_encode($response);
    } elseif ($api == "job_category") {

        $sql1 = "SELECT id,job_category FROM job_category WHERE is_deleted='N'  ORDER BY id DESC";
        $data = array();
        $result1 = mysqli_query($conn, $sql1);
        while ($row1 = mysqli_fetch_assoc($result1)) {
            $data[] = $row1;
        }
        echo json_encode($data);
    } elseif ($api == "job_sub_category") {
        $job_category = $_REQUEST['job_category_id'];
        $sql1 = "SELECT id,job_sub_category FROM job_sub_category WHERE is_deleted='N' AND job_category='$job_category'  ORDER BY id DESC";
        $data = array();
        $result1 = mysqli_query($conn, $sql1);
        while ($row1 = mysqli_fetch_assoc($result1)) {
            $data[] = $row1;
        }
        echo json_encode($data);
    } elseif ($api == "job_name") {
        $jobs_category_id = $_REQUEST['job_category_id'];
        $jobs_sub_category_id = $_REQUEST['job_sub_category_id'];
        $sql1 = "SELECT id,jobs_name FROM jobs WHERE is_deleted='N' AND jobs_category_id='$jobs_category_id' AND jobs_sub_category_id = '$jobs_sub_category_id'   ORDER BY id DESC";
        $data = array();
        $result1 = mysqli_query($conn, $sql1);
        while ($row1 = mysqli_fetch_assoc($result1)) {
            $data[] = $row1;
        }
        echo json_encode($data);
    } elseif ($api == "view_employee") {
        $employee_id = $_REQUEST['employee_id'];
        $sql1 = "SELECT * From Employee  WHERE is_deleted='N' AND id='$employee_id' ORDER BY id DESC";
        $data = array();
        $result1 = mysqli_query($conn, $sql1);
        while ($row1 = mysqli_fetch_assoc($result1)) {
            $data[] = $row1;
        }
        echo json_encode($data);
    } elseif ($api == "All_complaint_employee") {
        $employee_id = $_REQUEST['employee_id'];
        $limit_from = $_REQUEST['start'];
        $limit_to = $_REQUEST['end'];
        $result1 = mysqli_query($conn, "SELECT complaint.id,complaint.complaint_number,jobs.jobs_name,complaint.complaint_login_datetime  ,complaint.complaint_status,complaint.estimated_date_of_completion,employee.phone,house.house_number,house_type.house_type
        FROM complaint 
        LEFT JOIN workman ON complaint.allocated_to = workman.id
        LEFT JOIN jobs ON complaint.type_of_job = jobs.id 
        LEFT JOIN employee ON complaint.employee_id = employee.id 
        LEFT JOIN house ON complaint.house_id = house.id 
        LEFT JOIN house_type ON house.house_type = house_type.id  
        WHERE complaint.employee_id ='$employee_id' ORDER BY complaint.id DESC LIMIT $limit_from,$limit_to");

        $data = array();
        while ($row1 = mysqli_fetch_assoc($result1)) {
            $row1['complaint_number'] = 'C/' . date('m-Y', strtotime($row1['complaint_login_datetime'])) . '/' . $row1['complaint_number'];
            $data[] = $row1;
        }

        echo json_encode($data);
    } elseif ($api == "Pending_complaints_employee") {
        $employee_id = $_REQUEST['employee_id'];
        $limit_from = $_REQUEST['start'];
        $limit_to = $_REQUEST['end'];
        $sql1 = "SELECT complaint.id,complaint.complaint_number,jobs.jobs_name,complaint.complaint_login_datetime  ,complaint.complaint_status,complaint.estimated_date_of_completion,employee.phone,house.house_number,house_type.house_type
        FROM complaint 
        LEFT JOIN workman ON complaint.allocated_to = workman.id
        LEFT JOIN jobs ON complaint.type_of_job = jobs.id 
        LEFT JOIN employee ON complaint.employee_id = employee.id 
        LEFT JOIN house ON complaint.house_id = house.id 
        LEFT JOIN house_type ON house.house_type = house_type.id 
        WHERE complaint.employee_id ='$employee_id' AND complaint.complaint_status !='Closer' ORDER BY complaint.id DESC LIMIT $limit_from,$limit_to";

        $data = array();
        $result1 = mysqli_query($conn, $sql1);
        while ($row1 = mysqli_fetch_assoc($result1)) {
            $row1['complaint_number'] = 'C/' . date('m-Y', strtotime($row1['complaint_login_datetime'])) . '/' . $row1['complaint_number'];
            $data[] = $row1;
        }
        echo json_encode($data);
    } elseif ($api == "Closed_complaints_employee") {
        $employee_id = $_REQUEST['employee_id'];
        $limit_from = $_REQUEST['start'];
        $limit_to = $_REQUEST['end'];

        $sql1 = "SELECT complaint.id,complaint.complaint_number,jobs.jobs_name,complaint.complaint_login_datetime  ,complaint.complaint_status,complaint.estimated_date_of_completion,employee.phone,house.house_number,house_type.house_type
        FROM complaint 
        LEFT JOIN workman ON complaint.allocated_to = workman.id
        LEFT JOIN jobs ON complaint.type_of_job = jobs.id 
        LEFT JOIN employee ON complaint.employee_id = employee.id 
        LEFT JOIN house ON complaint.house_id = house.id 
        LEFT JOIN house_type ON house.house_type = house_type.id 
        WHERE complaint.employee_id ='$employee_id' AND complaint.complaint_status ='Closer' ORDER BY complaint.id DESC LIMIT $limit_from,$limit_to";

        $data = array();
        $result1 = mysqli_query($conn, $sql1);
        while ($row1 = mysqli_fetch_assoc($result1)) {
            $row1['complaint_number'] = 'C/' . date('m-Y', strtotime($row1['complaint_login_datetime'])) . '/' . $row1['complaint_number'];
            $data[] = $row1;
        }
        echo json_encode($data);
    } elseif ($api == "recent_complaints_employee") {
        $employee_id = $_REQUEST['employee_id'];


        $sql1 = "SELECT complaint.id,complaint.complaint_number,jobs.jobs_name,complaint.complaint_login_datetime  ,complaint.complaint_status,complaint.estimated_date_of_completion,employee.phone,house.house_number,house_type.house_type
        FROM complaint 
        LEFT JOIN workman ON complaint.allocated_to = workman.id
        LEFT JOIN jobs ON complaint.type_of_job = jobs.id 
        LEFT JOIN employee ON complaint.employee_id = employee.id 
        LEFT JOIN house ON complaint.house_id = house.id 
        LEFT JOIN house_type ON house.house_type = house_type.id 
        WHERE complaint.employee_id ='$employee_id' ORDER BY complaint.id DESC";

        $data = array();
        $result1 = mysqli_query($conn, $sql1);
        while ($row1 = mysqli_fetch_assoc($result1)) {
            $row1['complaint_number'] = 'C/' . date('m-Y', strtotime($row1['complaint_login_datetime'])) . '/' . $row1['complaint_number'];
            $data[] = $row1;
        }
        echo json_encode($data);
    } elseif ($api == "total_complain_employee") {
        $employee_id = $_REQUEST['employee_id'];
        $sql1 = "SELECT * From complaint  WHERE employee_id='$employee_id' ORDER BY id DESC";
        $data = array();
        $count = 0;
        $result1 = mysqli_query($conn, $sql1);
        while ($row1 = mysqli_fetch_assoc($result1)) {
            $count++;
        }
        $data[] = $count;
        echo json_encode($data);
    } elseif ($api == "total_Pending_complain_employee") {
        $employee_id = $_REQUEST['employee_id'];
        $sql1 = "SELECT * From complaint  WHERE complaint_status !='Closer' AND employee_id='$employee_id' ORDER BY id DESC";
        $data = array();
        $count = 0;
        $result1 = mysqli_query($conn, $sql1);
        while ($row1 = mysqli_fetch_assoc($result1)) {
            $count++;
        }
        $data[] = $count;
        echo json_encode($data);
    } elseif ($api == "total_Closed_complain_employee") {
        $employee_id = $_REQUEST['employee_id'];
        $sql1 = "SELECT * From complaint  WHERE complaint_status ='Closer' AND employee_id='$employee_id' ORDER BY id DESC";
        $data = array();
        $count = 0;
        $result1 = mysqli_query($conn, $sql1);
        while ($row1 = mysqli_fetch_assoc($result1)) {
            $count++;
        }
        $data[] = $count;
        echo json_encode($data);
    } elseif ($api == "material_stock") {
        $stock_userid = $_REQUEST['workman_id'];
        $result1 = mysqli_query($conn, "SELECT material.material_name,material.id  From txn_logs 
        INNER JOIN material ON txn_logs.material_id= material.id
        WHERE txn_logs.stock_userid ='$stock_userid' AND material.is_deleted='N' GROUP BY material.id DESC");
        $data = array();
        $a = array();
        while ($row1 = mysqli_fetch_assoc($result1)) {
            $mid = $row1['id'];
            $result12 = mysqli_query($conn, "SELECT SUM(txn_logs.quantity) AS q_in 
                From txn_logs WHERE stock_userid ='$stock_userid' AND material_id ='$mid' AND type='IN'");
            $row12 = mysqli_fetch_assoc($result12);

            $result22 = mysqli_query($conn, "SELECT SUM(txn_logs.quantity) AS q_out 
                From txn_logs WHERE stock_userid ='$stock_userid' AND material_id ='$mid' AND type='OUT'");
            $row22 = mysqli_fetch_assoc($result22);

            $data['material_id']  = $row1['id'];
            $data['material_name']  = $row1['material_name'];
            $data['material_stock'] = $row12['q_in'] - $row22['q_out'];
            $a[] = $data;
        }
        echo json_encode($a);
    } elseif ($api == "criteria_type") {
        $criteria_type = $_REQUEST['criteria_type'];
        $result1 = mysqli_query($conn, "SELECT * From criteria  WHERE criteria_type ='$criteria_type' AND is_deleted='N' ORDER BY id DESC");
        $data = array();

        while ($row1 = mysqli_fetch_assoc($result1)) {
            $data[] = $row1['id'];
            $data[] = $row1['criteria_name'];
        }

        echo json_encode($data);
    } elseif ($api == "feedback") {
        $data = array();
        $date = date('Y-m-d H:i:s');


        $employee_id = $_REQUEST['employee_id'];
        $rating = $_REQUEST['rating'];
        $complaint_id = $_REQUEST['complaint_id'];
        $employee_remarks=$_REQUEST['employee_remarks'];
        $result1 = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id From workman_feedback WHERE complaint_id='$complaint_id' ORDER BY id DESC"));
        $WMID = $result1['id'];
        $EXE2 = mysqli_query($conn, "UPDATE workman_feedback SET employee_feedback='$rating',employee_remarks=' $employee_remarks',feedback_datetime=' $date' WHERE id='$WMID'");
        if ($rating == "1") {
            $status = "Pending_For_Workman";
            $slg_complaint = mysqli_fetch_assoc(mysqli_query($conn, "SELECT jobs.slg 
            FROM complaint 
            LEFT JOIN jobs ON complaint.type_of_job=jobs.id
            WHERE complaint.id='$complaint_id'"));
            $Date = date('d-m-Y');
            $slg = date('Y-m-d', strtotime($Date . ' + ' . $slg_complaint['slg'] . ' days'));
            $a = ",estimated_date_of_completion='$slg'";
        } else {
            $status = "Closer";
            $a = ",complaint_closed_by='$employee_id',complaint_closed_datetime='$date'";
            $complaintList = mysqli_fetch_assoc(mysqli_query($conn, "SELECT complaint.complaint_login_datetime,complaint.complaint_number,employee.phone 
            FROM complaint 
            LEFT JOIN employee ON complaint.employee_id = employee.id
            WHERE complaint.id='$complaint_id'"));
            $cno = 'C/' . date('m-Y', strtotime($complaintList['complaint_login_datetime'])) . '/' . $complaintList['complaint_number'];
            $phone = $complaintList['phone'];
            //sms EMPLOYEE
            $msg = "Dear Employee,";
            $msg .= "\nYour Complaint No $cno has marked Closed.";
            $msg .= "\nThanks, Tata Steel Long Products Limited";
            $msg = urlencode($msg);
            file_get_contents("http://gateway9.mbiz.co.in/httpapi/httpapi?token=ec5199c307c1e1f3e809efe526dd5fb0&sender=TSLPMS&number=$phone&route=2&type=1&sms=$msg&templateid=1607100000000135336");
            
        }
        $EXE3 = mysqli_query($conn, "UPDATE complaint SET complaint_status='$status'$a WHERE id='$complaint_id'");
        if($EXE2 && $EXE3){
        echo 'Success';
        }else{
            echo "Error";
        }
    } elseif ($api == "update") {
        $arr = array();
        $arr["link"] = 'https://play.google.com/store/apps/details?id=com.anmoul.tslptownshipapp';
        $arr["version_code"] = "3";
        echo json_encode($arr);
    } elseif ($api == "check_password") {
        $old_password = $_REQUEST['old_password'];
        $new_password = $_REQUEST['new_password'];
        $confirm_new_password = $_REQUEST['confirm_new_password'];
        $type = $_REQUEST['type'];
        $user = $_REQUEST['username'];
        if ($new_password == $confirm_new_password) {
            if ($type == 'Workman') {
                $qw   = mysqli_query($conn, "SELECT * from workman where id='$user' and workman_password = '$old_password'");
                if (mysqli_num_rows($qw) > 0) {
                    $workmanList = mysqli_fetch_assoc($qw);
                    $id = $workmanList['id'];
                    $exe = mysqli_query($conn, "UPDATE `workman` SET `workman_password`='$new_password',`force_pwd`='N' WHERE id='$id'");
                } else {
                    echo "Check Your Username And Password";
                }
            } elseif ($type == "Employee") {
                $qw   = mysqli_query($conn, "SELECT * from employee where id='$user' and password = '$old_password'");
                if (mysqli_num_rows($qw) > 0) {
                    $employeeList = mysqli_fetch_assoc($qw);
                    $id = $employeeList['id'];
                    $exe1 = mysqli_query($conn, "UPDATE `employee` SET `password`='$new_password',`force_pwd`='N' WHERE id='$id'");
                } else {
                    echo "Check Your Personal Number And Password";
                }
            }
            if ($exe || $exe1) {
                echo "Success";
            }
        } else {
            echo "Passwords do not match!";
        }
    } elseif ($api == "forgot_password") {
        $user = $_REQUEST['user_id'];
        $pwd = rand(0000, 9999);
        $qw   = mysqli_query($conn, "SELECT * from workman where workman_username='$user'");
        if (mysqli_num_rows($qw) > 0) {
            $data = mysqli_fetch_assoc($qw);
            $id = $data['id'];
            $mobile = $data['workman_mobile'];
            $email = $data['workman_email'];
            $name = $data['workman_name'];

            $exe = mysqli_query($conn, "UPDATE  `workman` SET `force_pwd`='Y',workman_password='$pwd' WHERE id='$id'");
        } else {
            $qw   = mysqli_query($conn, "SELECT * from employee where p_number='$user'");
            if (mysqli_num_rows($qw) > 0) {
                $data = mysqli_fetch_assoc($qw);
                $id = $data['id'];
                $mobile = $data['phone'];
                $email = $data['email'];
                $name = $data['name'];

                $exe1 = mysqli_query($conn, "UPDATE  `employee` SET `force_pwd`='Y', password='$pwd' WHERE id='$id'");
            } else {
                echo "Check Your Username";
            }
        }

        if ($exe || $exe1) {
            //send Mail SMS
            include "email_message_send.php";
            email_sms($email, $mobile, $name, $pwd);
            echo "Success";
        }
    } elseif ($api == "job_return") {
        $complaint_id = $_REQUEST['complaint_id'];
        $complaint_status = 'Pending_For_Allocation';
        $type_of_job='';
        $exe=mysqli_query($conn, "UPDATE `complaint` SET `complaint_status`='$complaint_status',type_of_job='$type_of_job' WHERE id='$complaint_id'");
        if($exe){
            echo "yes";
        }else{
            echo "no";
        }
    } else {
        echo "Invalid Api";
    }
} else {
    echo "Invalid Token";
}


// 'Pending_Job_Card','Pending_For_Allocation','Pending_For_Workman','Pending_For_Closer','Closer'