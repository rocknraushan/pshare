<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$count = 1;
$sql = "SELECT txn_logs.*,material.material_name ,user.user_name,workman.workman_name,complaint.complaint_number,complaint.complaint_login_datetime,complaint.id AS com_id
    FROM txn_logs 
     LEFT JOIN material ON txn_logs.material_id =  material.id
     LEFT JOIN user ON txn_logs.entry_by =  user.id
     LEFT JOIN workman ON txn_logs.stock_userid = workman.id
     LEFT JOIN complaint ON txn_logs.complaint_id = complaint.id
    ORDER BY id DESC";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
	while ($row = $result->fetch_assoc()) {
		$id = $row['id'];
?>
		<tr>
			<td><?= $count++; ?></td>
			<td><?= date('d-m-Y h:i A', strtotime($row['datetime'])) ?></td>
			<td><?= $row['material_name']; ?></td>
			<td><?= $row['type']; ?></td>
			<?php if ($row['type'] == 'IN') {
				if ($row['workman_name']) { ?>
					<td><?php echo $row['in_type']; ?></td>
					<td><?= $row['workman_name'] ?></td>
				<?php } else { ?>
					<?php if($row['in_type']=='Supplier-SRC'){ ?>
						<td><?php echo "Receipt from Supplier Against ".$row['remarks']; ?></td>
				<?php } else{ ?>
					<td><?php echo $row['in_type']; ?></td>
					<?php } ?>
					<td>Head office</td>
				<?php } ?>
				<?php
			} elseif ($row['type'] == 'OUT') {
				if ($row['workman_name']) { ?>
					<td><?php if($row['out_type']=='Used_for_job'){
						echo "Used in Complaint ";
					}else{
					echo $row['out_type'];
					}
						if ($row['complaint_number']) {
							$complaint_id = md5($row['com_id']);
							echo '<a href="complaint_edit.php?id=' . $complaint_id . '" target="_blank"> (C/' . date('m', strtotime($row['complaint_login_datetime'])) . '-' . date('Y', strtotime($row['complaint_login_datetime'])) . '/' . $row['complaint_number'] . ')</a>';
						}
						?> </td>
					<td><?= $row['workman_name']; ?></td>
				<?php } else { ?>
					<td><?php echo $row['out_type']; ?></td>
					<td>Head office</td>
				<?php } ?>
			<?php }
			?>
			<td><?= $row['quantity']; ?></td>
			<?php if($row['out_type']=='Used_for_job'){ ?>
				<td><?= $row['workman_name']; ?></td>
			<?php }else{ ?>
			<td><?= $row['user_name']; ?></td>
			<?php } ?>
		</tr>
<?php
	}
} else {
	echo "<tr >
		<td colspan='5'>No Result found !</td>
		</tr>";
}
mysqli_close($conn);
?>