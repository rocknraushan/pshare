<?php
session_start();
include("../inc/db_conn.php");
$myid=$_SESSION['userid'];
$id=$_POST['id'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');
$complaint_status='Closer';

    $sql = "UPDATE  `complaint` SET complaint_status='$complaint_status',complaint_closed_datetime='$date',complaint_closed_by='$myid'  WHERE `id`='$id'";
    mysqli_query($conn, $sql);
?>