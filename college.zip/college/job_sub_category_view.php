<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$count = 1;
$sql="SELECT job_sub_category.id,job_sub_category.job_sub_category,job_category.job_category AS type_job,
			job_sub_category.job_category AS job_category_id 
	FROM job_sub_category 
	INNER JOIN job_category ON job_sub_category.job_category=job_category.id WHERE job_sub_category.is_deleted='N' ORDER BY 
			job_sub_category.id DESC";
// echo $sql;
// exit;


$result = mysqli_query($conn,$sql);
if ($result) {
	while ($row = mysqli_fetch_array($result)) {	
?>
<tr>
<td><?= $count++; ?>
<td><?= $row['type_job']; ?></td>			
<td><?= $row['job_sub_category']; ?></td>
<td><button type="button" class="btn btn-success btn-sm update" data-toggle="modal" data-keyboard="false" data-backdrop="static" data-target="#modal-update" 
    data-id="<?= $row['id'];?>" 
    data-job_category="<?= $row['job_category_id']; ?>" 
    data-job_sub_category="<?= $row['job_sub_category']; ?>">Edit</button>
</td>
<td><button type="button" class="btn btn-danger btn-sm update" id="delete" data-id="<?= $row['id']; ?>">Delete</button></td>
</tr>
<?php
	} 
} else {
	echo "<tr >
		<td colspan='5'>No Result found !</td>
		</tr>";
}
mysqli_close($conn);
?>

