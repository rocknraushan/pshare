<?php
session_start();

include("../inc/db_conn.php"); 
$myid = $_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');

foreach ($_POST['material_id'] as $key => $value) {
    $material_id =  $_POST['material_id'][$key];
    $quantity  = $_POST['quantity'][$key];
      $remarks  = $_POST['remarks'][$key];
   
    $EXE   = mysqli_query($conn, "INSERT INTO txn_logs SET  material_id='$material_id',  quantity='$quantity',remarks='$remarks',type='IN',in_type='Supplier-SRC',entry_by='$myid',datetime='$date'");
}
if($EXE){
    echo "yes";
}
?>