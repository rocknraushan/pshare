<?php
session_start();
include("../inc/db_conn.php");
$myid=$_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$id=@$_POST['id'];
$allocated_to=@$_POST['allocated_to1'];
$type_of_job1=@$_POST['type_of_job1'];
$find_slg=@$_POST['find_slg'];
$estimated_date_of_completion  = date('Y-m-d', strtotime( $find_slg)); 
$repeat_complaint=@$_POST['repeat_complaint1'];
$date = date('Y-m-d H:i:s'); 
$complaint_status='Pending_For_Workman';
$job_category_check=@$_POST['job_category_check'];
$repeat_complaint_id_check=@$_POST['repeat_complaint_id_check'];

if($job_category_check ||$repeat_complaint_id_check ){
  mysqli_query($conn,"UPDATE  `complaint` SET allocated_to='$allocated_to', allocated_datetime='$date',   
    complaint_status='$complaint_status',allocated_by='$myid'  WHERE `id`='$id'");
}else{
mysqli_query($conn,"UPDATE  `complaint` SET allocated_to='$allocated_to', allocated_datetime='$date', repeat_complaint='$repeat_complaint',
    type_of_job='$type_of_job1',estimated_date_of_completion='$estimated_date_of_completion',
    complaint_status='$complaint_status',allocated_by='$myid'  WHERE `id`='$id'");
}    
      $complaintList= mysqli_fetch_assoc(mysqli_query($conn,"SELECT complaint.complaint_number,complaint.complaint_login_datetime,workman.workman_name,workman.workman_mobile,workman.vender_mobile,employee.phone
       FROM complaint 
       LEFT JOIN workman ON complaint.allocated_to=workman.id
       LEFT JOIN employee ON complaint.employee_id=employee.id
       WHERE complaint.id='$id'"));
        $complaint_number='C/'. date('m-Y', strtotime($complaintList['complaint_login_datetime'])) . '/' . $complaintList['complaint_number'];
        $workman_name=$complaintList['workman_name'];
        $workman_mobile=$complaintList['workman_mobile'];
        $phone=$complaintList['phone'];
        $workman_vendor_mobile=$complaintList['vender_mobile']; 
       $jobList=mysqli_fetch_assoc(mysqli_query($conn,"SELECT `jobs_name` FROM `jobs` WHERE id='$type_of_job1'"));
        $type_of_job11=$jobList['jobs_name'];
        if (strlen($type_of_job11) > 18){
          $type_of_job11 = substr($type_of_job11, 0, 16).'...';
        }
// to employee
$msg="Dear Employee,";
$msg.="\nYour Complaint No $complaint_number has been assigned to $workman_name / Mobile No - $workman_mobile. Estimated Completion Date is $estimated_date_of_completion.";
$msg.="\nThanks, Tata Steel Long Products Limited";
$msg=urlencode($msg);
file_get_contents("http://gateway9.mbiz.co.in/httpapi/httpapi?token=ec5199c307c1e1f3e809efe526dd5fb0&sender=TSLPMS&number=$phone&route=2&type=1&sms=$msg&templateid=1607100000000135333");

//to workman
$msg2="Dear Vendor,";
$msg2.="\nYou have been assigned a Job -$type_of_job11 with Complaint No.$complaint_number. Estimated Completion Date is $estimated_date_of_completion.";
$msg2.="\nThanks, Tata Steel Long Products Limited";
$msg2=urlencode($msg2);
file_get_contents("http://gateway9.mbiz.co.in/httpapi/httpapi?token=ec5199c307c1e1f3e809efe526dd5fb0&sender=TSLPMS&number=$workman_mobile&route=2&type=1&sms=$msg2&templateid=1607100000000135331");

//to workman vendor
$msg2="Dear Vendor,";
$msg2.="\nYou have been assigned a Job - $type_of_job11 with Complaint No.$complaint_number. Estimated Completion Date is $estimated_date_of_completion.";
$msg2.="\nThanks, Tata Steel Long Products Limited";
$msg2=urlencode($msg2);
file_get_contents("http://gateway9.mbiz.co.in/httpapi/httpapi?token=ec5199c307c1e1f3e809efe526dd5fb0&sender=TSLPMS&number=$workman_vendor_mobile&route=2&type=1&sms=$msg2&templateid=1607100000000135331");


