<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$count++;
$role = array();
$roleQuery = mysqli_query($conn,"SELECT id,rolename,created_date_time  FROM role_master WHERE is_deleted='N' ORDER BY id DESC");
	while ($roleList = mysqli_fetch_assoc($roleQuery)) {
		$id = $roleList['id'];
?> 
		<tr>
			<td><?= $count++; ?></td>
			<td><?= $roleList['rolename']; ?></td>				
			<td><?= date('d-m-Y h:i A',strtotime($roleList['created_date_time'])); ?></td>		
			<td><button type="button" class="btn btn-success btn-sm update" 
					data-toggle="modal" data-keyboard="false" 
					data-backdrop="static" data-target="#modal-update" 
					data-id="<?= $roleList['id']; ?>" data-role="<?= $roleList['rolename']; ?>" >Edit</button></td>
			<td><button type="button" class="btn btn-danger btn-sm update" id="delete" data-id="<?= $roleList['id']; ?>">Delete</button></td>
		</tr>
<?php
	}
// } else {
// 	echo "<tr >
// 		<td colspan='5'>No Result found !</td>
// 		</tr>";
// }
mysqli_close($conn);
?>