<?php
session_start();

include("../inc/db_conn.php");
$myid = $_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');
$user_name   = $_POST['user_name'];
$email       = $_POST['email'];
$phone      = $_POST['phone'];
$role      = $_POST['role'];
$pwd=rand(0000,9999);

$EXE   = mysqli_query($conn, "INSERT INTO user SET user_name = '$user_name', email='$email',password='$pwd',role='$role',
          phone = '$phone', created_by='$myid',created_date_time='$date'");
if($EXE){
    
//send email sms
include "email_message_send.php"; 
email_sms($email,$phone,$user_name,$pwd);
}
