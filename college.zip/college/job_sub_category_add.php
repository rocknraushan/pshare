<?php
session_start();
include("../inc/db_conn.php");
//$db=$conn;// database connection  
$myid=$_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');
$job_category   = $_POST['job_category'];
$job_sub_category   = $_POST['job_sub_category'];


$EXE   = mysqli_query($conn, "INSERT INTO job_sub_category SET job_category = '$job_category', job_sub_category='$job_sub_category', created_by='$myid',created_date_time='$date'");