<?php
session_start();
include("../inc/db_conn.php");
//$db=$conn;// database connection  
$myid=$_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');
$house_type   = $_POST['house_type'];
$house_number   = $_POST['house_number'];


$EXE   = mysqli_query($conn, "INSERT INTO house SET house_type = '$house_type', house_number='$house_number', created_by='$myid',created_date_time='$date'");