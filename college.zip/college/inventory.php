<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$head="inventory";
$page="inventory";
include("layouts/header.php");

?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h3 class="m-0">Inventory</h3>
                </div>
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div><!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header border-0">
                            <div class="d-flex justify-content-between">
                                Inventory
                                <div style="float:right">
                                    <a href="allot.php" class="btn btn-success btn-sm" >Allot</a>
                                    <a href="receipt.php" class="btn btn-success btn-sm" >Receipt</a>
                                </div>
                            </div>
                        </div>

                        <div class="card-body">
                            <div class="alert alert-success alert-dismissible" id="success" style="display:none;">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                            </div>
                            <table id="example1" class="table table-bordered table-sm">
                                <thead>
                                    <tr>
                                        <th>Sl No.</th>
                                        <th>DateTime</th>
                                        <th>Material Name</th>
                                        <th>Type</th>
                                        <th>Description</th>
                                        <th>Stock Point</th>
                                        <th>Quantity</th>
                                        <th>Entry By </th>
                                    </tr>
                                </thead>
                                <tbody id="table">

                                </tbody>
                            </table>

                            <script type="text/javascript">
                                $(document).ready(function() {
                                    loaddata();
                                });

                                function loaddata() {
                                    $('#modal-loader').modal('show');
                                    $.ajax({
                                        url: 'inventory_view.php',
                                        type: 'POST',
                                        dataType: 'html',
                                        success: function(newContent) {
                                            $('#table').html('');
                                            $('#table').append(newContent);
                                            $('#modal-loader').modal('hide');
                                            $('#example1').DataTable();

                                        }
                                    });
                                }
                            </script>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- /.content -->
    <!-- /.content-wrapper -->
</div>
<div class="modal" id="modal-loader" style="z-index:1000000000">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body" style="z-index:1000000000">
                <img class="mx-auto d-block" src="dist/img/loader.gif" />
                <p class="text-center">Please Wait</p>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

<?php
include("layouts/footer.php");
?>