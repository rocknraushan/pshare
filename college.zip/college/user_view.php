<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$count++;
$sql = "SELECT user.id,user.user_name,user.phone,user.email,role,role_master.rolename ,role_master.id AS role_id
FROM user 
LEFT JOIN role_master ON user.role = role_master.id
WHERE user.is_deleted='N'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
	while ($row = $result->fetch_assoc()) {
		$id = $row['id'];
?> 
		<tr>
			<td><?= $count++; ?></td> 
			<td><?= $row['user_name']; ?></td>			
			<td><?= $row['email']; ?></td>
			<td><?= $row['phone']; ?></td>
			<?php if($row['rolename'] !=''){  ?>
				<td><div data-toggle="modal" data-target="#myModal" data-id="<?=  $row['role_id']; ?>" ><?php echo @$row['rolename']; ?></div></td>
			<?php }else{ ?> 				
				<td><div data-toggle="modal" data-target="#myModal" data-id="0" >Super Admin</div></td>
			<?php } ?>
			<td><button type="button" class="btn btn-info btn-sm update" id="reset_password" data-id="<?= $row['id']; ?>"			
			>Reset Password</button></td>
			<td><button type="button" class="btn btn-success btn-sm update" data-toggle="modal" data-keyboard="false" data-backdrop="static" data-target="#modal-update" 
			data-id="<?= $row['id']; ?>" 
			data-name="<?= $row['user_name']; ?>" 
			data-email="<?= $row['email']; ?>" 
			data-phone="<?= $row['phone']; ?>" 
			data-role="<?= $row['role']; ?>" 
			>Edit</button></td>
			<td><button type="button" class="btn btn-danger btn-sm update" id="delete" data-id="<?= $row['id']; ?>"			
			>Delete</button></td>
		</tr>
<?php
	}
} else {
	echo "<tr >
		<td colspan='5'>No Result found !</td>
		</tr>";
}
mysqli_close($conn);
?>