<?php
session_start();

include("../inc/db_conn.php");
$myid = $_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');
$role   = $_POST['role']; 

$EXE   = mysqli_query($conn, "INSERT INTO role_master SET rolename = '$role',
          created_by='$myid',created_date_time='$date'");
$roleidgenerate   = mysqli_insert_id($conn);
foreach ($_POST['permission_master_id'] as $key => $value) {
        $permission_master_id   = $_POST['permission_master_id'][$key];
    $query ="INSERT INTO role_permission (role_master_id,permission_master_id)  VALUES ('$roleidgenerate','$permission_master_id')"; 
    $RolePermission = mysqli_query($conn,$query);
}
if($EXE){
        echo "yes";
}
?>