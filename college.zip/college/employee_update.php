<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$myid=$_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');	
	$id=$_POST['id'];
	$name=$_POST['name'];
	$email=$_POST['email'];
	$alternative_email=$_POST['alternative_email'];
	$phone=$_POST['phone'];
	$alternative_phone=$_POST['alternative_phone'];
	$inter_com_nunber=$_POST['inter_com_nunber'];
	$per=$_POST['p_number'];   
	$house_id=$_POST['house_id_edit'];
	$old_house_id=$_POST['old_house_id'];
	$sql = "UPDATE `employee` SET `name`='$name',`email`='$email',`alternative_email`='$alternative_email',`phone`='$phone',`house_id`='$house_id',
	`alternative_phone`='$alternative_phone',`intercom_nunber`='$inter_com_nunber',`p_number`='$per', updated_by='$myid',updated_date_time='$date' WHERE `id`='$id'";
// mysqli_query($conn, $sql);
if ($house_id != $old_house_id )
{
	$sql6="UPDATE house SET house_status='Non-Active' WHERE id='$old_house_id'";
	mysqli_query($conn,$sql6);
	$sql2 = "UPDATE employee_house SET status='Non-Active' WHERE employee_id='$id' ";
	$sql1  =  "INSERT INTO employee_house SET employee_id='$id',house_id='$house_id',status='Active', created_by='$myid',created_date_time='$date'";
	mysqli_query($conn, $sql2);
	mysqli_query($conn, $sql1);
	$sql5="UPDATE house SET house_status='Active' WHERE id='$house_id'";
	mysqli_query($conn,$sql5);
}



	if (mysqli_query($conn, $sql)) {
		echo json_encode(array("statusCode"=>200));
	} 
	else {
		echo json_encode(array("statusCode"=>201));
	}
	mysqli_close($conn);
?>