<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$head="masters";
$head1="employee";
$page="workman";
include("layouts/header.php");


?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h3 class="m-0">Masters/Workman</h3>
                </div>
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div><!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header border-0">
                            <div class="d-flex justify-content-between">
                                Workman
                                <div style="float:right">
                                    <a href="#" class="btn btn-success btn-sm" data-toggle="modal" data-target="#exampleModal">Add New</a>
                                </div>
                            </div>
                        </div>

                        <div class="card-body">
                            <div class="alert alert-success alert-dismissible" id="success" style="display:none;">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                            </div>
                            <table id="example1" class="table table-bordered table-sm">
                                <thead>
                                    <tr>
                                        <th>Sl No.</th>
                                        <th> Name</th>
                                        <th>Email</th>
                                        <th>User Name</th>
                                        <th>Mobile</th>
                                        <th>Type</th>
                                        <th>Reset Password</th> 
                                        <th>Edit </th>
                                        <th>Delete</th>
                                    </tr>
                                </thead>
                                <tbody id="table">

                                </tbody>
                            </table>

                            <script type="text/javascript">
                                $(document).ready(function() {
                                    $(".ven").css("display", "none"); //for use in  add data
                                    loaddata();
                                });

                                function loaddata() {
                                    $('#modal-loader').modal('show');
                                    $(".ven").css("display", "none"); //for use in  add data
                                    $.ajax({
                                        url: 'work_man_view.php',
                                        type: 'POST',
                                        dataType: 'html',
                                        success: function(newContent) {
                                            $('#modal-loader').modal('hide');
                                            $('#table').html('');
                                            $('#table').append(newContent);
                                            $('#example1').DataTable();
                                            

                                        }
                                    });
                                }
                            </script>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- /.content -->
    <!-- /.content-wrapper -->
</div>
</div>

</body>


<div class="modal" id="modal-loader" style="z-index:1000000000">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body" style="z-index:1000000000">
                <img class="mx-auto d-block" src="dist/img/loader.gif" />
                <p class="text-center">Please Wait</p>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

<div class="modal" id="exampleModal">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Workman</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form class="form-horizontal" role="form" method="post" autocomplete="off" id="userForm" action="">
                <div class="modal-body">
                    <input type="hidden" value="<?= @$data['id'] ?>" name="token">

                    <div class="form-group">
                        <label for="exampleInputEmail1">Name</label>
                        <input type="text" name="workman_name" class="form-control rec" id=" " placeholder="Name" required>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Email</label>
                        <input type="email" name="workman_email" class="form-control rec" id=" " placeholder="Email" required>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">User Name</label>
                        <input type="text" name="workman_username" class="form-control rec" id=" " placeholder=" User Name" required>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Mobile</label>
                        <input type="number" name="workman_mobile" class="form-control rec" id=" " placeholder=" Mobile" min="1000000000" required >
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Workman Type </label>
                        <select name="workman_type" id="workman_type" class="form-control rec" required>
                            <option value="">Select Workman Type</option>
                            <option value="V">Vender Employee</option>
                            <option value="O">Own Employee</option>
                        </select>
                    </div>
                    <!--===== hide part ====== -->

                    <div class="form-group ven">
                        <label for="exampleInputEmail1">Vendor Name</label>
                        <input type="text" name="vender_name" class="form-control rec" id=" " placeholder="Name">
                    </div>
                    <div class="form-group ven">
                        <label for="exampleInputEma''il1">Vendor Email</label>
                        <input type="email" name="vender_email" class="form-control rec" id=" " placeholder="Email Id">
                    </div>
                    <div class="form-group ven">
                        <label for="exampleInputEmail1">Vendor Code</label>
                        <input type="text" name="vender_code" class="form-control rec" id=" " placeholder="Code">
                    </div>
                    <div class="form-group ven">
                        <label for="exampleInputEmail1">Vendor Mobile</label>
                        <input type="number" name="vender_mobile" class="form-control rec" id=" " placeholder=" Mobile Number" min="1000000000">
                    </div>

                    <div class="form-group">
                        <?php if ($edit) { ?>
                            <input type="submit" name="update" onclick="return form_validate()" value="Update" class="btn btn-primary btn-sm" />&nbsp;&nbsp;
                        <?php } else { ?>
                        <?php } ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" id="cancelbtn" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" id="submit_request" onSubmit="add(event)">Submit</button>
                </div>
        </div>
        </form>
    </div>
</div>
</div>
<script>
     $('#cancelbtn').on('click', function() {
        $(".ven").css("display", "none");
     });
</script>
<script>
    $('#workman_type').on('change', function() {
        var workman_type_change = $(this).val();


        if (workman_type_change == 'V') {
            $(".ven").css("display", "block");

        } else {

            $(".ven").css("display", "none");

        }
    });
</script>
<script>
    $(document).on('submit', '#userForm', function(e) {
        $('#modal-loader').modal('show');
        $('#submit_request').prop('disabled', true);
        e.preventDefault();
        $.ajax({
            method: "POST",
            url: "work_man_add.php",
            data: $(this).serialize(),
            success: function(data) {
                $('#modal-loader').modal('hide');
                if(data=='yes'){
                $('#userForm').find('input').val('');
                $('#submit_request').prop('disabled', false);
                $('#exampleModal').modal('hide');
                swal("Workman Saved!", "", "success");
                loaddata();
                }else{
                    $('#userForm').find('input').val('');
                $('#submit_request').prop('disabled', false);
                $('#exampleModal').modal('hide');
                swal("Duplicate Entry!", "", "warning");
                loaddata();
                }
            }
        });
    });
</script>


<!-- UPATE  DATA -->
<!-- Modal Update-->
<div class="modal fade" id="modal-update">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Workman </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <!--1-->
                <div class="form-group ">
                    <label for="exampleInputEmail1">Name</label>
                    <input type="text" name="workman_name" class="form-control rec" id="workman_name_edit" placeholder="Name" required>
                </div>
                <!-- 2  -->
                <div class="form-group">
                    <label for="exampleInputEmail1">Email</label>
                    <input type="email" name="workman_email" class="form-control rec" id="workman_email_edit" placeholder="Email" required>
                </div>
                <!-- 3  -->
                <div class="form-group">
                    <label for="exampleInputEmail1">User Name</label>
                    <input type="text" name="workman_username" class="form-control rec" id="workman_username_edit" placeholder=" User Name" required>
                </div>
                <!-- 4  -->
                <div class="form-group">
                    <label for="exampleInputEmail1">Mobile</label>
                    <input type="number" name="workman_mobile" class="form-control rec" id="workman_mobile_edit" placeholder=" Mobile" min="1"  required>
                </div>
                <!-- 5  -->
                <div class="form-group">
                    <label for="exampleInputPassword1">Workman Type </label>
                    <select name="workman_type" id="workman_type_edit" class="form-control rec" required>
                        <option value="">Select Workman Type</option>
                        <option value="V">Vendor Employee</option>
                        <option value="O">Own Employee</option>
                    </select>
                </div>
                <!--===== hide part ====== -->
                <!-- 5 -->
                <div class="form-group ven">
                    <label for="exampleInputEmail1">Vendor Name</label>
                    <input type="text" name="vender_name" class="form-control rec" id="vender_name_edit" placeholder="Name">
                </div>
                <!-- 6  -->
                <div class="form-group ven">
                    <label for="exampleInputEma''il1">Vendor Email</label>
                    <input type="email" name="vnder_email" class="form-control rec" id="vender_email_edit" placeholder="Email Id">
                </div>
                <!-- 7  -->
                <div class="form-group ven">
                    <label for="exampleInputEmail1">Vendor Code</label>
                    <input type="text" name="vender_code" class="form-control rec" id="vender_code_edit" placeholder="Code">
                </div>
                <!-- 8  -->
                <div class="form-group ven">
                    <label for="exampleInputEmail1">Vendor Mobile</label>
                    <input type="number" name="vender_mobile" class="form-control rec" id="vender_mobile_edit" placeholder=" Mobile Number" min="1000000000" maxlength = "10">
                </div>
                <input type="hidden" name=" " id="id_modal" class="form-control">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary" id="update_data">Update</button>
            </div>
        </div>
    </div>
</div>
</div>
<!-- Modal End-->
<script>
    $('#workman_type_edit').on('change', function() {
        var workman_type_change = $(this).val();


        if (workman_type_change == 'V') {
            $(".ven").css("display", "block");

        } else {

            $(".ven").css("display", "none");

        }
    });
</script>
<script>
    $(function() {
        $('#modal-update').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget); /*Button that triggered the modal*/
            var id = button.data('id');
            var workman_name = button.data('workman_name');
            var workman_email = button.data('workman_email');
            var workman_username = button.data('workman_username');
            var workman_mobile = button.data('workman_mobile');
            var workman_type = button.data('workman_type');
            var vender_email = button.data('vender_email');
            var vender_name = button.data('vender_name');
            var vender_code = button.data('vender_code');
            var vender_mobile = button.data('vender_mobile');
            // alert("id"+id);
           //  alert(workman_type);
            // alert(workman_email);
            if(workman_type == 'V'){
                $(".ven").css("display", "block"); 
            } else {
                $(".ven").css("display", "none");
            }
            var modal = $(this);
            modal.find('#workman_name_edit').val(workman_name);
            modal.find('#workman_email_edit').val(workman_email);
            modal.find('#workman_username_edit').val(workman_username);
            modal.find('#workman_mobile_edit').val(workman_mobile);
            modal.find('#workman_type_edit').val(workman_type);
            modal.find('#vender_email_edit').val(vender_email);
            modal.find('#vender_name_edit').val(vender_name);
            modal.find('#vender_code_edit').val(vender_code);
            modal.find('#vender_mobile_edit').val(vender_mobile);
            modal.find('#id_modal').val(id);
        });
    });

    $(document).on("click", "#update_data", function() {
        $('#modal-loader').modal('show');

        $.ajax({
            url: "work_man_update.php",
            type: "POST",
            cache: false,
            data: {
                id: $('#id_modal').val(),
                workman_name_edit: $('#workman_name_edit').val(),
                workman_email_edit: $('#workman_email_edit').val(),
                workman_username_edit: $('#workman_username_edit').val(),
                workman_mobile_edit: $('#workman_mobile_edit').val(),
                workman_type_edit: $('#workman_type_edit').val(),
                vender_email_edit: $('#vender_email_edit').val(),
                vender_name_edit: $('#vender_name_edit').val(),
                vender_code_edit: $('#vender_code_edit').val(),
                vender_mobile_edit: $('#vender_mobile_edit').val(),
            },
            success: function(dataResult) {
                var dataResult = JSON.parse(dataResult);
                if (dataResult.statusCode == 200) {
                    $('#modal-loader').modal('hide');
                    // $('#modal-update').modal().hide();
                    swal("Workman Updated!", "", "success");
                    loaddata();
                }
            }
        });
    });
</script>

<!-- DELETE DATA  -->
<script>
    $(document).on("click", "#delete", function() {
        var jobcatID = $(this).attr('data-id');
        var dataResult = "";
        swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this data!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: "delete.php",
                        type: "POST",
                        cache: false,
                        data: {
                            id: jobcatID,
                            dtable: "workman",
                            ctable: "job_workman",
                            field: "workman_id",
                        },
                        success: function(dataResult) {
                            dataResult = JSON.parse(dataResult);
                            // console.log(dataResult);
                            if (dataResult == 'success') {
                                loaddata();
                                swal("Deleted Successfully", {
                                    icon: "success",
                                });
                            } else if (dataResult == 'duplicate') {
                                loaddata();
                                swal("Data already associated with Child Table!", {
                                    icon: "error",
                                });
                            }
                        }
                    });

                } else {
                    swal("Delete Action Cancelled by User!", {
                        icon: "warning",
                    });
                }
            });

    });
</script>

<!-- Reset Password  -->
<script>
    $(document).on("click", "#reset_password", function() {
        var dataId = $(this).attr("data-id");
        swal({
                title: "Are you sure?",
                text: "Once Reset, you will not be able to recover this imaginary Password!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: "work_man_reset_password.php",
                        type: "POST",
                        cache: false,
                        data: {
                            id: dataId,
                        },
                        success: function(dataResult) {
                            var dataResult = JSON.parse(dataResult);
                        }
                    });

                    loaddata();
                    swal("Poof! Your imaginary file has been Reset!", {
                        icon: "success",
                    });
                } else {
                    swal("Your imaginary Password is safe!");
                }
            });
        loaddata();
    });
</script>

<?php
include("layouts/footer.php");
?>