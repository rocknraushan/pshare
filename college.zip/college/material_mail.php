<?php
session_start();
error_reporting(0);
include("../inc/db_conn.php");
$id=3;
?>
<html>
<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>MATERIAL RECEIPT</title>
</head>
<body>
<?PHP
$get_receipt = mysqli_query($conn, "SELECT delivery_challan_parent.* ,site_master.site,site_master1.site AS stock_point,delivery_challan_parent.receipt_datetime,user_master.user_name,delivery.user_name AS delivery_name
FROM `delivery_challan_parent`
LEFT JOIN site_master ON delivery_challan_parent.from_site = site_master.id
LEFT JOIN site_master AS site_master1 ON delivery_challan_parent.destination_stock_point =  site_master1.id
LEFT JOIN user_master ON delivery_challan_parent.delivery_challan_user_id =user_master.id
LEFT JOIN user_master AS delivery ON delivery_challan_parent.receipt_by =user_master.id
WHERE delivery_challan_parent.id='$id' GROUP BY delivery_challan_parent.id");

    ?>
<div align="center">
	<table border="1" width="56%" cellspacing="0" bordercolor="#000000">
    
		<tr>
			<td colspan="2" bgcolor="#000000" height="34">
			<p align="center"><b><font face="Arial" color="#FFFFFF">MATERIAL 
			RECEIPT</font></b></td>
		</tr>
        <?php while ($receipt_list = mysqli_fetch_assoc($get_receipt)) { ?>
		<tr>
			<td width="50%" height="20" align="center">
			<font face="Arial" size="2">DELIVERY CHALLAN DATE</font></td>
			<td width="48%" height="20"><font face="Arial" size="2"><?php echo $receipt_list['receipt_datetime']; ?></font></td>
		</tr>
		<tr>
			<td width="50%" height="20" align="center">
			<font face="Arial" size="2">DELIVERY CHALLAN NO</font></td>
			<td width="48%" height="20"><font face="Arial" size="2"><?php echo $receipt_list['id'] ?></font></td>
		</tr>
		<tr>
			<td width="50%" align="center"><font face="Arial" size="2">Source Stock Point</font></td>
			<td width="48%"><font face="Arial" size="2"><?php echo $receipt_list['site'] ?></font></td>
		</tr>
		<tr>
			<td width="50%" align="center"><font face="Arial" size="2">
			Destination Stock Point</font></td>
			<td width="48%"><font face="Arial" size="2"><?php echo $receipt_list['stock_point'] ?></font></td>
		</tr>
		<tr>
			<td width="50%" align="center"><font face="Arial" size="2">REMARKS</font></td>
			<td width="48%"><font face="Arial" size="2"><?php echo $receipt_list['remarks'] ?></font></td>
		</tr>
		<tr>
			<td width="50%" align="center"><font face="Arial" size="2">DELIVERY CHALLAN BY</font></td>
			<td width="48%"><font face="Arial" size="2"><?php echo $receipt_list['user_name'] ?></font></td>
		</tr>
		<tr>
			<td width="50%" align="center"><font face="Arial" size="2">RECEIPT BY ON</font></td>
			<td width="48%"><font face="Arial" size="2"><?php echo $receipt_list['delivery_name'] ?></font></td>
		</tr>
		<tr>
			<td width="50%" align="center"><font face="Arial" size="2">IMAGE</font></td>
			<td width="48%"><font face="Arial" size="2"><img src="data:image/png;base64,<?= $receipt_list['image'] ?>" style="width:200px; height:200px;"></font></td>
		</tr>
        <?php } ?>

		<tr>
			<td width="76%" colspan="2" height="58">
			<div align="center">
				<table border="1" width="94%" cellspacing="0" cellpadding="2" bordercolor="#666666">
					<tr>
						<td width="11"><font face="Arial" size="2">#</font></td>
						<td><font face="Arial" size="2">MATERIAL NAME</font></td>
						<td><font face="Arial" size="2">QUANTITY</font></td>
					</tr>
                    <?php
                    $i=0;
                    $get_material = mysqli_query($conn, "SELECT delivery_challan_child.qty,product_master.product
                                FROM  delivery_challan_child
                                LEFT JOIN product_master ON delivery_challan_child.material_id=product_master.id
                                WHERE delivery_challan_child.dc_parent_id='$id'");
                    while ($material_list = mysqli_fetch_assoc($get_material)) {
                    ?>
					<tr>
						<td width="11"><font face="Arial" size="2"><?php echo ++$i ?></font></td>
						<td><font face="Arial" size="2"><?php echo $material_list['product'] ?></font></td>
						<td><font face="Arial" size="2"><?php echo $material_list['qty'] ?></font></td>
					</tr>
                    <?php } ?>
				</table>
			</div>
			</td>
		</tr>
	</table>
</div>
</body>
</html>
