<?php
session_start();

include("../inc/db_conn.php");
//$db=$conn;// database connection  
$myid = $_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');
$unit_name   = $_POST['unit_name'];
$material_name   = $_POST['material_name'];
$opening_quantity   = $_POST['opening_quantity'];

$EXE   = mysqli_query($conn, "INSERT INTO material SET unit_name = '$unit_name',material_name = '$material_name', created_by='$myid',created_date_time='$date'");
$id = mysqli_insert_id($conn);
if($opening_quantity){
    mysqli_query($conn, "INSERT INTO txn_logs SET type = 'IN',in_type = 'Opening',quantity = '$opening_quantity',
   material_id='$id', datetime='$date',entry_by='$myid'");
}
?>