<?php
session_start();
include("../inc/check_login.php"); 
include("../inc/db_conn.php");
$myid=$_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');	
	$id=$_POST['id']; 
	$exe=mysqli_query($conn, "DELETE FROM role_permission WHERE role_master_id='$id'"); 
	$sql = mysqli_query($conn,"UPDATE  `role_master` SET is_deleted='Y', deleted_by='$myid',deleted_date_time='$date'  WHERE `id`='$id'");
?>