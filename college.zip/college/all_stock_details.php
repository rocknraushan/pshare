<?php
session_start();
include("../inc/db_conn.php");
// $token    = addslashes($_REQUEST['id']);
// $stock_userid = $_REQUEST['stock_userid']; 
$token    =  $_GET['id'];
if($_GET['stock_userid'] =='a'){
    $stock_userid=0;
}else{
    $stock_userid = $_GET['stock_userid'];
}

?>
<div class="modal-body">
    <div class="col col-lg-12">
        <div class="col col-lg-6">
            <div class="form-group">
                <label for="exampleInputEmail1"> Material Name</label>                
                    <?php $product = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM material WHERE id='$token'")); ?>                   
                <input type="text" class="form-control rec" value="<?= $product['material_name']; ?>" readonly>
            </div>
        </div> 
        <div class="col col-lg-6">
            <div class="form-group">
                <label for="exampleInputEmail1"> Workman Name</label> 
                <?php if($stock_userid =='0' || $stock_userid =="")  {   ?>
                    <input type="text" class="form-control rec" value="Head office" readonly>                      
                <?php }else{
                    $workmanList = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM workman WHERE id='$stock_userid'")); ?>                  
                    <input type="text" class="form-control rec" value="<?= $workmanList['workman_name']; ?>" readonly>
                <?php } ?>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="form-group">
            <table class="table table-bordered table-hover table-condensed">
                <thead>
                    <tr>
                        <th>SL</th>
                        <th>Date & Time</th>
                        <th>Particulars</th>
                        <th>Credit</th>
                        <th>Debit</th>
                        <th>Balance</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $c = 1;
                    $txnQ = mysqli_query($conn, "SELECT txn_logs.*,workman.workman_name 
                    FROM txn_logs 
                    LEFT JOIN workman on txn_logs.stock_userid=workman.id
                    WHERE txn_logs.material_id ='$token' AND stock_userid='$stock_userid'");
                    $Numrows = mysqli_num_rows($txnQ);
                    if ($Numrows > 0) {
                        $balence = 0;
                        while ($txnList = mysqli_fetch_array($txnQ)) {
                    ?>
                            <tr>
                                <td style="width:1%" class="sl"><?= $c++;  ?></td>
                                <td style="width:15%"><?php echo date('d-m-Y H:i', strtotime($txnList['datetime'])) ?></td>
                                <td style="width:35%">
                                    <?php echo $txnList['type'];
                                    if ($txnList['type'] == 'IN') {
                                        echo "-" . $txnList['in_type'];
                                        if ($txnList['stock_userid'] == '0') {
                                            echo "(Head Office)";
                                        } else {
                                            echo "(" . $txnList['workman_name'] . ")";
                                        }
                                    ?>
                                <td><?php echo  $txnList['quantity']; ?></td>
                                <?php $balence += $txnList['quantity']; ?>
                                <td></td>
                                <td><?php echo $balence; ?></td>
                            <?php
                                    } else {
                                        echo "-" . $txnList['out_type'];
                                        if ($txnList['stock_userid'] == '0') {
                                            echo "(Head Office)";
                                        } else {
                                            echo "(" . $txnList['workman_name'] . ")";
                                        }
                            ?>
                                <td></td>
                                <td><?php echo  $txnList['quantity']; ?></td>
                                <?php $balence -= $txnList['quantity']; ?>
                                <td><?php echo $balence; ?></td>
                            <?php
                                    }
                            ?>
                            </tr>
                        <?php } ?>
                    <?php  } else { ?>
                        <tr>
                            <td colspan="6">
                                <center>No Data Available</center>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>