<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$myid=$_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');	
	$id=$_POST['id']; 
	$pwd=rand(0000,9999);
	$sql = "UPDATE  `workman` SET workman_password='$pwd',force_pwd='Y' WHERE `id`='$id'";
	$userList= mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM workman WHERE id='$id'"));
	$email=$userList['workman_email'];
	$mobile=$userList['workman_mobile'];
	$name=$userList['workman_name'];
	if (mysqli_query($conn, $sql)) {
		//send email sms
		include "email_message_send.php";
        email_sms($email,$mobile,$name,$pwd);
		echo json_encode(array("statusCode"=>200));
	} 
	else {
		echo json_encode(array("statusCode"=>201));
	}
	
	mysqli_close($conn);
?>