<?php
header("Content-type: application/excel");
header("Content-Disposition: attachment; filename=complaint_All.xls");
header("Pragma: no-cache");
header("Expires: 0");
session_start();
include("../inc/db_conn.php");
$myid = $_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
// $date = date('Y-m-d H:i:s');

$from = $_REQUEST['from'];
$to   = $_REQUEST['to'];
$compalint_type  = $_REQUEST['compalint_type'];
if ($from) {
    $from  = date('Y-m-d 00:00:00', strtotime($from));
    $to    = date('Y-m-d 23:59:59', strtotime($to));
    $date = "date_time BETWEEN '$from' AND '$to'";
} else {
    $from  = date('Y-m-d 00:00:00');
    $to    = date('Y-m-d 23:59:59');
    $date = "date_time BETWEEN '$from' AND '$to'";
}
?>

<head>
    <!-- <style> -->
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous"> -->
    <!-- </style> -->
</head>
<div id="content" class="">
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-heading">
                    <div class="panel-title" style="float:left">
                    </div>
                </div>
                <div class="panel-body">
                    <?php
                    echo "Type : $compalint_type | From Date : $from | To Date : $to";
                    ?>
                    <table border="1" class="" id="">
                        <thead>
                            <tr>
                                <th>
                                    <div align="center"><strong>SL No.</strong></div>
                                </th>
                                <th>
                                    <div align="center"><strong>Complaint Number</strong></div>
                                </th>
                                <th>
                                    <div align="center"><strong>Complaint Datetime</strong></div>
                                </th>
                                <th>
                                    <div align="center"><strong>Employee Name</strong></div>
                                </th>
                                <th>
                                    <div align="center"><strong>Employee P Number</strong></div>
                                </th>
                                <th>
                                    <div align="center"><strong>Employee Mobile</strong></div>
                                </th>
                                <th>
                                    <div align="center"><strong>Job</strong></div>
                                </th>
                                <th>
                                    <div align="center"><strong>Complaint Description</strong></div>
                                </th>
                                <th>
                                    <div align="center"><strong>Assigned To</strong></div>
                                </th>
                                <th>
                                    <div align="center"><strong>Status</strong></div>
                                </th>
                                <th>
                                    <div align="center"><strong>Complaint Photo</strong></div>
                                </th>
                                <th>
                                    <div align="center"><strong>Workman Feedback</strong></div>
                                </th>
                                <th>
                                    <div align="center"><strong>Material Used</strong></div>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            
                            <?php
                            
                            $count = 0;
                            if ($compalint_type == 'All') {
                                $result1 = mysqli_query($conn, "SELECT complaint.* ,workman.workman_name,jobs.jobs_name,employee.name,employee.p_number,employee.phone
                                        FROM complaint 
                                        LEFT JOIN workman ON complaint.allocated_to = workman.id
                                        LEFT JOIN jobs ON complaint.type_of_job = jobs.id 
                                        LEFT JOIN employee ON complaint.employee_id = employee.id  
                                        WHERE complaint.complaint_login_datetime between '$from' AND '$to'                                        
                                        ORDER BY complaint.id DESC");
                            } elseif($compalint_type=="Beyound-SLG"){
                                $get_complaint = mysqli_query($conn, "SELECT complaint.* ,workman.workman_name,jobs.jobs_name,employee.name,employee.p_number,employee.phone
                                            FROM complaint 
                                            LEFT JOIN workman ON complaint.allocated_to = workman.id
                                            LEFT JOIN jobs ON complaint.type_of_job = jobs.id 
                                            LEFT JOIN employee ON complaint.employee_id = employee.id 
                                            WHERE complaint.complaint_login_datetime between '$from' AND '$to' AND complaint.estimated_date_of_completion < complaint.complaint_closed_datetime
                                            ORDER BY complaint.id DESC");
                            }
                            elseif ($compalint_type == 'Repeat-Complaint') {
                                $result1 = mysqli_query($conn, "SELECT complaint.* ,workman.workman_name,jobs.jobs_name,employee.name,employee.p_number,employee.phone
                                FROM complaint 
                                LEFT JOIN workman ON complaint.allocated_to = workman.id
                                LEFT JOIN jobs ON complaint.type_of_job = jobs.id 
                                LEFT JOIN employee ON complaint.employee_id = employee.id  
                                WHERE complaint.complaint_login_datetime between '$from' AND '$to' AND complaint.repeat_complaint='on'
                                            ORDER BY complaint.id DESC");
                            } else {
                                $result1 = mysqli_query($conn, "SELECT complaint.* ,workman.workman_name,jobs.jobs_name,employee.name,employee.p_number,employee.phone
                                        FROM complaint 
                                        LEFT JOIN workman ON complaint.allocated_to = workman.id
                                        LEFT JOIN jobs ON complaint.type_of_job = jobs.id 
                                        LEFT JOIN employee ON complaint.employee_id = employee.id  
                                        WHERE complaint.complaint_login_datetime between '$from' AND '$to' AND complaint.complaint_status ='$compalint_type'                                      
                                        ORDER BY complaint.id DESC");
                            }
                            while ($complaintList = mysqli_fetch_assoc($result1)) {
                            ?>
                                <tr>
                                    <td>
                                        <div align="center">
                                            <?= ++$count ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div align="center">
                                            C/<?= date('m-Y', strtotime($complaintList['complaint_login_datetime'])); ?>/<?= $complaintList['complaint_number']; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div align="center">
                                            <?= date('d-m-Y h:i A', strtotime(@$complaintList['complaint_login_datetime'])) ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div align="center">
                                            <?= @$complaintList['name'] ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div align="center">
                                            <?= @$complaintList['p_number'] ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div align="center">
                                            <?= @$complaintList['phone'] ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div align="center">
                                            <?= @$complaintList['jobs_name'] ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div align="center">
                                            <?= @$complaintList['complaint_description'] ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div align="center">
                                            <?= @$complaintList['workman_name'] ?>
                                        </div>
                                    </td>
                                    <?php if ($complaintList['complaint_status'] == 'Pending_For_Allocation') {
                                        $status = "Pending for Job Card";
                                        $cl = "info";
                                    } elseif ($complaintList['complaint_status'] == 'Pending_For_Workman') {
                                        $status = "Work in Progress";
                                        $cl = "info";
                                    } elseif ($complaintList['complaint_status'] == 'Pending_For_Closer') {
                                        $status = "Pending for Closure";
                                        $cl = "info";
                                    } elseif ($complaintList['complaint_status'] == 'Closer') {
                                        $status = "Closed";
                                        $cl = "success";
                                    }
                                    ?>
                                    <td>
                                        <div align="center" class="badge badge-<?= $cl ?>">
                                            <?= @$status ?>
                                        </div>
                                    </td>
                                    <?php if($complaintList['complaint_photo']){ ?>
                                    <td>
                                        <div align="center">
                                            <img src="data:image/png;base64,<?= @$complaintList['complaint_photo'] ?>" width="200" height="200">
                                        </div>
                                    </td>
                                    <?php }else{ echo "<td></td>"; } ?>
                                    <td>
                                        <table border="1">
                                            <tr>
                                                <th>Resolved</th>
                                                <th>Datetime</th>
                                                <th>Remarks</th>
                                                <th>Employee Feedback</th>
                                                <th>Feedback Datetime</th>
                                                <th>Image</th>
                                                
                                            </tr>
                                            <?php
                                            $feedbackQuery = mysqli_query($conn, "SELECT * FROM workman_feedback WHERE complaint_id ='" . $complaintList['id'] . "'");
                                            while ($feedbackList = mysqli_fetch_assoc($feedbackQuery)) {
                                            ?>
                                                <tr>
                                                    <td>
                                                        <div align="center"><?= @$feedbackList['resolved'] ?></div>
                                                    </td>
                                                    <td>
                                                        <div align="center"><?= date('d-m-Y h:i A', strtotime(@$feedbackList['complaint_datetime'])) ?></div>
                                                    </td>
                                                    <td>
                                                        <div align="center"><?= @$feedbackList['remarks'] ?></div>
                                                    </td>
                                                    <td>
                                                        <div align="center"><?= @$feedbackList['employee_feedback'] ?></div>
                                                    </td>
                                                    <td>
                                                        <div align="center"><?= @$feedbackList['feedback_datetime'] ?></div>
                                                    </td>
                                                    <?php if($feedbackList['image']){ ?>
                                                    <td>
                                                        <div align="center"><img src="data:image/png;base64,<?= @$feedbackList['image'] ?>" width="200" height="200"></div>
                                                    </td>
                                                    <?php  }else{ echo "<td></td>" ; } ?>
                                                </tr>
                                            <?php } ?>
                                        </table>
                                    </td>

                                    <td>

                                        <table border="1">
                                            <tr>
                                                <th>Material</th>
                                                <th>Quantity</th>
                                            </tr>
                                            <?php
                                            $materialquery = mysqli_query($conn, "SELECT txn_logs.quantity ,material.material_name 
                                                                        FROM txn_logs
                                                                        LEFT JOIN material ON txn_logs.material_id = material.id
                                                                        WHERE txn_logs.complaint_id='" . $complaintList['id'] . "' GROUP BY txn_logs.id");

                                            while ($materiallist = mysqli_fetch_assoc($materialquery)) {
                                            ?>
                                                <tr>
                                                    <td>
                                                        <div align="center"><?= @$materiallist['material_name'] ?></div>
                                                    </td>
                                                    <td>
                                                        <div align="center"><?= @$materiallist['quantity'] ?></div>
                                                    </td>
                                                </tr>
                                            <?php } ?>
                                        </table>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
