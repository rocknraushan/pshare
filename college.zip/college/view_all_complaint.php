<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$head = "complaint";
$page = "view_all";
include("layouts/header.php");
$user_id  = $_SESSION['userid'];
$fin_year = $_SESSION['active_fin_year'];

?>
<style>
    .content {
        background-color: white;
    }
</style>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-12">
                   <div style="float: left;"> <h1 class="m-0">View Complaints</h1></div>
                    <div style="float: right;"><button  onclick='window.location.reload();' class="btn btn-info">Refresh</button></div>
                </div>
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div><!-- /.content-header -->

    <!-- Main content -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">


                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="all" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">All</a>
                    </li>
                    <?php if (in_array("allocate.php", $_SESSION['allowed_file']) || $_SESSION['role'] == '0') { ?>
                        <li class="nav-item">
                            <a class="nav-link" id="pending_for_allocation" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Job Card Pending For Allocation</a>
                        </li>
                    <?php } ?> 
                    <li class="nav-item">
                        <a class="nav-link" id="pending_for_workman" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false">Pending For Workman</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="pending_for_closure" data-toggle="tab" href="#contact1" role="tab" aria-controls="contact1" aria-selected="false">Pending For Closure</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="closure" data-toggle="tab" href="#contact2" role="tab" aria-controls="contact2" aria-selected="false"> Closed</a>
                    </li>
                </ul>
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="all">
                        <!-- ---------------------  -->

                        <div class="card">

                            <div class="card-body">
                                <div class="alert alert-success alert-dismissible" id="success" style="display:none;">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                </div>

                                <table id="example1" class="table table-bordered table-hover table-condensed">

                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Date of Complaint</th>
                                            <th scope="col">Complaint No.</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">P. No.</th>
                                            <th scope="col">Mobile</th>
                                            <th scope="col">Job</th>
                                            <th scope="col">Description</th>
                                            <th scope="col">Assigned To</th>
                                            <th scope="col">Status</th>
                                        </tr>
                                    </thead>

                                    <tbody id="all_data">

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>


                    <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="pending_for_allocation">

                        <div class="card">
                            <!-- <div class="card-header border-0">
                                                    <div class="d-flex justify-content-between">

                                                    </div>
                                                </div> -->
                            <div class="card-body">
                                <div class="alert alert-success alert-dismissible" id="success" style="display:none;">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                </div>
                                <table id="example3" class="table table-bordered table-hover table-condensed">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Date of Complaint</th>
                                            <th scope="col">Complaint No.</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">P. No.</th>
                                            <th scope="col">Mobile</th>
                                            <th scope="col">Job</th>
                                            <th scope="col">Description</th>
                                            <th scope="col">Assigned To</th>
                                        </tr>
                                    </thead>
                                    <tbody id="pending_for_allocation_data">
                                    </tbody>
                                </table>
                            </div>
                        </div>


                    </div>
                    <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="pending_for_workman">

                        <div class="card">

                            <div class="card-body">
                                <div class="alert alert-success alert-dismissible" id="success" style="display:none;">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                </div>
                                <div class="form-group ven">
                                    <label for="exampleInputEmail1">Workman Name </label>
                                    <select id="workman_name_select" class="form-control rec" required>
                                        <option value="">All </option> 
                                        <?php
                                        $q1 = mysqli_query($conn, "SELECT id,workman_name FROM workman WHERE is_deleted='N'");
                                        while ($listofWORKMAN = mysqli_fetch_assoc($q1)) {
                                            // ----------------------------
                                            $id_count = $listofWORKMAN['id'];
                                            $dt = date('Y-m-d', strtotime($date));
                                            $row5=  mysqli_fetch_assoc(mysqli_query($conn,"SELECT count(allocated_to) AS pending_job FROM complaint  WHERE allocated_to = '$id_count' AND complaint_status='Pending_For_Workman'")); 
                                       
                                            // --------------------------
                                        ?>
                                            <option value="<?= $listofWORKMAN['id']; ?>"><?= $listofWORKMAN['workman_name'];  ?>(Pending Jobs - <?= $row5['pending_job']; ?>)</option>
                                        <?php
                                        }   ?>
                                    </select>
                                </div>
                                <table id="example4" class="table table-bordered table-hover table-condensed">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Date of Complaint</th>
                                            <th scope="col">Complaint No.</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">P. No.</th>
                                            <th scope="col">Mobile</th>
                                            <th scope="col">Job</th>
                                            <th scope="col">Description</th>
                                            <th scope="col">Assigned To</th>
                                        </tr>
                                    </thead>
                                    <tbody id="pending_for_workman_data">
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="contact1" role="tabpanel" aria-labelledby="pending_for_closure">

                        <div class="card">

                            <div class="card-body">
                                <div class="alert alert-success alert-dismissible" id="success" style="display:none;">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                </div>
                                <table id="example5" class="table table-bordered table-hover table-condensed">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Date of Complaint</th>
                                            <th scope="col">Complaint No.</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">P. No.</th>
                                            <th scope="col">Mobile</th>
                                            <th scope="col">Job</th>
                                            <th scope="col">Description</th>
                                            <th scope="col">Assigned To</th>
                                        </tr>
                                    </thead>
                                    <tbody id="pending_for_closure_data">
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="contact2" role="tabpanel" aria-labelledby="closure">

                        <div class="card">
                            <!-- <div class="card-header border-0">
                                                    <div class="d-flex justify-content-between">

                                                    </div>
                                                </div> -->
                            <div class="card-body">
                                <div class="alert alert-success alert-dismissible" id="success" style="display:none;">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                </div>
                                <table id="example6" class="table table-bordered table-hover table-condensed">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Date of Complaint</th>
                                            <th scope="col">Complaint No.</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">P. No.</th>
                                            <th scope="col">Mobile</th>
                                            <th scope="col">Job</th>
                                            <th scope="col">Description</th>
                                            <th scope="col">Assigned To</th>
                                        </tr>
                                    </thead>
                                    <tbody id="closure_data">
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
<!-- /.content-wrapper -->

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->

</div>

<div class="modal" id="modal-loader" style="z-index:1000000000">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body" style="z-index:1000000000">
                <img class="mx-auto d-block" src="dist/img/loader.gif" />
                <p class="text-center">Please Wait</p>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<script>
    $(document).ready(function() {
        All_data();
    });
    $(document).on('click', '#all', function(e) {
        e.preventDefault();
        All_data();
    });

    function All_data() {
        $('#modal-loader').modal('show');
        $.ajax({
            method: "POST",
            url: "view_all_complaint_all.php",
            data: {
                id: 1,

            },
            success: function(data) {
                $("#all_data").html('');
                $("#all_data").append(data);
                $('#example1').DataTable();
                $('#modal-loader').modal('hide');
            }
        });
    }
    $(document).on('change', '#workman_name_select', function(e) {
        $('#modal-loader').modal('show');
        var workman_name_select = $(this).val();
        e.preventDefault();
        $.ajax({
            method: "POST",
            url: "view_all_complaint_change.php", 
            data: {
                id3: 1,
                workman_name_select: workman_name_select
            },
            success: function(data) {
                $("#pending_for_workman_data").html('');
                $("#pending_for_workman_data").append(data);
                // $('#example4').DataTable();
                $('#modal-loader').modal('hide');
            }
        });
    });
    $(document).on('click', '#pending_for_allocation', function(e) {
        $('#modal-loader').modal('show');
        e.preventDefault();
        $.ajax({
            method: "POST",
            url: "view_all_complaint_change.php",
            data: {
                id2: 1,
            },
            success: function(data) {
                $("#pending_for_allocation_data").html('');
                $("#pending_for_allocation_data").append(data);
                $('#example3').DataTable();
                $('#modal-loader').modal('hide');

            }
        });
    });

    $(document).on('click', '#pending_for_workman', function(e) {
        $('#modal-loader').modal('show');
        e.preventDefault();
        $.ajax({
            method: "POST",
            url: "view_all_complaint_change.php",
            data: {
                id3: 1,
            },
            success: function(data) {
                // $("#workman_name_select").html('');
                $('#modal-loader').modal('hide');
                $("#pending_for_workman_data").html('');
                $("#pending_for_workman_data").append(data);
                // $('#example4').DataTable();
               

            }
        });
    });

    $(document).on('click', '#pending_for_closure', function(e) {
        e.preventDefault();
        $('#modal-loader').modal('show');
        $.ajax({
            method: "POST",
            url: "view_all_complaint_change.php",
            data: {
                id4: 1,

            },
            success: function(data) {
                $('#modal-loader').modal('hide');
                $("#pending_for_closure_data").html('');
                $("#pending_for_closure_data").append(data);
                $('#example5').DataTable();
            }
        });
    });

    $(document).on('click', '#closure', function(e) {
        $('#modal-loader').modal('show');
        e.preventDefault();
        $.ajax({
            method: "POST",
            url: "view_all_complaint_change.php",
            data: {
                id5: 1,

            },
            success: function(data) {
                $('#modal-loader').modal('hide');
                $("#closure_data").html('');
                $("#closure_data").append(data);
                $('#example6').DataTable();
               

            }
        });
    });
</script>
<?php
include("layouts/footer.php");
?>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>