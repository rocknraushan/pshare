<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");	
$myid=$_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');
	$id = $_POST['idUnq'];
	$job_category =   $_POST['jobCat'];
	$job_sub_category = $_POST['jobSubCat'];
	$sql = "UPDATE `job_sub_category` SET `job_category`='$job_category',`job_sub_category`='$job_sub_category', updated_by='$myid',updated_date_time='$date' WHERE `id`='$id'";
	// echo $sql;
	// exit;
	if (mysqli_query($conn, $sql)) {
		echo json_encode(array("statusCode"=>200));
	} 
	else {
		echo json_encode(array("statusCode"=>201));
	}
?>