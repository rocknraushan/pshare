<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");	
$myid=$_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');
$id=$_POST['id'];
$dtable=$_POST['dtable'];
$ctable=$_POST['ctable'];
$field=$_POST['field'];

$sql2 = "SELECT id FROM $ctable WHERE $field='$id' AND is_deleted='N'";
$result2 = $conn->query($sql2);
if ($result2->num_rows == 0) {
$sql = "UPDATE `$dtable` SET is_deleted='Y', deleted_by='$myid',deleted_date_time='$date'  WHERE `id`='$id'";
$exe=mysqli_query($conn, $sql);
$result="success";
}
else
{
$result="duplicate";
}
echo json_encode($result);
mysqli_close($conn);
?>  