<?php
session_start();
include("../inc/db_conn.php");
$id=$_POST['id'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');
$complaint_status='Pending_For_Closer';

    $sql = "UPDATE  `complaint` SET complaint_status='$complaint_status'  WHERE `id`='$id'";
    mysqli_query($conn, $sql);
?>