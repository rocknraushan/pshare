<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$myid=$_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');	
	$id=$_POST['id']; 
	$house_status = $_POST['house_status'];
	$sql5 = "UPDATE house SET house_status='Non-Active' WHERE id='$house_status'";
	mysqli_query($conn,$sql5);
	$sql = "UPDATE  `employee` SET is_deleted='Y', deleted_by='$myid',deleted_date_time='$date'  WHERE `id`='$id'";
	$sql1 = "UPDATE employee_house SET status='Non-Active', created_by='$myid',created_date_time='$date' WHERE employee_id='$id' ";
	mysqli_query($conn,$sql1);
	if (mysqli_query($conn, $sql)) {
		echo json_encode(array("statusCode"=>200));
	} 
	else {
		echo json_encode(array("statusCode"=>201));
	}
	
	mysqli_close($conn);
?>