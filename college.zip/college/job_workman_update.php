<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$myid = $_SESSION['userid'];
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('Y-m-d H:i:s');
$id = $_POST['idUnq1'];
$job_category_id   = $_POST['job_category_id_edit'];
$workman_id   = $_POST['workman_id_edit'];
$jobs_name = $_POST['jobs_name_edit'];
$slg = $_POST['slg_edit'];
$sql = "UPDATE `job_workman` SET `job_category_id`='$job_category_id',`workman_id`='$workman_id',
	 updated_by='$myid',updated_date_time='$date' WHERE `id`='$id'";
if (mysqli_query($conn, $sql)) {
	echo json_encode(array("statusCode" => 200));
} else {
	echo json_encode(array("statusCode" => 201));
}
