<?php
session_start();
include("../inc/check_login.php");
include("../inc/db_conn.php");
$head="masters";
$head1="employee";
$page="job_workman";
include("layouts/header.php");
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h3 class="m-0">Masters/Job Work Man</h3>
                </div>
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div><!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header border-0">
                            <div class="d-flex justify-content-between">
                                Job Work Man
                                <div style="float:right">
                                    <a href="#" class="btn btn-success btn-sm" data-toggle="modal" data-target="#exampleModal">Add New</a>
                                </div>
                            </div>
                        </div>

                        <div class="card-body">
                            <div class="alert alert-success alert-dismissible" id="success" style="display:none;">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                            </div>
                            <table id="example1" class="table table-bordered table-sm">
                                <thead>
                                    <tr>
                                        <th>Sl No.</th>
                                        <th>Job Category</th>
                                        <th>Work Man</th>
                                        <th>Edit </th>
                                        <th>Delete</th>
                                    </tr>
                                </thead>
                                <tbody id="table">

                                </tbody>
                            </table>

                            <script type="text/javascript">
                                $(document).ready(function() {
                                    loaddata();
                                });

                                function loaddata() {
                                    $('#modal-loader').modal('show');

                                    $.ajax({
                                        url: 'job_workman_view.php',
                                        type: 'POST',
                                        dataType: 'html',
                                        success: function(newContent) {
                                            $('#table').html('');
                                            $('#table').append(newContent);
                                            $('#example1').DataTable();
                                            $('#modal-loader').modal('hide');

                                        }
                                    });
                                }
                            </script>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- /.content -->
    <!-- /.content-wrapper -->
</div>
</div>

</body>


<div class="modal" id="modal-loader" style="z-index:1000000000">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body" style="z-index:1000000000">
                <img class="mx-auto d-block" src="dist/img/loader.gif" />
                <p class="text-center">Please Wait</p>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- ====ADD DATA =====  -->
<?php $count = 1; ?>
<div class="modal" id="exampleModal">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Job Work Man</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form class="form-horizontal" role="form" method="post" autocomplete="off" id="userForm" action="">
                <div class="modal-body">
                    <input type="hidden" value="<?= @$data['id'] ?>" name="token">
                    <div class="form-group">
                        <table class="table" style=" border: 1px solid black;">
                            <thead>
                                <tr>
                                    <th>Sl. No.</th>
                                    <th>Job Category Type</th>
                                    <th>Work Man Type</th>
                                    <th>Action</th>
                                </tr>
                            </thead> 
                            <tbody id="items_list">
                                <tr>
                                    <td  class="sl">1</td>
                                    <td><select name="job_category_id[]" id=" " class="form-control rec" required >
                                        <option value="">Select Job Category Type</option>
                                        <?php
                                            $jobs = mysqli_query($conn,"SELECT * FROM job_category  WHERE is_deleted='N' ORDER BY id DESC");
                                            while ($jobslist = mysqli_fetch_array($jobs)) { ?>
                                                <option value="<?= $jobslist['id']; ?>"><?php echo $jobslist['job_category']; ?></option>
                                        <?php  } ?>
                                        </select>
                                    </td>
                                        <td><select name="workman_id[]" id=" " class="form-control rec" required >
                                            <option value="">Select Work Man Type</option>
                                    <?php   $workmans = mysqli_query($conn,"SELECT * FROM workman WHERE is_deleted='N' ORDER BY id DESC");
                                            while($workmanlist = mysqli_fetch_array($workmans)){ ?>
                                                <option value="<?= $workmanlist['id']; ?>"><?php echo $workmanlist['workman_name']; ?></option>
                                    <?php   } ?>
                                        </select></td>
                                    <td style="width:2%"><a href="javascript:void(0)" title="ADD" onclick="addProduct(this)" class="tab-index"><i class="fa fa-plus-circle fa-2x"></i></a></td>
                                </tr>
                            </tbody>                                                      
                        </table>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" id="submit_request" onSubmit="add(event)">Submit</button>
                </div>
        </div>
        </form>
    </div>
</div>
</div>
<script>
    function addProduct(th)
    {
        var tds='<tr><td  style="width:2%" class="sl">1</td>';
            tds+='<td><select name="job_category_id[]"  class="form-control rec"><option value="" required >Select Job Category Type</option>';
                    <?php
                        $jobs = mysqli_query($conn,"SELECT * FROM job_category  WHERE is_deleted='N' ORDER BY id DESC");
                        while ($jobslist = mysqli_fetch_array($jobs)) { ?>
                            tds+='<option value="<?= $jobslist['id']; ?>"><?php echo $jobslist['job_category']; ?></option>';
                    <?php  } ?>
            tds+='</select></td>';
            tds+='<td><select name="workman_id[]" id=" " class="form-control rec" required><option value="">Select Work Man Type</option>';
                <?php   $workmans = mysqli_query($conn,"SELECT * FROM workman WHERE is_deleted='N' ORDER BY id DESC");
                    while($workmanlist = mysqli_fetch_array($workmans)){ ?>
                tds+='<option value="<?= $workmanlist['id']; ?>"><?php echo $workmanlist['workman_name']; ?></option>';
                <?php   } ?>
            tds+='</select></td>';
            tds+='<td style="width:2%"><a href="javascript:void(0)" title="ADD" onclick="addProduct(this)" class="tab-index"><i class="fa fa-plus-circle fa-2x"></i></a></td>';
            tds+='</tr>';
            
            $(th).find('> i').addClass('fa-times-circle');
            $(th).find('> i').removeClass('fa-plus-circle');
            $(th).attr('onclick','$(this).closest("tr").remove();setSl();');     
            $(th).attr('title','DELETE');                                     
            $("#items_list").append(tds);                         
            setSl();
    }  
        
   function setSl()
   {
      var i=0;
      $(".sl").each(function(e){
         i++;
         $(this).html(i);
      })
   }
   
</script>
<!-- =====submit add data =====  -->
<script>
    $(document).on('submit', '#userForm', function(e) {
        // $('#modal-loader').modal('show');
        $('#submit_request').prop('disabled', true);
        e.preventDefault();
        $('#modal-loader').modal('show');
        $.ajax({
            method: "POST",
            url: "job_workman_add.php",
            data: $(this).serialize(),
            success: function(data) {
               
                // $('#-loadermodal').modal('hide');
                // $('#exampleModal').hide();
                $('#userForm').find('input').val('');
                //location.reload();
                $('#userForm').find('select').val('');
                loaddata();
                swal("Job Workman Saved!", "", "success");
                $('#submit_request').prop('disabled', false);
                $('#modal-loader').modal('hide');
            }
        });
    });
</script>


<!-- UPATE  DATA -->
<!-- Modal Update-->
<div class="modal fade" id="modal-update">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Update Job Sub Category</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body">
                <!--1-->
                <input type="hidden" name="" id="idUnq" class="form-control">
                <div class="form-group">
                    <label for="exampleInputPassword1">Job Category </label>
                    <select name="job_category_id_edit" id="job_category_id_edit" class="form-control rec">
                        <option value="">Select Job Category Type</option>
                        <?php
                        $sql1 = "SELECT * FROM job_category  WHERE is_deleted='N' ORDER BY id DESC";
                        $result1 = mysqli_query($conn, $sql1);
                        while ($row1 = mysqli_fetch_assoc($result1)) {
                        ?>
                            <option value="<?= $row1['id']; ?>"><?= $row1['job_category']; ?></option>
                        <?php
                        }   ?>
                    </select>
                </div>
                <!--2-->

                <div class="form-group">
                    <label for="exampleInputEmail1">Workman Name </label>
                    <select name="workman_id_edit" id="workman_id_edit" class="form-control rec">
                        <option value="">Select Workman Type</option>
                        <?php
                        $sql1 = "SELECT * FROM workman  WHERE is_deleted='N' ORDER BY id DESC";
                        $result1 = mysqli_query($conn, $sql1);
                        while ($row1 = mysqli_fetch_assoc($result1)) {
                        ?>
                            <option value="<?= $row1['id']; ?>"><?= $row1['workman_name']; ?></option>
                        <?php
                        }   ?>
                    </select>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary" id="update_data">Update</button>
            </div>
        </div>
    </div>
</div>
</div>
<!-- Modal End-->

<script>
    $(function() {
        $('#modal-update').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget); /*Button that triggered the modal*/
            var id = button.data('id');
            var job_category_id_edit = button.data('job_category_id_edit');
            var workman_id_edit = button.data('workman_id_edit');

            // alert(id);
            // alert(job_category_id_edit);
            // alert(workman_id_edit);
            var modal = $(this);
            modal.find('#idUnq').val(id);
            modal.find('#job_category_id_edit').val(job_category_id_edit);
            modal.find('#workman_id_edit').val(workman_id_edit);
        });
    });

    $(document).on("click", "#update_data", function() {
        $('#modal-loader').modal('show');
        // alert(id);
        // console.log( $('#jobs_category_edit').val());
        $.ajax({
            url: "job_workman_update.php",
            type: "POST",
            cache: false,
            data: {
                idUnq1: $('#idUnq').val(),
                job_category_id_edit: $('#job_category_id_edit').val(),
                workman_id_edit: $('#workman_id_edit').val(),

            },
            success: function() {

                swal("Job Workman  Updated!", "", "success");
                $('#modal-loader').modal('hide');
                //swal("Job  Updated!", "", "success");
                loaddata();

            }
        });
    });
</script>

<!-- DELETE DATA  -->
<script>
    $(document).on("click", "#delete", function() {
        var jobcatID = $(this).attr('data-id');
        var dataResult = "";
        swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this data!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: "delete.php",
                        type: "POST",
                        cache: false,
                        data: {
                            id: jobcatID,
                            dtable: "job_workman", 
                            ctable: "workman",
                            field: "workman_id",
                        },
                        success: function(dataResult) {
                            dataResult = JSON.parse(dataResult);
                            // console.log(dataResult);
                            if (dataResult == 'success') {
                                loaddata();
                                swal("Deleted Successfully!", {
                                    icon: "success",
                                });
                            } else if (dataResult == 'duplicate') {
                                loaddata();
                                swal("Data already associated with Child Table!", {
                                    icon: "error",
                                });
                            }
                        }
                    });

                } else {
                    swal("Delete Action Cancelled by User!", {
                        icon: "warning",
                    });
                }
            });
    });
</script>
<?php
include("layouts/footer.php");
?>