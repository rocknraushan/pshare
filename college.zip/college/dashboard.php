﻿<?php
session_start();
$myid = $_SESSION['userid'];
$file = $_SESSION['allowed_file'];
include("../inc/check_login.php");
include("../inc/db_conn.php");
$head0 = "masters";
// $head1="employee";
$page = "page1";
include("layouts/header.php");
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$today  = date('Y-m-d 00:00:00');
$today1 = date('Y-m-d 23:59:59');
if ($_REQUEST['old_password']) {
    $old_password = @$_REQUEST['old_password'];
    $new_password = @$_REQUEST['new_password'];
    $confirm_new_password = @$_REQUEST['confirm_new_password'];
    // ------------------------------
    if (strlen($new_password) <= '7') {
?>
        <script>
            alert("Your Password Must Contain At Least 7 Digits !");
        </script>
    <?php
    } elseif (!preg_match("#[0-9]+#", $new_password)) { ?>
       <script> alert("Your Password Must Contain At Least 1 Number !" ); </script>
   <?php } elseif (!preg_match("#[A-Z]+#", $new_password)) { ?>
    <script> alert("Your Password Must Contain At Least 1 Capital Letter !"); </script>
    <?php } elseif (!preg_match("#[a-z]+#", $new_password)) { ?>
        <script>alert("Your Password Must Contain At Least 1 Lowercase Letter !") </script>
    <?php } elseif (!preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬-]/', $new_password)) { ?>
        <script>alert("Your Password Must Contain At Least 1 Special Character !"); </script>
   <?php  } else {
        // -------------------------------------
    ?>
        <?php
        if ($old_password != $_SESSION['password']) { ?>
            <script>
                alert("Check Your old Password");
            </script>
        <?php
        } elseif ($new_password != $confirm_new_password) {
        ?>
            <script>
                alert("Passwords do not match!");
            </script>
            <?php
        } else {
            $exe = mysqli_query($conn, "UPDATE `user` SET `password`='$new_password',`force_pwd`='N' WHERE id='$myid'");
            if ($exe) {
                $_SESSION['change_password'] = 'N';
            ?>
                <script>
                    // alert("Set Password Success !");
                </script>
<?php
            }
        }
    }
}
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <!--  <div class="col-lg-3 col-xs-6">     
                    <p><b>Quick Go-To Complaint Number</b></p>
                    <form action="complaint_edit.php" method = "post">
                    
                    <div class="form-group">    

                        <input type="text" class="form-control" id="complaint_number" name="complaint_number" required autocomplete="off" style="
    border: 1px solid #d0d0d0;
    border-radius: 20px;
    width: 570px;
    height: 50px;
    font-size: 22px;
    text-align: center;
">
</div>
<div class="col-lg-3 col-xs-6">     
                        <button type="submit" class="btn btn-primary"  style="
    border: 1px solid #d0d0d0;
    border-radius: 20px;
    width: 100px;
    height: 50px;
    font-size: 22px;
    text-align: center;
    margin-left: 472px;
    margin-top: -66px;
    display: block;
">Go</button>
</div>
                    </form>                
                </div><br>-->
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Dashboard
                    </h1>
                </div>
                <!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-lg-3 col-xs-6">
                    <!-- small box -->
                    <div class="small-box bg-blue" onclick="window.location.href = 'view_all_complaint.php'">
                        <div class="inner">
                            <?php
                            $complaintquery =  mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) as com_total FROM complaint "));
                            ?>
                            <h3><?php echo $complaintquery['com_total'] ?> </h3>

                            <p>Total Complaints</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-pie-graph"></i>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-xs-6">
                    <!-- small box -->
                    <div class="small-box bg-pink" onclick="window.location.href = 'view_all_complaint.php'">
                        <div class="inner">
                            <?php
                            $complaintquery1 =  mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) as com_total FROM complaint WHERE complaint_status='Pending_For_Allocation'"));
                            ?>
                            <h3><?php echo $complaintquery1['com_total'] ?> </h3>
                            <p>Pending for Allocation</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-pie-graph"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-xs-6">
                    <!-- small box -->
                    <div class="small-box bg-red" onclick="window.location.href = 'view_all_complaint.php'">
                        <div class="inner">
                            <?php
                            $complaintquery2 =  mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) as com_total FROM complaint WHERE complaint_status='Pending_For_Workman' "));
                            ?>
                            <h3><?php echo $complaintquery2['com_total'] ?> </h3>
                            <p>Pending from Workman </p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-pie-graph"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-xs-6">
                    <!-- small box -->
                    <div class="small-box bg-yellow" onclick="window.location.href = 'view_all_complaint.php'">
                        <div class="inner">
                            <?php
                            $complaintquery3 =  mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) as com_total FROM complaint WHERE complaint_status='Pending_For_Closer'"));
                            ?>
                            <h3><?php echo $complaintquery3['com_total'] ?> </h3>
                            <p>Pending for Closure</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-exclamation-circle"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-xs-6">
                    <!-- small box -->
                    <div class="small-box bg-green" onclick="window.location.href = 'view_all_complaint.php'">
                        <div class="inner">
                            <?php
                            $complaintquery4 =  mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) as com_total FROM complaint WHERE complaint_status='Closer' "));
                            ?>
                            <h3><?php echo $complaintquery4['com_total'] ?> </h3>
                            <p>Closed</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-pie-graph"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-xs-6">
                    <!-- small box -->
                    <div class="small-box bg-green" onclick="window.location.href = 'view_all_complaint.php'">
                        <div class="inner">
                            
                            <h3><?php echo $complaintquery4['com_total']+$complaintquery3['com_total'] ?> </h3>
                            <p>Close from Workman</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-pie-graph"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-xs-6">
                    <!-- small box -->
                    <div class="small-box bg-red">
                        <div class="inner">
                            <?php
                            $beyondquery =  mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) AS beyond_count  FROM complaint WHERE estimated_date_of_completion < complaint_closed_datetime ORDER BY id DESC"));
                            ?>
                            <h3><?php echo $beyondquery['beyond_count'] ?> </h3>
                            <p>Beyond SLG</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-pie-graph"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-xs-6"> 
                    <!-- small box -->
                    <div class="small-box bg-yellow">
                        <div class="inner">
                            <?php
                            $repeatquery =  mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) AS repeat_count  FROM complaint WHERE repeat_complaint='on'"));
                            ?>
                            <h3><?php echo $repeatquery['repeat_count'] ?> </h3>
                            <p>Repeat Complaint</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-pie-graph"></i>
                        </div>
                    </div>
                </div>
                <div>
                    <hr>
                </div>
                <div class="col-lg-3 col-xs-6">
                    <!-- small box -->
                    <div class="small-box bg-green">
                        <div class="inner">
                            <?php
                            $housequery =  mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) as house_total FROM house WHERE is_deleted ='N'"));
                            ?>
                            <h3><?php echo $housequery['house_total'] ?> </h3>
                            <p>Total Houses</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-home"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-xs-6">

                    <div class="small-box bg-red" data-toggle="modal" data-target="#myModal" data-id="Allot_house">
                        <div class="inner">
                            <?php
                            $housequery1 =  mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) as house_total FROM house WHERE is_deleted ='N' AND house_status='Active'"));
                            ?>
                            <h3><?php echo $housequery1['house_total'] ?> </h3>
                            <p>Alloted Houses</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-home"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-xs-6">
                    <div class="small-box bg-yellow" data-toggle="modal" data-target="#myModal" data-id="Non_house">
                        <div class="inner">
                            <?php
                            $housequery2 =  mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) as house_total FROM house WHERE is_deleted ='N' AND house_status='Non-Active'"));
                            ?>
                            <h3><?php echo $housequery2['house_total'] ?> </h3>
                            <p>Un-Alloted Houses</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-home"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-xs-6">
                    <!-- small box -->
                    <div class="small-box bg-green">
                        <div class="inner">

                            <?php
                            $total = 0;
                            $count = 0;
                            date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
                            $date = date('Y-m-d H:i:s');
                            $month = date('m', strtotime($date));
                            $month2 = date('F', strtotime($date));
                            $year  = date('Y', strtotime($date));

                            $ratingquery =  mysqli_query($conn, "SELECT employee_feedback, MAX(feedback_datetime) FROM `workman_feedback` WHERE  YEAR(feedback_datetime)='$year' AND MONTH(feedback_datetime)='$month' GROUP BY complaint_id");
                            while ($ratingList = mysqli_fetch_assoc($ratingquery)) {
                                $total += @$ratingList['employee_feedback'];
                                $count++;
                            }
                            if($count==0){
                            $total_number = $total / 1;
                            $totalvalue = (int)$total_number;
                            }else{
                                $total_number = $total / $count;
                            $totalvalue = (int)$total_number;
                            }

                            ?>
                            <h3>
                                <?php 
                                if ($totalvalue == 1) {
                                    echo  "Un-Satisfactory";
                                } elseif ($totalvalue == 2) {
                                    echo "Average";
                                } elseif ($totalvalue == 3) {
                                    echo "Good";
                                } elseif ($totalvalue == 4) {
                                    echo "V-Good";
                                } elseif ($totalvalue == 5) {
                                    echo "Excellence";
                                } else {
                                    echo "-";
                                } ?>
                            </h3>
                            <p><?= $month2 ." ". $year ?> Feedback</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-star"></i>
                        </div>
                    </div>
                </div>
                <div>
                    <hr>

                </div>

            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->
</div>
</body>
<?php
include("layouts/footer.php");
?>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script>
    $("#complaint_number").autocomplete({
        source: "complaint_number_autocomplete.php",
    });

    $(document).ready(function() {

        $('#reservation').daterangepicker();

        $('#myModal').on('show.bs.modal', function(e) {
            $('#table_app').html("");
            var iddetails = $(e.relatedTarget).data('id');
            // alert(iddetails);
            $('#abc').html("");
            if (iddetails == "Allot_house") {
                $('#abc').append("Alloted Houses");
            } else if (iddetails == "Non_house") {
                $('#abc').append("Un-Alloted Houses");
            }

            $.ajax({
                method: 'GET',
                url: "dashboard_model.php",
                data: {
                    'type': iddetails
                }
            }).done(function(data) {
                // console.log(data);
                $('#table_app').append(`<div class="modal-body1">`);
                $('#table_app').append(data);
                $('#table_app').append(`</div>`);
            });
        });
    });
</script>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title contenttoshow" id="abc"> </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div id="table_app">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php
if ($_SESSION['change_password'] == 'Y') {
?>
    <div class="modal fade" id="success-alert" tabindex="-1" role="dialog" data-backdrop="static" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Change Temporary Password</h5>
                </div>
                <form class="form-horizontal" method="post" action="">
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="exampleInputPassword1">Old Password</label>
                            <input type="password" name="old_password" class="form-control rec" placeholder="Old Password" required>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">New Password</label>
                            <input type="password" name="new_password" id="new_password" class="form-control rec" placeholder="New Password" required min="1">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Confirm New Password</label>
                            <input type="password" name="confirm_new_password" class="form-control rec" placeholder="Confirm New Password" required min="1">
                        </div>
                    </div>
                    <small style="color:red"><i>  <ul>
                        <li>Your Password Must Contain At Least 7 Digits !</li>
                        <li> Your Password Must Contain At Least 1 Number !</li>
                        <li>Your Password Must Contain At Least 1 Capital Letter !</li>
                        <li>Your Password Must Contain At Least 1 Lowercase Letter !</li>
                        <li>Your Password Must Contain At Least 1 Special Character !</li>
                </ul></i></small>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary" id="submit_request" onclick="checkPassword()" name="chg_pwd">Submit</button>
                    </div>
                </form>
                
            </div>
        </div>
    </div>
    <script>
        $('#success-alert').modal('show');
    </script>
<?php
}
?>